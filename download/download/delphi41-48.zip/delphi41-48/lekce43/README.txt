Z d�vodu neexistence knihovny FreeType pro Delphi v sou�asnosti neportovateln� :-(
