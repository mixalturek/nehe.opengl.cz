<?
class SkinDefault
{
	function CSS()// Vlo�� kask�dov� styl (p_begin.php)
	{
		echo '<link href="skin/default.css" rel="stylesheet" type="text/css" media="all" />'."\n";
		echo '<link href="skin/print.css" rel="stylesheet" type="text/css" media="print" />'."\n";
	}

	function WebIco()// Ikona str�nky (p_begin.php)
	{
		echo '<link rel="shortcut icon" href="skin/default/web.ico" type="image/x-icon" />'."\n";
	}

	function ImgMainLogo()// Hlavn� logo str�nky (p_left.php)
	{
		echo '<img src="skin/default/web_logo.gif" width="135" height="135" style="margin-left: 5px;" alt="CZ NeHe OpenGL" />';
	}

	function ImgBlank()// Obr�zek u odkazu s parametrem target="_blank"
	{
		echo ' <img src="skin/default/blank.gif" class="blank" alt="Nov� okno" />';
	}

	function ImgDown()// Obr�zek u odkazu pro download souboru
	{
		echo ' <img src="skin/default/down.gif" class="down" alt="Download" />';
	}

	function ImgOpenGL()// (index.php) Obr�zek loga OpenGL
	{
		echo '<img src="skin/default/opengl.gif" width="136" height="60" align="left" alt="OpenGL" />'."\n";
	}

	function ImgStatistiky($width, $height, $alt)
	{
		echo '<img src="skin/default/statistiky.jpg" width="'.$width.'" height="'.$height.'" alt="'.$alt.'" title="'.$alt.'" />'."\n";
	}

	function MainMenu()
	{
?>
<body>

<!-- Lev� sloupec -->
<div class="levy">
<div id="main_menu">
<a href="http://nehe.opengl.cz/"><?$this->ImgMainLogo();?></a>

<div class="main_menu_bez_loga">

<ul class="text_main_menu">
<li><a href="my.php" title="P�ekladatel� NeHe Tutori�l� a auto�i �l�nk�">My</a></li>
<li><a href="novinky.php" title="Co je nov�ho">Novinky</a></li>
<li><a href="navigacni_mapa.php" title="P�ehledn� navigace na jednotliv� str�nky, kter� dohromady tvo�� tento web">Naviga�n� mapa</a></li>
<li><a href="kontakt.php" title="Kontakt na spr�vce tohoto webu">Kontakt</a></li>
<li><a href="guestbook.php" title="Napi�te, jak se v�m l�b� tento web">Kniha n�v�t�v</a></li>
</ul>

<ul class="text_main_menu">
<li><a href="clanky.php" title="Obsah �l�nk�">�l�nky</a></li>
<li><a href="tut_obsah.php" title="Obsah NeHe OpenGL Tutori�l�">NeHe Tutori�ly</a></li>
<li><a href="programy.php" title="Programy od �esk�ch autor�">�esk� programy</a></li>
<li><a href="cl_gl_zacinam.php" title="Kde za��t p�i u�en� OpenGL">Pomoc, za��n�m</a></li>
<li><a href="cl_z_internetu.php" title="Seri�ly �l�nk� postahovan� p�i brouzdn�n� internetem">Z internetu</a></li>
<li><a href="odkazy.php" title="Jin� zdroje informac�">Odkazy</a></li>
</ul>

<ul class="text_main_menu">
<li><a href="spoluprace.php" title="Nechcete se pod�let na tvorb� t�chto webov�ch str�nek?">Spolupr�ce...?</a></li>
<li><a href="download.php" title="Stahujte">Download</a></li>
<li><a href="statistiky.php" title="Statistiky n�v�t�vnosti webu">Statistiky</a></li>
<li><a href="skiny.php" title="Nastavte si jin� layout a design str�nek">Skiny</a></li>
<li><a href="javascript:window.print();" title="Vytiskne tuto str�nku">Tisk</a></li>
</ul>

<ul class="text_main_menu">
<li>
<form action="fulltext.php" method="post" onsubmit="if(!this.najit.value) { alert('Byl zad�n pr�zdn� �et�zec!'); this.najit.focus(); return false; }">
<input type="text" name="najit" size="12" class="editbox" /><br />
<input type="submit" value="Fulltext" class="tlacitko" title="Prohled� soubory t�chto str�nek a pokus� se naj�t zadan� �et�zec" />
<input type="checkbox" name="case_sensitive" value="ano" title="Rozli�ovat mal� a velk� p�smena" /> Aa
</form>
</li>
</ul>

</div>

</div>
</div>
<!-- Lev� sloupec (konec) -->

<?
	}

	function TutMenu()
	{
?>
<!-- Prav� sloupec -->
<div class="pravy">
<div id="tut_menu">

<ul class="text_tut_menu">
<?
		for($i = 1; $i <= 48; $i++)
		{
			switch($i)
			{
				case 1: $tit="Vytvo�en� OpenGL okna ve Windows"; break;
				case 2: $tit="Vytv��en� troj�heln�k� a �ty��heln�k�"; break;
				case 3: $tit="Barvy"; break;
				case 4: $tit="Rotace"; break;
				case 5: $tit="Pevn� objekty"; break;
				case 6: $tit="Textury"; break;
				case 7: $tit="Texturov� filtry, osv�tlen�, ovl�d�n� pomoc� kl�vesnice"; break;
				case 8: $tit="Blending"; break;
				case 9: $tit="Pohyb bitmap ve 3D prostoru"; break;
				case 10: $tit="Vytvo�en� 3D sv�ta a pohyb v n�m"; break;
				case 11: $tit="Efekt vln�c� se vlajky"; break;
				case 12: $tit="Display list"; break;
				case 13: $tit="Bitmapov� fonty"; break;
				case 14: $tit="Outline fonty"; break;
				case 15: $tit="Mapov�n� textur na fonty"; break;
				case 16: $tit="Mlha"; break;
				case 17: $tit="2D fonty z textur"; break;
				case 18: $tit="Quadratic"; break;
				case 19: $tit="��sticov� syst�my"; break;
				case 20: $tit="Maskov�n�"; break;
				case 21: $tit="P��mky, antialiasing, �asov�n�, pravo�hl� projekce, z�kladn� zvuky a jednoduch� hern� logika"; break;
				case 22: $tit="Bump Mapping &amp; Multi Texturing"; break;
				case 23: $tit="Mapov�n� textur na kulov� quadratiky"; break;
				case 24: $tit="V�pis OpenGL roz���en�, o�ez�vac� testy a textury z TGA obr�zk�"; break;
				case 25: $tit="Morfov�n� objekt� a jejich nahr�v�n� z textov�ho souboru"; break;
				case 26: $tit="Odrazy a jejich o�ez�v�n� za pou�it� stencil bufferu"; break;
				case 27: $tit="St�ny"; break;
				case 28: $tit="Bezierovy k�ivky a povrchy, fullscreen fix"; break;
				case 29: $tit="Blitter, nahr�v�n� .RAW textur"; break;
				case 30: $tit="Detekce koliz�"; break;
				case 31: $tit="Nahr�v�n� a renderov�n� model�"; break;
				case 32: $tit="Picking, alfa blending, alfa testing, sorting"; break;
				case 33: $tit="Nahr�v�n� komprimovan�ch i nekomprimovan�ch obr�zk� TGA"; break;
				case 34: $tit="Generov�n� ter�n� a krajin za pou�it� v��kov�ho mapov�n� textur"; break;
				case 35: $tit="P�ehr�v�n� videa ve form�tu AVI"; break;
				case 36: $tit="Radial Blur, renderov�n� do textury"; break;
				case 37: $tit="Cel-Shading"; break;
				case 38: $tit="Nahr�v�n� textur z resource souboru &amp; texturov�n� troj�heln�k�"; break;
				case 39: $tit="�vod do fyzik�ln�ch simulac�"; break;
				case 40: $tit="Fyzik�ln� simulace lana"; break;
				case 41: $tit="Volumetrick� mlha a nahr�v�n� obr�zk� pomoc� IPicture"; continue; break;
				case 42: $tit="V�ce viewport�"; break;
				case 43: $tit="FreeType Fonty v OpenGL"; break;
				case 44: $tit="�o�kov� efekty"; break;
				case 45: $tit="Vertex Buffer Object (VBO)"; break;
				case 46: $tit="Fullscreenov� antialiasing"; continue; break;
				case 47: $tit="CG vertex shader"; continue; break;
				case 48: $tit="ArcBall rotace"; continue; break;
				default: break;
			}

			$L = ($i < 10) ? '0'.$i : $i;
			echo "<li class=\"li_tut\"><a href=\"tut_$L.php\" title=\"Lekce $i - $tit\">$L</a></li>\n";
		}
?>
</ul>

</div>
</div>
<!-- Prav� sloupec (konec) -->
<?
	}

	function Informace()
	{
?>
<!-- Informace o webu -->
<center><div id="informace">
<img src="images/my/woq.gif" width="60" height="60" align="right" alt="Woq logo" />
<div><b>Informace</b></div>
<div>Aktu�ln� po�et online �ten���: <?include 'p_online.php';?></div>
<br />
<div>Adresa indexu: <a href="http://nehe.opengl.cz/" target="_blank">http://nehe.opengl.cz/<?$this->ImgBlank();?></a></div>
<div>Web byl inspirov�n: <a href="http://nehe.gamedev.net/" target="_blank">http://nehe.gamedev.net/<?$this->ImgBlank();?></a></div>
<div>Zalo�il a spravuje: Michal Turek - Woq <?VypisEmail('woq@email.cz');?></div>
<br />
<div>V z�sad� nejsem proti tomu, abyste �l�nky um�stili i na sv� str�nky, nicm�n� p�edt�m ne� tak u�in�te, alespo� mi napi�te - je to slu�nost.</div>
</div></center>
<!-- Informace o webu (konec) -->
<?
	}

}
?>
