/***************************************************************************
 *   Copyright (C) 2005 by Adam Haiduk                                     *
 *   puvodni program (C) Michal Turek                                      *
 *                                                                         *
 *   3D real-time aplikace pro predmet POGR                                *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <stdio.h>
#include <SDL.h>
#include <math.h>
#include <limits>



/*
 * Pro vetsi prehlednost a rychlejsi upravy symbolicke konstanty
 * Neni spatny napad nacitat nektere parametry ze souboru...
 */

#define SDL_SUBSYSTEMS SDL_INIT_VIDEO

#define WIN_FLAGS SDL_ANYFORMAT|SDL_SWSURFACE     // |SDL_FULLSCREEN
#define WIN_WIDTH 1024
#define WIN_HEIGHT 768
#define WIN_BPP 32

#define WIN_TITLE "3D real-time aplikace"


#define DEBUG(x) printf("*** DEBUG : %s:%d:%s(): "#x"= %f \n",__FILE__,__LINE__,__FUNCTION__,(double)(x))
#define PI 3.14159265





/*
 * Deklarace funkci
 */

int max(int p1, int p2);
void Trojuhelnik(float x1, float y1,float z1, float x2, float y2,float z2, float x3, float y3, float z3, Uint8 color);
void Nacti(char soubor[]);
void Test();
void ClearScreen();
void Projekce(double zoom,double uhelx, double uhely, double uhelz);

/*
 * Globalni promenne
 */

SDL_Surface *g_screen;
Uint32 PocetBodu;
Uint32 PocetTroj;
Uint32 *Troj;
float *Body;
int l1=0;  //pocty bodu v jednotlivych carach
int l2=0;
int l3=0;
double rotaceleft=0;//uhel, o ktery se ma obrazek pootocit kolem osy y
double rotaceup=0;//uhel, o ktery se ma obrazek pootocit kolem osy x

double buffer[1024][768]; //kazdy bod obsahuje z-ovou slozku prislusneho bodu 
const int zvetseni=50;
bool otacet = true;


/*
 * Inicializacni funkce
 */

bool Init()
{
	// Inicializace SDL
	if(SDL_Init(SDL_SUBSYSTEMS) == -1)
	{
		fprintf(stderr, "Unable to initialize SDL: %s\n",
				SDL_GetError());
		return false;
	}

	// Vytvori okno s definovanymi vlastnostmi
	g_screen = SDL_SetVideoMode(WIN_WIDTH, WIN_HEIGHT, WIN_BPP, WIN_FLAGS);

	if(g_screen == NULL)
	{
		fprintf(stderr, "Unable to set %dx%d video: %s\n",
				WIN_WIDTH, WIN_HEIGHT, SDL_GetError());
		return false;
	}

	// Titulek okna
	SDL_WM_SetCaption(WIN_TITLE, NULL);

	return true;
}


/*
 * Deinicializacni funkce
 */

void Destroy()
{
	SDL_Quit();
}


/*
 * Nacteni vstupniho souboru
 */

void Nacti(char soubor[])
{
  FILE *F = fopen(soubor,"r");
  if (F==NULL)
    {
      printf("pokusny radek\n");
      F = fopen("venus-torso.ifs","r");
      printf("Nacitam soubor venus-torso.ifs, pokud chces nacist jiny, zadej ho jako parametr pri spousteni\n");
    }
  Uint32 cislo;
  float cislo2;
  char text[20];
  char nazev[40];

  // Nacti hlavicku
  fread(&cislo,4,1,F);
  fread(&text,sizeof(unsigned char),cislo,F);
  
  fread(&cislo2,4,1,F);

  fread(&cislo,4,1,F);
  fread(&nazev,sizeof(unsigned char),cislo,F);

  printf("%s %f %s\n",text,(double)cislo2,nazev);

  //Nacti vertexy (body)
  fread(&cislo,4,1,F);
  fread(&text,sizeof(unsigned char),cislo,F);//text==VERTICES

  fread(&PocetBodu,4,1,F);

  printf("%d\n",PocetBodu);                     

  float (*Points)[3]=new float[PocetBodu][3];
  for (long i=0;i<PocetBodu;i++)
    {
      fread(&Points[i][0],4,3,F);//nacteme rovnou vsechny 3 souradnice
      //printf("bod %d: %f %f %f\n",i+1,Points[i][0],Points[i][1],Points[i][2]);
    }

  //Nacti Trojuhelniky
  fread(&cislo,4,1,F);
  fread(&text,sizeof(unsigned char),cislo,F);//text==TRIANGLES
  
  fread(&PocetTroj,4,1,F);

  printf("%d\n",PocetTroj);                     

  Uint32 (*Trojuhelniky)[3]=new Uint32[PocetTroj][3];
  for (long i=0;i<PocetTroj;i++)
    {
      fread(&Trojuhelniky[i][0],4,3,F);//nacteme rovnou vsechny 3 souradnice
      //printf("Trojuhelnik %d: %d %d %d\n",i+1,Trojuhelniky[i][0],Trojuhelniky[i][1],Trojuhelniky[i][2]);
    }

  fclose(F); 
  
  Body=(float*)Points;
  Troj=(Uint32*)Trojuhelniky;

}


void Test()
{ 
  ClearScreen();
  printf("Z-buffer hodnota min=%f\n",buffer[0][0]);
  printf(" pokus (Uint8) -8 =%d\n",(Uint8) -8);
  //Trojuhelnik(10,20,10,440,700,10,550,100,20,220);
  float neco;
  neco=*(Body);
  DEBUG(neco);
  neco=*(Body+1);
  DEBUG(neco);
  neco=*(Body+2);
  DEBUG(neco);
  
  neco=15.32;
  *(Body)=neco;
  neco=*(Body);
  DEBUG(neco);
  neco=*(Body+1);
  DEBUG(neco);
  neco=*(Body+2);
  DEBUG(neco);
  
}

void Trojuhelnik(float x1, float y1,float z1, float x2, float y2,float z2, float x3, float y3, float z3, Uint8 color)
{
  // postup
  // seradim body tak, aby 1. byl vpravo nahore, druhy co nejdal vlevo (souradnice x)
  // vyhodnotim specialni pripady
  //ulozim si x-ove nrbo y-ve souradnice bodu
  //provedu vypln : pro kazdy bod urcim x, y a z
  // pokud bude treba, tak jej nakreslim
  

  // Seradeni
  int lx,ly,sx,sy,px,py;  //levy stredni a pravy vrchol
  double lz,sz,pz;
  l1=0;
  l2=0;
  l3=0;
  if (x1<x2) 
    { 
    if (x2<x3)
      {
        lx=(int)round(x1);
	ly=(int)round(y1);
        lz=z1;
	sx=(int)round(x2);
	sy=(int)round(y2);
	sz=z2;
	px=(int)round(x3);
	py=(int)round(y3);
	pz=z3;
      }
    else  
      {
        if (x1<x3)
	  {
	    lx=(int)round(x1);
	    ly=(int)round(y1);
	    lz=z1;
	    sx=(int)round(x3);
	    sy=(int)round(y3);
	    sz=z3;
	    px=(int)round(x2);
	    py=(int)round(y2);
	    pz=z2;
	  }
        else //x1<x2, x3<=x1
          {
	    lx=(int)round(x3);
	    ly=(int)round(y3);
	    lz=z3;
	    sx=(int)round(x1);
	    sy=(int)round(y1);
	    sz=z1;
	    px=(int)round(x2);
	    py=(int)round(y2);
	    pz=z2;
	  }
      }
    }
  else  //x2<=x1
    { 
    if (x1<x3)
      {
        lx=(int)round(x2);
	ly=(int)round(y2);
	lz=z2;
	sx=(int)round(x1);
	sy=(int)round(y1);
	sz=z1;
	px=(int)round(x3);
	py=(int)round(y3);
	pz=z3;
      }
    else  //x2<=x1 x3<=x1
      {
        if (x2<x3)
	  {
	    lx=(int)round(x2);
	    ly=(int)round(y2);
	    lz=z2;
	    sx=(int)round(x3);
	    sy=(int)round(y3);
	    sz=z3;
	    px=(int)round(x1);
	    py=(int)round(y1);
	    pz=z1;
	  }
        else //x2<=x1, x3<=x1 x2>=x3
          {
	    lx=(int)round(x3);
	    ly=(int)round(y3);
	    lz=z3;
	    sx=(int)round(x2);
	    sy=(int)round(y2);
	    sz=z2;
	    px=(int)round(x1);
	    py=(int)round(y1);
	    pz=z1;
	  }
      }
    }
  //printf("lx=%d ly=%d sx=%d sy=%d px=%d py=%d color=%d\n",lx,ly,sx,sy,px,py,color);

  // Vytvorim lajnu z L do P a ulozim body do pameti
  double (*lajna1)[3]=new double[max((int)fabs(px-lx),(int)fabs(py-ly))+1][3];
  if (px-lx!=0)
    {
      double m=(py-ly)/(double)(px-lx);
      //DEBUG(m);
      if (m <-1.0) //pripad 1
	{
	  double pom=(px-lx)/(double)(py-ly);
          double n=(pz-lz)/(double)(py-ly);
	  for (int y=ly;y>=py;y--)
	    {
	      lajna1[ly-y][0]=round(lx+pom*(y-ly));
	      lajna1[ly-y][1]=y;
	      lajna1[ly-y][2]=lz+n*(y-ly);
	      l1++;
	    }
	}
	     					
      else if (m <=1 )//pripad 2 a 3 - jsou stejne a patri sem i 7
	{
	  double pom=(py-ly)/(double)(px-lx);
          double n=(pz-lz)/(double)(px-lx);
	  for (int x=lx;x<=px;x++)
	    {
	      lajna1[x-lx][0]=x;
	      lajna1[x-lx][1]=round(ly+pom*(x-lx));
	      lajna1[x-lx][2]=lz+n*(x-lx);   //(x-lx)/(px-lx) musi probihat od 0 do 1
	      l1++;
	    }
	}
      else //m >=1 ://pripad 4
	{
	  double pom=(px-lx)/(double)(py-ly);
	  double n=(pz-lz)/(double)(py-ly);
	  for (int y=ly;y<=py;y++)
	    {
	      lajna1[y-ly][0]=round(lx+pom*(y-ly));
	      lajna1[y-ly][1]=y;
	      lajna1[y-ly][2]=lz+n*(y-ly);
	      l1++;
	    }
	}
    }

  else //pripad 5 a 6
    {
      if (ly>py) // pripad 5
	{
	  double pom=0.;
          double n=(pz-lz)/(double)(py-ly);
	  for (int y=ly;y>=py;y--)
	    {
	      lajna1[ly-y][0]=lx;
	      lajna1[ly-y][1]=y;
	      lajna1[ly-y][2]=lz+n*(y-ly);
	      l1++;
	    }
	}
      else //pripad 6 a 0-va usecka(1 bod)
	{
          if (ly=py) //0-va usecka
	    {
	      lajna1[0][0]=lx;
	      lajna1[0][1]=ly;
	      lajna1[0][2]=(lz+pz)/2.;
	      l1++;
	    }
	  else // pripad 6
	    {
	      double pom=0.;
	      double n=(pz-lz)/(double)(py-ly);
	      for (int y=ly;y<=py;y++)
		{
		  lajna1[y-ly][0]=lx;
		  lajna1[y-ly][1]=y;
		  lajna1[y-ly][2]=lz+n*(y-ly);
		  l1++;
		}
	    }
	}
    }


// Vytvorim lajnu z L do S a ulozim body do pameti
  double (*lajna2)[3]=new double[max((int)fabs(sx-lx),(int)fabs(sy-ly))+1][3];
  if (sx-lx!=0)
    {
      double m=(sy-ly)/(double)(sx-lx);
      //DEBUG(m);
      if (m <-1.0) //pripad 1
	{
	  double pom=(sx-lx)/(double)(sy-ly);
          double n=(sz-lz)/(double)(sy-ly);
	  for (int y=ly;y>=sy;y--)
	    {
	      lajna2[ly-y][0]=round(lx+pom*(y-ly));
	      lajna2[ly-y][1]=y;
	      lajna2[ly-y][2]=lz+n*(y-ly);
	      l2++;
	    }
	}
	     					
      else if (m <=1 )//pripad 2 a 3 - jsou stejne a patri sem i 7
	{
	  double pom=(sy-ly)/(double)(sx-lx);
          double n=(sz-lz)/(double)(sx-lx);
	  for (int x=lx;x<=sx;x++)
	    {
	      lajna2[x-lx][0]=x;
	      lajna2[x-lx][1]=round(ly+pom*(x-lx));
	      lajna2[x-lx][2]=lz+n*(x-lx);   //(x-lx)/(sx-lx) musi probihat od 0 do 1
	      l2++;
	    }
	}
      else //m >=1 ://pripad 4
	{
	  double pom=(sx-lx)/(double)(sy-ly);
	  double n=(sz-lz)/(double)(sy-ly);
	  for (int y=ly;y<=sy;y++)
	    {
	      lajna2[y-ly][0]=round(lx+pom*(y-ly));
	      lajna2[y-ly][1]=y;
	      lajna2[y-ly][2]=lz+n*(y-ly);
	      l2++;
	    }
	}
    }

  else //pripad 5 a 6
    {
      if (ly>sy) // pripad 5
	{
	  double pom=0.;
          double n=(sz-lz)/(double)(sy-ly);
	  for (int y=ly;y>=sy;y--)
	    {
	      lajna2[ly-y][0]=lx;
	      lajna2[ly-y][1]=y;
	      lajna2[ly-y][2]=lz+n*(y-ly);
	      l2++;
	    }
	}
      else //pripad 6 a 0-va usecka(1 bod)
	{
          if (ly=sy) //0-va usecka
	    {
	      lajna2[0][0]=lx;
	      lajna2[0][1]=ly;
	      lajna2[0][2]=(lz+sz)/2.;
	      l2++;
	    }
	  else // pripad 6
	    {
	      double pom=0.;
	      double n=(sz-lz)/(double)(sy-ly);
	      for (int y=ly;y<=sy;y++)
		{
		  lajna2[y-ly][0]=lx;
		  lajna2[y-ly][1]=y;
		  lajna2[y-ly][2]=lz+n*(y-ly);
		  l2++;
		}
	    }
	}
    }


// Vytvorim lajnu z S do P a ulozim body do pameti
  double (*lajna3)[3]=new double[max((int)fabs(px-sx),(int)fabs(py-sy))+1][3];
  if (px-sx!=0)
    {
      double m=(py-sy)/(double)(px-sx);
      //DEBUG(m);
      if (m <-1.0) //pripad 1
	{
	  double pom=(px-sx)/(double)(py-sy);
          double n=(pz-sz)/(double)(py-sy);
	  for (int y=sy;y>=py;y--)
	    {
	      lajna3[sy-y][0]=round(sx+pom*(y-sy));
	      lajna3[sy-y][1]=y;
	      lajna3[sy-y][2]=sz+n*(y-sy);
	      l3++;
	    }
	}
	     					
      else if (m <=1 )//pripad 2 a 3 - jsou stejne a patri sem i 7
	{
	  double pom=(py-sy)/(double)(px-sx);
          double n=(pz-sz)/(double)(px-sx);
	  for (int x=sx;x<=px;x++)
	    {
	      lajna3[x-sx][0]=x;
	      lajna3[x-sx][1]=round(sy+pom*(x-sx));
	      lajna3[x-sx][2]=sz+n*(x-sx);   //(x-sx)/(px-sx) musi probihat od 0 do 1
	      l3++;
	    }
	}
      else //m >=1 ://pripad 4
	{
	  double pom=(px-sx)/(double)(py-sy);
	  double n=(pz-sz)/(double)(py-sy);
	  for (int y=sy;y<=py;y++)
	    {
	      lajna3[y-sy][0]=round(sx+pom*(y-sy));
	      lajna3[y-sy][1]=y;
	      lajna3[y-sy][2]=sz+n*(y-sy);
	      l3++;
	    }
	}
    }

  else //pripad 5 a 6
    {
      if (sy>py) // pripad 5
	{
	  double pom=0.;
          double n=(pz-sz)/(double)(py-sy);
	  for (int y=sy;y>=py;y--)
	    {
	      lajna3[sy-y][0]=sx;
	      lajna3[sy-y][1]=y;
	      lajna3[sy-y][2]=sz+n*(y-sy);
	      l3++;
	    }
	}
      else //pripad 6 a 0-va usecka(1 bod)
	{
          if (sy=py) //0-va usecka
	    {
	      lajna3[0][0]=sx;
	      lajna3[0][1]=sy;
	      lajna3[0][2]=(sz+pz)/2.;
	      l3++;
	    }
	  else // pripad 6
	    {
	      double pom=0.;
	      double n=(pz-sz)/(double)(py-sy);
	      for (int y=sy;y<=py;y++)
		{
		  lajna3[y-sy][0]=sx;
		  lajna3[y-sy][1]=y;
		  lajna3[y-sy][2]=sz+n*(y-sy);
		  l3++;
		}
	    }
	}
    }

  // Vyplneni trojuhelnika
  int ymax, ymin;
  double zmax, zmin;
  int pozice1=0;
  int pozice2=0;  // kam az jsme dosli v lajne
  int pozice3=0;
  bool opakovat;
  int PocetBodu1=1;
  int PocetBodu2=1;
  int PocetBodu3=1;
  int bypp = g_screen->format->BytesPerPixel;
  int pitch = g_screen->pitch;
  for (int i=lx;i<=sx;i++)
    {
      PocetBodu1=1;
      PocetBodu2=1;
      do 
	{
	  opakovat=false;
	  if (((int)lajna1[pozice1+1][0]==i)&&(pozice1<l1-1))
	    {
	      opakovat=true;
	      PocetBodu1++;
	    }
	  pozice1++;
	}
      while (opakovat);
      do 
	{
	  opakovat=false;
	  if (((int)lajna2[pozice2+1][0]==i)&&(pozice2<l2-1))
	    {
	      opakovat=true;
	      PocetBodu2++;
	    }
	  pozice2++;
	}
      while (opakovat);
      
      double (*PomocnaLajna)[3]=new double[PocetBodu1 + PocetBodu2][3];
      
      for(int k=(pozice1-PocetBodu1);k<pozice1;k++)
	{
	  PomocnaLajna[k-pozice1+PocetBodu1][0]=lajna1[k][0];
	  PomocnaLajna[k-pozice1+PocetBodu1][1]=lajna1[k][1];
	  PomocnaLajna[k-pozice1+PocetBodu1][2]=lajna1[k][2];
	}

      for(int k=(pozice2-PocetBodu2);k<pozice2;k++)
	{
	  PomocnaLajna[k-pozice2+PocetBodu2+PocetBodu1][0]=lajna2[k][0];
	  PomocnaLajna[k-pozice2+PocetBodu2+PocetBodu1][1]=lajna2[k][1];
	  PomocnaLajna[k-pozice2+PocetBodu2+PocetBodu1][2]=lajna2[k][2];
	}
      ymax=(int)PomocnaLajna[0][1];
      zmax=(int)PomocnaLajna[0][2];
      ymin=(int)PomocnaLajna[0][1];
      zmin=(int)PomocnaLajna[0][2];
      for (int k=1;k<(PocetBodu1+PocetBodu2);k++)
	{
	  if ((int)PomocnaLajna[k][1]>ymax)
	    {
	      zmax=PomocnaLajna[k][2];
	      ymax=(int)PomocnaLajna[k][1];
	    }
	  if ((int)PomocnaLajna[k][1]<ymin)
	    {
	      zmin=PomocnaLajna[k][2];
	      ymin=(int)PomocnaLajna[k][1];
	    }
	  
	}

      // Vykresleni pixelu

      //Prvni pixel se nevykresli (ymax-ymin=0);
      //michal rika, ze to nemam resit... :)
      double zneco=(zmax-zmin)/(double)(ymax-ymin);

      // Vypsani PomocneLajny
      //DEBUG(i);
      /*for (int l=0;l<(PocetBodu1+PocetBodu2);l++)
	{
	  printf("[%5.1f %5.1f %5.1f]\n",PomocnaLajna[l][0],PomocnaLajna[l][1],PomocnaLajna[l][2]);
	}
	printf("ymax = %d, ymin = %d zmax=%f zmin=%f\n",ymax, ymin,zmax, zmin);*/


      // Pokracovani
      for (int j=ymin;j<=ymax-1;j++)
	{
	  if((i>=0) && (i<=1023) && (j>=0) && (j<=767))
	    {
	      double z=zmin+zneco*(j-ymin);
              //printf("vykreslovani bodu : [%d %d %f]\n",i,j,z);
	      if (z>buffer[i][j])
		{
		  *((Uint8 *)g_screen->pixels + j*pitch + i*bypp)=color;//Alpha
		  *((Uint8 *)g_screen->pixels + j*pitch + i*bypp+1)=color;
		  *((Uint8 *)g_screen->pixels + j*pitch + i*bypp+2)=color;
		  *((Uint8 *)g_screen->pixels + j*pitch + i*bypp+3)=255;
                  buffer[i][j]=z;
		}
	    }
	}
      delete [] PomocnaLajna;
    }

  // pokracuji pro 3 lajnu...


  //nastaveni pozice3 na dalsi hodnotu x
  do
    {
      opakovat=false;
      if ((int)lajna3[pozice3+1][0]==sx)
	{
	  opakovat=true;
	  PocetBodu3++;
	}
      pozice3++;
    }
  while (opakovat);



for (int i=sx+1;i<=px;i++)
    {
      PocetBodu1=1;
      PocetBodu3=1;
      do 
	{
	  opakovat=false;
	  if (((int)lajna1[pozice1+1][0]==i)&&(pozice1<l1-1))
	    {
	      opakovat=true;
	      PocetBodu1++;
	    }
	  pozice1++;
	}
      while (opakovat);
      do 
	{
	  opakovat=false;
	  if (((int)lajna3[pozice3+1][0]==i)&&(pozice3<l3-1))
	    {
	      opakovat=true;
	      PocetBodu3++;
	    }
	  pozice3++;
	}
      while (opakovat);
      
      double (*PomocnaLajna)[3]=new double[PocetBodu1 + PocetBodu3][3];
      
      for(int k=(pozice1-PocetBodu1);k<pozice1;k++)
	{
	  PomocnaLajna[k-pozice1+PocetBodu1][0]=lajna1[k][0];
	  PomocnaLajna[k-pozice1+PocetBodu1][1]=lajna1[k][1];
	  PomocnaLajna[k-pozice1+PocetBodu1][2]=lajna1[k][2];
	}

      for(int k=(pozice3-PocetBodu3);k<pozice3;k++)
	{
	  PomocnaLajna[k-pozice3+PocetBodu3+PocetBodu1][0]=lajna3[k][0];
	  PomocnaLajna[k-pozice3+PocetBodu3+PocetBodu1][1]=lajna3[k][1];
	  PomocnaLajna[k-pozice3+PocetBodu3+PocetBodu1][2]=lajna3[k][2];
	}
      ymax=(int)PomocnaLajna[0][1];
      zmax=(int)PomocnaLajna[0][2];
      ymin=(int)PomocnaLajna[0][1];
      zmin=(int)PomocnaLajna[0][2];
      for (int k=1;k<(PocetBodu1+PocetBodu3);k++)
	{
	  if ((int)PomocnaLajna[k][1]>ymax)
	    {

	      zmax=PomocnaLajna[k][2];
	      ymax=(int)PomocnaLajna[k][1];
	    }
	  if ((int)PomocnaLajna[k][1]<ymin)
	    {
	      zmin=PomocnaLajna[k][2];
	      ymin=(int)PomocnaLajna[k][1];
	    }
	  
	}

      // Vykresleni pixelu
      double zneco=(zmax-zmin)/(double)(ymax-ymin);

      // Vypsani PomocneLajny
      /*DEBUG(i);
      for (int l=0;l<(PocetBodu1+PocetBodu3);l++)
	{
	  printf("[%5.1f %5.1f %5.1f]\n",PomocnaLajna[l][0],PomocnaLajna[l][1],PomocnaLajna[l][2]);
	}
	printf("ymax = %d, ymin = %d\n",ymax, ymin);*/


      for (int j=ymin;j<=ymax-1;j++)
	{
	  if((i>=0) && (i<=1023) && (j>=0) && (j<=767))
	    {
	      double z=zmin+zneco*(j-ymin);
	      if (z>buffer[i][j])
		{
		  *((Uint8 *)g_screen->pixels + j*pitch + i*bypp)=color;//Alpha
		  *((Uint8 *)g_screen->pixels + j*pitch + i*bypp+1)=color;
		  *((Uint8 *)g_screen->pixels + j*pitch + i*bypp+2)=color;
		  *((Uint8 *)g_screen->pixels + j*pitch + i*bypp+3)=255;
                  buffer[i][j]=z;
		}
	    }
	}
      delete [] PomocnaLajna;
    }

  // uvolneni pouzite pameti
  delete [] lajna1;
  delete [] lajna2;
  delete [] lajna3;






  /*printf("lajna1 :\n");
  for (int i=0;i<l1;i++)
    printf("[%5.1f %5.1f %5.1f]\n",lajna1[i][0],lajna1[i][1],lajna1[i][2]);
  printf("lajna2 :\n");
  for (int i=0;i<l2;i++)
    printf("[%5.1f %5.1f %5.1f]\n",lajna2[i][0],lajna2[i][1],lajna2[i][2]);
  printf("lajna3 :\n");
  for (int i=0;i<l3;i++)
  printf("[%5.1f %5.1f %5.1f]\n",lajna3[i][0],lajna3[i][1],lajna3[i][2]);*/
}

void Projekce(double zoom,double uhelx, double uhely, double uhelz)
{
  Uint32 b1,b2,b3;
  float bod1[3];
  float bod2[3];
  float bod3[3];
  float prumer[3];
  float osvetleni[3]={-1000,-1000,-1000};
  float normala[3];
  float vektor[3];
  double skalsoucin;
  double abshodnoty;
  float cosinus;
  float x,y,z;
  
  ClearScreen();
  for (int s=0;s<PocetBodu;s++)
    {
      bod1[0]=*(Body+3*s);
      bod1[1]=*(Body+3*s+1);
      bod1[2]=*(Body+3*s+2);
      
      //Modifikace- zoom

      bod1[0]=bod1[0]*zoom;
      bod1[1]=bod1[1]*zoom;
      bod1[2]=bod1[2]*zoom;
      

     
      
       //Modifikace pro rotaci

      //Rotace kolem x
      
      // Matice : 1             0             0
      //          0        cos(uhelx)   -sin(uhelx)
      //          0        sin(uhelx)   cos(uhelx)

      //bod1
      x=bod1[0];
      y=bod1[1]*cos(uhelx)-bod1[2]*sin(uhelx);
      z=bod1[1]*sin(uhelx)+bod1[2]*cos(uhelx);
      bod1[0]=x;
      bod1[1]=y;
      bod1[2]=z;

      
      //Rotace kolem y
      
      // Matice :   cos(uhely)      0       -sin(uhely)    
      //              0             1           0
      //            sin(uhely)      0       cos(uhely)

      //bod1
      x=bod1[0]*cos(uhely)-bod1[2]*sin(uhely);
      y=bod1[1];
      z=bod1[0]*sin(uhely)+bod1[2]*cos(uhely);
      bod1[0]=x;
      bod1[1]=y;
      bod1[2]=z;

      //Rotace kolem z
      
      // Matice :   cos(uhelz)  -sin(uhelz)      0
      //            sin(uhelz)   cos(uhelz)      0
      //              0              0           1

      
      //bod1
      x=bod1[0]*cos(uhelz)-bod1[1]*sin(uhelz);
      y=bod1[0]*sin(uhelz)+bod1[1]*cos(uhelz);
      z=bod1[2];
      bod1[0]=x;
      bod1[1]=y;
      bod1[2]=z;


  
      //zapis zpet

      *(Body+3*s)=x;
      *(Body+3*s+1)=y;
      *(Body+3*s+2)=z;
      

      
      }
  

  for (int s=0;s<PocetTroj;s++)
    {
      b1=*(Troj+3*s);
      b2=*(Troj+3*s+1);
      b3=*(Troj+3*s+2);
      bod1[0]=*(Body+3*b1);
      bod1[1]=*(Body+3*b1+1);
      bod1[2]=*(Body+3*b1+2);
      bod2[0]=*(Body+3*b2);
      bod2[1]=*(Body+3*b2+1);
      bod2[2]=*(Body+3*b2+2);
      bod3[0]=*(Body+3*b3);
      bod3[1]=*(Body+3*b3+1);
      bod3[2]=*(Body+3*b3+2);
      

     
      /*
      //Modifikace- zoom

      bod1[0]=bod1[0]*zoom;
      bod1[1]=bod1[1]*zoom;
      bod1[2]=bod1[2]*zoom;
      bod2[0]=bod2[0]*zoom;
      bod2[1]=bod2[1]*zoom;
      bod2[2]=bod2[2]*zoom;
      bod3[0]=bod3[0]*zoom;
      bod3[1]=bod3[1]*zoom;
      bod3[2]=bod3[2]*zoom;


      
      //Modifikace pro rotaci

      //Rotace kolem x
      
      // Matice : 1             0             0
      //          0        cos(uhelx)  -sin(uhelx)
      //          0        sin(uhelx)   cos(uhelx)

      //bod1
      x=bod1[0];
      y=bod1[1]*cos(uhelx)-bod1[2]*sin(uhelx);
      z=bod1[1]*sin(uhelx)-bod1[2]*cos(uhelx);
      bod1[0]=x;
      bod1[1]=y;
      bod1[2]=z;

      //bod2
      x=bod2[0];
      y=bod2[1]*cos(uhelx)-bod2[2]*sin(uhelx);
      z=bod2[1]*sin(uhelx)-bod2[2]*cos(uhelx);
      bod2[0]=x;
      bod2[1]=y;
      bod2[2]=z;
      
      //bod3
      x=bod3[0];
      y=bod3[1]*cos(uhelx)-bod3[2]*sin(uhelx);
      z=bod3[1]*sin(uhelx)-bod3[2]*cos(uhelx);
      bod3[0]=x;
      bod3[1]=y;
      bod3[2]=z;
      
      //Rotace kolem y
      
      // Matice :   cos(uhely)      0       sin(uhely)    
      //              0             1           0
      //           -sin(uhely)      0       cos(uhely)

      //bod1
      x=bod1[0]*cos(uhely)+bod1[2]*sin(uhely);
      y=bod1[1];
      z=-bod1[0]*sin(uhely)+bod1[2]*cos(uhely);
      bod1[0]=x;
      bod1[1]=y;
      bod1[2]=z;

      //bod2
      x=bod2[0]*cos(uhely)+bod2[2]*sin(uhely);
      y=bod2[1];
      z=-bod2[0]*sin(uhely)+bod2[2]*cos(uhely);
      bod2[0]=x;
      bod2[1]=y;
      bod2[2]=z;

      //bod3
      x=bod3[0]*cos(uhely)+bod3[2]*sin(uhely);
      y=bod3[1];
      z=-bod3[0]*sin(uhely)+bod3[2]*cos(uhely);
      bod3[0]=x;
      bod3[1]=y;
      bod3[2]=z;

      
      //Rotace kolem z
      
      // Matice :   cos(uhelz)  -sin(uhelz)      0
      //            sin(uhelz)   cos(uhelz)      0
      //              0              0           1

      
      //bod1
      x=bod1[0]*cos(uhelz)-bod1[1]*sin(uhelz);
      y=bod1[0]*sin(uhelz)+bod1[1]*cos(uhelz);
      z=bod1[2];
      bod1[0]=x;
      bod1[1]=y;
      bod1[2]=z;
      
      //bod2
      x=bod2[0]*cos(uhelz)-bod2[1]*sin(uhelz);
      y=bod2[0]*sin(uhelz)+bod2[1]*cos(uhelz);
      z=bod2[2];
      bod2[0]=x;
      bod2[1]=y;
      bod2[2]=z;
      

      //bod3
      x=bod3[0]*cos(uhelz)-bod3[1]*sin(uhelz);
      y=bod3[0]*sin(uhelz)+bod3[1]*cos(uhelz);
      z=bod3[2];
      bod3[0]=x;
      bod3[1]=y;
      bod3[2]=z;
      
      */

      // Projekce promennych

      if ((bod1[2]!=200) || (bod2[2]!=200) || (bod3[2]!=200))
	{
	  //2 - 1: (bod2[0]-bod1[0]),(bod2[1]-bod1[1]),(bod2[2]-bod1[2])
 	  //3 - 2: (bod3[0]-bod2[0]),(bod3[1]-bod2[1]),(bod3[2]-bod2[2])
	  normala[0]=(bod2[1]-bod1[1])*(bod3[2]-bod2[2])-(bod2[2]-bod1[2])*(bod3[1]-bod2[1]);
	  normala[1]=(bod2[2]-bod1[2])*(bod3[0]-bod2[0])-(bod2[0]-bod1[0])*(bod3[2]-bod2[2]);
	  normala[2]=(bod2[0]-bod1[0])*(bod3[1]-bod2[1])-(bod2[1]-bod1[1])*(bod3[0]-bod2[0]);

	  //pozn tato normala v mem pripade miri dovnitr objektu...


          // a.b = |a|*|b|*cos(alfa)
	  prumer[0]=(bod1[0]+bod2[0]+bod3[0])/3;
	  prumer[1]=(bod1[1]+bod2[1]+bod3[1])/3;
	  prumer[2]=(bod1[2]+bod2[2]+bod3[2])/3;
	  vektor[0]=osvetleni[0]-prumer[0];
	  vektor[1]=osvetleni[1]-prumer[1];
	  vektor[2]=osvetleni[2]-prumer[2];

	  skalsoucin=vektor[0]*normala[0]+vektor[1]*normala[1]+vektor[2]*normala[2];
          abshodnoty=sqrt( vektor[0]*vektor[0] +vektor[1]*vektor[1]+vektor[2]*vektor[2])*
	    sqrt(normala[0]*normala[0]+normala[1]*normala[1]+normala[2]*normala[2]);
	  if (abshodnoty<0.0000001) abshodnoty=0.0000001;

	  cosinus=(skalsoucin/abshodnoty)*(-200);// po vynasobeni minusem kladne hodnoty odpovidaji pripadu, kdy svetlo dopada na vnejsi stranu
	  // vynasobim jenom 200, nikoli 255 - obrazek neni tolik presvetleny...
	  
	  if (cosinus<0)
	    cosinus=cosinus*(-1);
	    
	      
	      
	  
	  bod1[0]=(bod1[0]*1000/(200-bod1[2]))+512;
	  bod2[0]=(bod2[0]*1000/(200-bod2[2]))+512;
	  bod3[0]=(bod3[0]*1000/(200-bod3[2]))+512; 
	  bod1[1]=(bod1[1]*1000/(200-bod1[2]))+384;
	  bod2[1]=(bod2[1]*1000/(200-bod2[2]))+384;
	  bod3[1]=(bod3[1]*1000/(200-bod3[2]))+384; 
	  
	  //printf("-----------------------------------------------------------------------\n");
	  //printf("Trojuhelnik %d\n",s);
	  //printf("Trojuhelnik(%f,%f,%f,%f,%f,%f,%f,%f,%f,%d)\n",bod1[0],bod1[1],bod1[2],bod2[0],bod2[1],bod2[2],bod3[0],bod3[1],bod3[2],(Uint8)(skalsoucin/abshodnoty)*255);
	  if (normala[2]>0)
    Trojuhelnik(bod1[0],bod1[1],bod1[2],bod2[0],bod2[1],bod2[2],bod3[0],bod3[1],bod3[2],(Uint8)cosinus);
	    
	}
      //SDL_Flip(g_screen);
      //SDL_Delay(1000);
    }
  SDL_Flip(g_screen);

}


void ClearScreen()
{
  for(int i=0;i<1024;i++)
    for(int j=0;j<768;j++)
      buffer[i][j]=-1*std::numeric_limits<double>::max();
  SDL_FillRect(g_screen, NULL, SDL_MapRGB(g_screen->format, 0, 0, 0));
  

}

int max(int p1, int p2)
{
  if (p1>p2)
    return p1;
  else
    return p2;
}




/*
 * Osetruje udalosti (bude probrano nekdy v budoucnu)
 * V tomto pripade ceka se na klavesu ESC, ktera ukonci program
 */

bool ProcessEvent()
{
	SDL_Event event;

	while(SDL_PollEvent(&event))
	{
		switch(event.type)
		{
			case SDL_KEYDOWN:
				switch(event.key.keysym.sym)
				{
					case SDLK_ESCAPE:
						return false;
						break;


					case SDLK_KP_PLUS:	
					case SDLK_PLUS:
						Projekce(1.1,0,0,0);
						break;
				        
				        case SDLK_KP_MINUS:
					case SDLK_MINUS:
						Projekce(0.9,0,0,0);
						break;

                  			case SDLK_UP:
					        Projekce(1,PI/12,0,0);
						break;

					case SDLK_DOWN:
					        Projekce(1,-PI/12,0,0);
						break;

					case SDLK_LEFT:
					        Projekce(1,0,PI/12,0);
						break;

					case SDLK_RIGHT:
					        Projekce(1,0,-PI/12,0);
						break;

					case SDLK_SPACE:
					        otacet=!otacet;
						break;


					default:
						break;
				}
				break;

			case SDL_QUIT:
				return false;
				break;

			default:
				break;
		}
	}

	return true;
}


/*
 * Vstup do programu
 */

int main(int argc, char *argv[])
{
	printf(WIN_TITLE"\n");
	// Inicializace
	if(!Init())
	{
		Destroy();
		return 1;
	}

	Nacti(argv[1]);

	printf("Funkcni klavesy jsou : sipky pro otaceni, + a - pro zoom, Mezera pro zapnuti/vypnuti rotace, Esc pro konec\n");
	//Test();
	ClearScreen();
	Projekce(zvetseni,0.,PI,PI);
        
	// Hlavni smycka programu  
	bool done = false;
 
	while(!done)
	{
		done = !ProcessEvent();
		// TODO: Tady by se vykreslovalo
		if (otacet)
		  Projekce(1,0,PI/200,0);
	}

	// Deinicializace a konec
	Destroy();
	return 0;
}
