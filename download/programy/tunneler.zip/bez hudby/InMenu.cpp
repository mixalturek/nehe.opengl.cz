/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Obrazovka hlavneho menu
############################################################################################*/

#include <windows.h>						// hlavickovy subor pre winapi
#include <gl\gl.h>							// hlavickovy subor pre OpenGL
#include <gl\glu.h>							// hlavickovy subor pre Glu
#include <stdio.h>							// standardny vstup / vystup
#include <stdarg.h>							// funkcie s variabilnym poctom argumentov
#include <string.h>							// praca s retazcami
#include "Tuneller.h"						// hlavickovy subor tejto hry
//===================================================================< DEFINICIE OBJEKTOV >========
TMenuClass	Menu;
//===================================================================< MENUCLASS >=================
TMenuClass::TMenuClass()
{
	BNew.SetMe(440,250,"Nova Hra");
	BSet.SetMe(440,300,"Nastavenie");
	BAut.SetMe(440,350,"Autori");
	BExt.SetMe(440,400,"Koniec");
	Lista.SetMe(0,0,"AUTORI");
};
void TMenuClass::Redraw()
{
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	Image.DrawPicture(Image.ListTEX[TEX_POZADIE].texID,0,0,640,480);
	BNew.Redraw();
	BSet.Redraw();
	BAut.Redraw();
	BExt.Redraw();
	Lista.Redraw();
		if(Lista.IsVisible)
		{
			glColor3ub(200,10,10);
			CText.DrawGLText(60-Lista.GoX,112,"            TUNNELER",false);
			glColor3ub(84,188,44);
			CText.DrawGLText(60-Lista.GoX,132,"Naprogramovali:",true);
			glColor3ub(200,200,200);
			CText.DrawGLText(60-Lista.GoX,148,"   Vladimir Hoffman",true);
			CText.DrawGLText(60-Lista.GoX,164,"   Gabriel Gecy",true);
			glColor3ub(84,188,44);
			CText.DrawGLText(60-Lista.GoX,180,"Skolsky rok 2004/2005",true);
			CText.DrawGLText(60-Lista.GoX,196,"   Pocitacova grafika 1",true);
			CText.DrawGLText(60-Lista.GoX,212,"Prednasajuci a vyucujuci:",true);
			glColor3ub(200,200,200);
			CText.DrawGLText(60-Lista.GoX,228,"   Doc.Ing.M.Sujansky,CSc.",true);
			CText.DrawGLText(60-Lista.GoX,244,"   Ing.Marek Straka",true);
			CText.DrawGLText(60-Lista.GoX,260,"   Ing.Branislav Sobota",true);
			glColor3ub(84,188,44);
			CText.DrawGLText(60-Lista.GoX,280,"   Katedra pocitacov",true);
			CText.DrawGLText(60-Lista.GoX,296,"    a informatiky",true);
			CText.DrawGLText(60-Lista.GoX,316,"  FEI TU KOSICE 2005",true);
		};
	Cursor.Redraw();
};
void TMenuClass::Update()
{
	Zvuky.PustiHudbu(Zvuky.HudbaMenu);
	if(BNew.Update() == true)
	{
		Game.SetScreen(Game.InCHOOSE);
	};
	if(BSet.Update() == true)
	{
		Game.SetScreen(Game.InSET);
	};
	if(BAut.Update() == true)
	{
		Lista.IsVisible = true;
		BNew.IsActivated = BSet.IsActivated = BAut.IsActivated = BExt.IsActivated = false;
	};
	if(BExt.Update() == true)
	{
		if(!Profils.SaveProfils())
		{
			MessageBox(NULL,"Nepodarilo sa ulozit profily a nastavenia!","Chyba",MB_OK 
				| MB_ICONERROR);
		}
		TerminateApp();
	};
	if(Lista.Update() == true)
	{
		Lista.IsVisible = false;
		BNew.IsActivated = BSet.IsActivated = BAut.IsActivated = BExt.IsActivated = true;
	};	
};
bool TMenuClass::Init()
{
	BNew.Reset(true,true,true);
	BSet.Reset(true,true,true);
	BAut.Reset(true,true,true);
	BExt.Reset(true,true,true);
	Lista.Reset(false,true,true);
	return true;
};
bool TMenuClass::DeInit()
{	
	return true;
};
//===================================================================< END >=======================