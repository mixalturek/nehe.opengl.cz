/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Implementacia zakladnych funkcii
############################################################################################*/

#include <windows.h>						// hlavickovy subor pre winapi
#include <gl\gl.h>							// hlavickovy subor pre OpenGL
#include <gl\glu.h>							// hlavickovy subor pre Glu
#include <stdio.h>							// standardny vstup / vystup
#include <stdarg.h>							// funkcie s variabilnym poctom argumentov
#include <string.h>							// praca s retazcami
#include "Tuneller.h"						// hlavickovy subor tejto hry
#include "TMakros.h"						// hlavickovy subor s konstantami
//===================================================================< DEFINICIE OBJEKTOV >========
TGameClass		Game;
TInputClass		Input;
TTimeClass		Time;
TProfilClass	Profils;
TZvukyClass		Zvuky;
//===================================================================< TGAMECLASS >=================
TGameClass::TGameClass()
{
	ShowFPS = ShowSXY = false;
	State = LastState = InLOAD;
};
void TGameClass::GlobalKey()
{
	if(Input.Key[VK_F5])						// Ak je stlacene F5 
		TerminateApp();							// Ukon�enie aplikacie
	if(Input.Key[VK_F1] && !Input.ShadeKey[VK_F1])	// Ak je stla�ene F1 
	{
		ToggleFullscreen ();					// Zmena modu fullscreen/window
		Input.ShadeKey[VK_F1] = true;			// Priznak stlacenia
	};
	if(Input.Key[VK_F2] && !Input.ShadeKey[VK_F2])
	{
		Game.ShowFPS = (Game.ShowFPS == true)? false : true;
		Input.ShadeKey[VK_F2] = true;
	}
	if(Input.Key[VK_F3] && !Input.ShadeKey[VK_F3])
	{
		Game.ShowSXY = (Game.ShowSXY == true)? false : true;
		Input.ShadeKey[VK_F3] = true;
	}
}
bool TGameClass::SetScreen(TStateE Screen)		// Nastav nove okno
{
	switch(State)
	{
		case InLOAD:	break;
		case InMENU:	Menu.DeInit(); break;
		case InSET:		Setting.DeInit();	break;
		case InCHOOSE:	Choose.DeInit(); break;
		case InGAME2:	Game2.DeInit(); break;
		case InRESULTS:	Results.DeInit(); break;
	}
	if(Screen == GoBACK)
		State = LastState;
	else
	{
		LastState = State;
		State = Screen;
	}
	switch(State)
	{
		case InLOAD:	break;
		case InMENU:	Menu.Init(); break;
		case InSET:		Setting.Init();	break;
		case InCHOOSE:	Choose.Init(); break;
		case InGAME2:	Game2.Init(); break;
		case InRESULTS:	Results.Init(); break;
	}
	
	return true;
}
bool TGameClass::Init()
{
	Image.BuildTextures();
	CText.CreateFont();
	if(!Skin.CreateList())
		return false;
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);				// cierne pozadie
	glClearDepth(1.0);									// povoli vymazavanie hlbkoveho buffra
	glDepthFunc(GL_LEQUAL);								// typ hlbkoveho testovania
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);// typ blendingu pre alfa kanal z textury
	glShadeModel(GL_SMOOTH);							// hladke tienovanie
	glEnable(GL_TEXTURE_2D);							// povoli texturovanie
	
	SetScreen(InMENU);			//uvodna obrazovka - hlavne menu
	return true;
};
bool TGameClass::Deinit()
{
	Image.KillGLTextures();
	Zvuky.ZastavHudbu(Zvuky.HudbaMenu);
	return true;
};
void TGameClass::ReDraw()					// Prekreslenie scen
{
	switch(State)							// ktoru scenu vykreslujeme
	{
		case InLOAD:	break;
		case InMENU:	Menu.Redraw();break;
		case InSET:		Setting.Redraw();break;
		case InCHOOSE:	Choose.Redraw();break;
		case InRESULTS:	Results.Redraw();break;
		case InGAME2:	Game2.Redraw();break;
	}
	if(ShowFPS)	FPSC.DrawFPS();
	if(ShowSXY) Cursor.Suradnice();
	glFlush();
};
void TGameClass::Update()					// aktualizacia objektov
{
	Game.GlobalKey();
	switch(State)							// pocita sa len pre danu scenu
	{
		case InLOAD:	break;
		case InMENU:	Menu.Update();break;
		case InSET:		Setting.Update();break;
		case InCHOOSE:	Choose.Update();break;
		case InRESULTS:	Results.Update();break;
		case InGAME2:	Game2.Update();break;
	}
}
//===================================================================< PLAYERCLASS >===============
TPlayerClass::TPlayerClass()
{
	SetControls('w','s','a','d','q');
	strcpy(Nick,"");
	CountOfGame = CountOfWins = 0;
	ObrID = 9;
	UI = false;
};
void TPlayerClass::SetControls(int Up,int Down,int Left,int Right,int Fire)
{
	Controls.Up = Up;
	Controls.Down = Down;
	Controls.Left = Left;
	Controls.Right = Right;
	Controls.Fire = Fire;
};
void TPlayerClass::SetControlsNames(char* Up,char* Down,char* Left,char* Right,char* Fire)
{
	strcpy(Controls.UpName,Up);
	strcpy(Controls.DownName,Down);
	strcpy(Controls.LeftName,Left);
	strcpy(Controls.RightName,Right);
	strcpy(Controls.FireName,Fire);
}
//===================================================================< PROFILCLASS >===============
bool TProfilClass::LoadProfils()
{
	Hraci[0].ObrID = 0;
	Hraci[0].UI = true;
	strcpy(Hraci[0].Nick,"UI Predator");
	Hraci[1].ObrID = 1;
	Hraci[1].UI = true;
	strcpy(Hraci[1].Nick,"UI Robocop");
	PocetP = 2;
	
	FILE* handle;
	int i = 2;
	handle=fopen("data\\profiles.dat","rb");
	if(!handle) return false;
	while(fread(&Hraci[i++],sizeof(TPlayerClass),1,handle)==1)
		PocetP++;		//pocet sa zvysi iba pri uspesnom nacitani
	fclose(handle);
	return true;	
};
bool TProfilClass::SaveProfils()
{
	FILE* handle;
	handle=fopen("data\\profiles.dat","wb");
	if(!handle) return false;
	for(int i=2;i<PocetP;i++)
		fwrite(&Hraci[i],sizeof(TPlayerClass),1,handle);			
	fclose(handle);
	return true;
};
//===================================================================< INPUTCLASS >================
TInputClass::TInputClass()
{
	for(int i=0; i<256; i++)
		ShadeKey[i] = Key[i] = false;
	Mouse.LBDown = Mouse.RBDown = false;
	Mouse.LeftB = Mouse.RightB = false;
	Mouse.Showme=true;
}
bool TInputClass::IsMouseIn(int x,int y,int xx,int yy)
{
	return (
	((Input.Mouse.x < x)||(Input.Mouse.x > xx)||(Input.Mouse.y < y )||(Input.Mouse.y > yy))
	? false : true);
}
bool TInputClass::IsMouseInR(int x, int y, int W, int H)
{
	return (
	((Input.Mouse.x < x)||(Input.Mouse.x > x+W)||(Input.Mouse.y < y )||(Input.Mouse.y > y+H))
	? false : true);
}
//================================================================== < ZVUKYCLASS >================
void TZvukyClass::PustiHudbu(THudbaE ktora)
{
	if(!Hudba) return;
	if(ktora == HudbaMenu)	//menu
	{
		if(MusicSec==0) mciSendString("play Data/Sound/title.wav",NULL,0,NULL);
		MusicSec += Time.Sec;
		if(MusicSec >= MUSIC_DURATION)	
		{
			MusicSec = 0;
			mciSendString("stop Data/Sound/title.wav",NULL,0,NULL);
		}
	}
	if(ktora == HudbaGame2)	//game2
	{
		if(MusicInGame2Sec==0) mciSendString("play Data/Sound/pozadie.wav",NULL,0,NULL);
		MusicInGame2Sec += Time.Sec;
		if(MusicInGame2Sec >= MUSICINGAME2_DURATION)
		{
			MusicInGame2Sec = 0;
			mciSendString("stop Data/Sound/pozadie.wav",NULL,0,NULL);
		}
	}
}
void TZvukyClass::ZastavHudbu(THudbaE ktora)
{
	if(ktora == HudbaMenu) 
	{
		mciSendString("stop Data/Sound/title.wav",NULL,0,NULL);
		MusicSec = 0;
		return;
	}
	if(ktora == HudbaGame2) 
	{
		mciSendString("stop Data/Sound/pozadie.wav",NULL,0,NULL);
		MusicInGame2Sec = 0;
		return;
	}
}
void TZvukyClass::PrehrajZvuk(TZvukE ktory)
{
	if(!Zvuky) return;
	if(ktory == swishin) mciSendString("play Data/Sound/swishin.wav",NULL,0,NULL);
	if(ktory == swishout) mciSendString("play Data/Sound/swishout.wav",NULL,0,NULL);
	if(ktory == mouseover) PlaySound("Data/Sound/mouseover.wav",NULL,SND_ASYNC);
	if(ktory == mousedown) PlaySound("Data/Sound/mousedown.wav",NULL,SND_ASYNC);
    if(ktory == swishlock) PlaySound("Data/Sound/swishlock.wav",NULL,SND_ASYNC);	
	if(ktory == psibolt) PlaySound("Data/Sound/shot/blastcan.wav",NULL,SND_ASYNC);
	if(ktory == explosion) mciSendString("play Data/Sound/shot/explo4.wav",NULL,0,NULL);
	if(ktory == koniec) mciSendString("play Data/Sound/shot/tnsfir00.wav",NULL,0,NULL);
}
//===================================================================< END >=======================