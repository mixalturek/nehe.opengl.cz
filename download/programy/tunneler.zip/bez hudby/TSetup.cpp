/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Zavadzanie hry
############################################################################################*/

#include <windows.h>						// hlavickovy subor pre winapi
#include <gl\gl.h>							// hlavickovy subor pre OpenGL
#include <gl\glu.h>							// hlavickovy subor pre Glu
#include <stdio.h>							// standardny vstup / vystup
#include <stdarg.h>							// funkcie s variabilnym poctom argumentov
#include <string.h>							// praca s retazcami
#include "Tuneller.h"						// hlavickovy subor tejto hry
#include "TMakros.h"						// hlavickovy subor s konstantami
//===================================================================< DEFINICIE OBJEKTOV >========
//===================================================================< PREMMENNE >=================
int			GraphMode[4];
//===================================================================< LOADTUNELLER >==============
bool LoadTuneller()
{
	GraphMode[0] = 640;						// sirka
	GraphMode[1] = 480;						// vyska
	GraphMode[2] = 16;						// BPP
	
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_FONT]),"Data/Image/FontARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_BUTTON]),"Data/Image/Button256x60ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_BUTTONSELECT]),"Data/Image/ButtonSelect256x60ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_BUTTONDOLE]),"Data/Image/ButtonD170x90x24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_DIABLO]),"Data/Image/Diablo24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_DRAGON]),"Data/Image/Dragon24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_HOLKA]),"Data/Image/Holka24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_NADPIS]),"Data/Image/Nadpis250x45x24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_PREDATOR]),"Data/Image/Predator24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_SKELET]),"Data/Image/Skelet24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_TIGER]),"Data/Image/Tiger24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_VLK]),"Data/Image/Vlk24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_ROBOCOP]),"Data/Image/Robocop24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_SELMA]),"Data/Image/Selma24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_POZADIE]),"Data/Image/PozadieO24RLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_POZADIEBLACK]),"Data/Image/PozadieB24RLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_DESK1]),"Data/Image/Desk1c24RLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_DESK2]),"Data/Image/Desk2c24RLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_LISTA]),"Data/Image/Lista364x321x24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_PONUKA]),"Data/Image/Ponuka240x333x24ARLE.tga")) return false;
	//if(!Image.LoadTGA(&(Image.ListTEX[TEX_REDTANK]),"Data/Image/Tank2c24ARLE.tga")) return false;
	//if(!Image.LoadTGA(&(Image.ListTEX[TEX_BLUETANK]),"Data/Image/Tank1c24ARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_REDTANK]),"Data/Image/RedTank60x60RLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_BLUETANK]),"Data/Image/BlueTank60x60RLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_LISTAPROF]),"Data/Image/ListaProfARLE.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_KRUZOK1]),"Data/Image/Kruzok/1.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_KRUZOK2]),"Data/Image/Kruzok/2.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_KRUZOK3]),"Data/Image/Kruzok/3.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_KRUZOK4]),"Data/Image/Kruzok/4.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_KRUZOK5]),"Data/Image/Kruzok/5.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_KRUZOK6]),"Data/Image/Kruzok/6.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_KRUZOK7]),"Data/Image/Kruzok/7.tga")) return false;
	if(!Image.LoadTGA(&(Image.ListTEX[TEX_STRELA]),"Data/Image/Star.tga")) return false;
	
	if(!Profils.LoadProfils())
	{
		MessageBox(NULL,"Nepodarilo sa nacitat profily a nastavenia!","Chyba",MB_OK 
			| MB_ICONERROR);   
	}
	return true;
}
//===================================================================< EXITTUNELLER >==============
bool ExitTuneller()
{
	Image.KillRAMImage();
	//Image.KillGLTextures();
	Skin.DestroyList();
	CText.KillFont();
	Profils.SaveProfils();
	return true;
};
//===================================================================< END >=======================