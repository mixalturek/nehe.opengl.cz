/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Praca s obrazkami a texturami
############################################################################################*/

#include <windows.h>						// hlavickovy subor pre winapi
#include <gl\gl.h>							// hlavickovy subor pre OpenGL
#include <gl\glu.h>							// hlavickovy subor pre Glu
#include <stdio.h>							// standardny vstup / vystup
#include <stdarg.h>							// funkcie s variabilnym poctom argumentov
#include <string.h>							// praca s retazcami
#include "Tuneller.h"						// hlavickovy subor tejto hry
#include "TMakros.h"						// hlavickovy subor s konstantami
//===================================================================< DEFINICIE OBJEKTOV >========
TImageClass	Image;
TSkinClass	Skin;
//===================================================================< IMAGECLASS >================
bool TImageClass::AllocateMemmory(Textura *texture,int Width,int Height,int BPP)
{
	texture->width = Width;
    texture->height = Height;
    texture->bpp = BPP;
    texture->imageData = (GLubyte*) malloc( Width * Height * BPP );
    if(texture->imageData == NULL)
		return false;

	return true;
};
bool TImageClass::LoadTGA(Textura *tex,char *filename)		// Load a TGA file
{
	GLubyte uTGAcompare[12] = {0,0,2, 0,0,0,0,0,0,0,0,0};	// Uncompressed TGA Header
	GLubyte cTGAcompare[12] = {0,0,10,0,0,0,0,0,0,0,0,0};	// Compressed TGA Header
	GLubyte TgaHeader[12];									// TGA File Header												// TGA image data
	GLubyte header[6];				// First 6 Useful Bytes From The Header
	GLuint	bytesPerPixel;			// Holds Number Of Bytes Per Pixel Used In The TGA File
	GLuint	imageSize;				// Used To Store The Image Size When Setting Aside Ram
	
	FILE *fTGA = fopen(filename, "rb");						// Open file for reading

	if(fTGA == NULL) return false;
	if(fread(TgaHeader,1,sizeof(TgaHeader),fTGA) != sizeof(TgaHeader))		
		// Attempt to read 12 byte header from file
	{
		if(fTGA != NULL)								// Check to seeiffile is still open
			fclose(fTGA);
		return false;
	}
	if(fread(header, sizeof(header), 1, fTGA) == 0)		// Read TGA header
	{
		if(fTGA != NULL)								// if file is still open
			fclose(fTGA);
		return false;									// Return failular
	}
	tex->width	= header[1] * 256 + header[0];			
	// Determine The TGA Width	(highbyte*256+lowbyte)
	tex->height = header[3] * 256 + header[2];			
	// Determine The TGA Height	(highbyte*256+lowbyte)
	tex->bpp	= header[4];							// Determine the bits per pixel
	
	if((tex->width <= 0)||(tex->height <= 0)||((tex->bpp != 24)&&(tex->bpp != 32)))
	{
		if(fTGA != NULL)													
			// Check if file is still open
			fclose(fTGA);
		return false;									// Return failed
	}
	
	tex->type = ((tex->bpp == 24) ? GL_RGB : GL_RGBA);
	bytesPerPixel = tex->bpp / 8;							
	// Compute the number of BYTES per pixel
	imageSize = bytesPerPixel * tex->width * tex->height;		
	// Compute the total amout ofmemory needed to store data
	tex->imageData = (GLubyte *)malloc(imageSize);
	if(tex->imageData == NULL)									// If no space was allocated
	{
		fclose(fTGA);											// Close the file
		return false;											// Return failed
	}
	if(memcmp(uTGAcompare, TgaHeader, sizeof(TgaHeader)) == 0)		
		// See if header matches the predefined header of 
	{																
		// an Uncompressed TGA image
		if(fread(tex->imageData, 1, imageSize, fTGA) != imageSize)	
			// Attempt to read image data
		{
			if(tex->imageData != NULL)								
				// If imagedata has data in it
				free(tex->imageData);
			fclose(fTGA);											// Close file
			return false;											// Return failed
		};
		for(GLuint cswap=0; cswap<int(imageSize); cswap += bytesPerPixel)
		{
			tex->imageData[cswap] ^= tex->imageData[cswap+2] ^=
			tex->imageData[cswap] ^= tex->imageData[cswap+2];
		}
		fclose(fTGA);												// Close file
		return true;
	}
	else
	if(memcmp(cTGAcompare, TgaHeader, sizeof(TgaHeader)) == 0)		
		// See if header matches the predefined header of
	{																
		// an RLE compressed TGA image
		GLuint pixelcount	= tex->height * tex->width;				
		// Nuber of pixels in the image
		GLuint currentpixel	= 0;									
		// Current pixel being read
		GLuint currentbyte	= 0;									
		// Current byte 
		GLubyte *colorbuffer = (GLubyte *)malloc(bytesPerPixel);	
		// Storage for 1 pixel
		GLubyte chunkheader;

		do
		{
			chunkheader = 0;											
			// Storage for "chunk" header
            if(fread(&chunkheader, sizeof(GLubyte), 1, fTGA) == 0)		
				// Read in the 1 byte header
				goto Chyba;
			if(chunkheader < 128)										
// If the ehader is < 128, it means the that is the number of RAW color packets minus 1
			{															
				// that follow the header
				chunkheader++;											
				// add 1 to get number of following color values
				for(short counter=0; counter<chunkheader; counter++)	
					// Read RAW color values
				{
					if(fread(colorbuffer, 1, bytesPerPixel, fTGA) != bytesPerPixel) 
						// Try to read 1 pixel
						goto Chyba;
					tex->imageData[currentbyte]		= colorbuffer[2];		
					// Flip R and B vcolor values around in the process 
					tex->imageData[currentbyte+1]	= colorbuffer[1];
					tex->imageData[currentbyte+2]	= colorbuffer[0];
					if(bytesPerPixel == 4)									
						// if its a 32 bpp image
					{
						tex->imageData[currentbyte + 3] = colorbuffer[3];	
						// copy the 4th byte
					}
                    currentbyte += bytesPerPixel;							
					// Increase thecurrent byte by the number of bytes per pixel
					currentpixel++;											
					// Increase current pixel by 1
					if(currentpixel > pixelcount)							
						// Make sure we havent read too many pixels
						goto Chyba;
				}
			}
			else																
				// chunkheader > 128 RLE data, next color reapeated chunkheader - 127 times
			{
				chunkheader -= 127;												
				// Subteact 127 to get rid of the ID bit
				if(fread(colorbuffer, 1, bytesPerPixel, fTGA) != bytesPerPixel)	
					// Attempt to read following color values
					goto Chyba;
				for(short counter = 0; counter < chunkheader; counter++)		
					// copy the color into the image data as many times as dictated 
				{																
					// by the header
					tex->imageData[currentbyte]		= colorbuffer[2];			
					// switch R and B bytes areound while copying
					tex->imageData[currentbyte+1]	= colorbuffer[1];
					tex->imageData[currentbyte+2]	= colorbuffer[0];
					if(bytesPerPixel == 4)										
						// If TGA images is 32 bpp
					{
						tex->imageData[currentbyte + 3] = colorbuffer[3];		
						// Copy 4th byte
					}
                    currentbyte += bytesPerPixel;								
					// Increase current byte by the number of bytes per pixel
					currentpixel++;												
					// Increase pixel count by 1
                    if(currentpixel > pixelcount)								
						// Make sure we havent written too many pixels
						goto Chyba;
				}
			}
		}
        while(currentpixel < pixelcount);			// Loop while there are still pixels left
		fclose(fTGA);								// Close the file
		return true;
	}
	else											// If header matches neither type
		return false;
	
	return true;
	//-----------------------
	Chyba:
	if(fTGA != NULL)								// If file is open
		fclose(fTGA);
	if(tex->imageData != NULL)						// If there is stored image data
		free(tex->imageData);
	return false;
}
void TImageClass::DrawPicture(GLuint TextID,int TLX,int TLY,int BRX,int BRY)
{
	glColor3ub(255,255,255);
	glBindTexture(GL_TEXTURE_2D, TextID);					// vyber textury
	glBegin(GL_QUADS);										// Kreslime stvorec
		glTexCoord2f(0.0f,0.0f); glVertex2i(TLX,BRY);		// Bottom Left
		glTexCoord2f(1.0f,0.0f); glVertex2i(BRX,BRY);		// Bottom Right
		glTexCoord2f(1.0f,1.0f); glVertex2i(BRX,TLY);		// Top Right
		glTexCoord2f(0.0f,1.0f); glVertex2i(TLX,TLY);		// Top Left
	glEnd();
};
void TImageClass::KillRAMImage()
{
	for(int i=0; i<TEX_TEXTURE_NUM; i++)
		free(Image.ListTEX[i].imageData);
};
void TImageClass::BuildTextures()
{
	GLuint	type;
	for(int i=0; i<TEX_TEXTURE_NUM; i++)
	{ 
		type = GL_RGBA;
		if (ListTEX[i].bpp==24)								
			type=GL_RGB;									
	
		glGenTextures(1, &ListTEX[i].texID);					// Generuje texturu
		glBindTexture(GL_TEXTURE_2D, ListTEX[i].texID);			// Vybere texturu za aktualnu
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);// Linearne 
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);//	filtrovanie
		// Mipmapovan� textura
		gluBuild2DMipmaps(GL_TEXTURE_2D,type,ListTEX[i].width,ListTEX[i].height,
			type,GL_UNSIGNED_BYTE,ListTEX[i].imageData);
    }
	glGenTextures(1, &Image.VyslednaMapa.texID);			// Generuje texturu
};
void TImageClass::KillGLTextures()
{
	for(int i=0; i<TEX_TEXTURE_NUM; i++)
		glDeleteTextures(1,&Image.ListTEX[i].texID);
};
//===================================================================< SKINCLASS >=================
void TSkinClass::DrawRect(int TLX,int TLY,int BRX,int BRY)
{
	glBegin(GL_LINE_LOOP);			// Kreslime obdlznik
		glVertex2i(TLX,BRY);		// Bottom Left
		glVertex2i(BRX,BRY);		// Bottom Right
		glVertex2i(BRX,TLY);		// Top Right
		glVertex2i(TLX,TLY);		// Top Left
	glEnd();
};
bool TSkinClass::CreateList()
{
	Skin.Base = glGenLists(MGL_LIST_NUM);
	//---------------------------------------------------------------------------------------------
	// CURSOR
	Skin.ListGL[MGL_CURSOR] = Base;
	glNewList(Skin.ListGL[MGL_CURSOR],GL_COMPILE);		
		glDisable(GL_TEXTURE_2D);
		glColor3ub(84,188,44);
		glBegin(GL_TRIANGLES);
			glVertex2i(0,0);
			glVertex2i(7,15);
			glVertex2i(15,7);
		glEnd();
		glColor3ub(0,0,0);
		glBegin(GL_LINE_LOOP);
			glVertex2i(0,0);
			glVertex2i(7,15);
			glVertex2i(15,7);
		glEnd();
		glEnable(GL_TEXTURE_2D);												
	glEndList();
	//---------------------------------------------------------------------------------------------
	// BUTTON
	Skin.ListGL[MGL_BUTTON] = Base + 1;
	glNewList(Skin.ListGL[MGL_BUTTON],GL_COMPILE);
		glBegin(GL_QUADS);									// Kreslime stvorec
			glTexCoord2f(0.0f,0.0f); glVertex2i(0,40);		// Bottom Left
			glTexCoord2f(1.0f,0.0f); glVertex2i(200,40);	// Bottom Right
			glTexCoord2f(1.0f,1.0f); glVertex2i(200,0);		// Top Right
			glTexCoord2f(0.0f,1.0f); glVertex2i(0,0);		// Top Left
		glEnd();
	glEndList();
	//---------------------------------------------------------------------------------------------
	// BUTTOND
	Skin.ListGL[MGL_BUTTOND] = Base + 2;
	glNewList(Skin.ListGL[MGL_BUTTOND],GL_COMPILE);
		glBegin(GL_QUADS);									// Kreslime stvorec
			glTexCoord2f(0.0f,0.0f); glVertex2i(0,90);		// Bottom Left
			glTexCoord2f(1.0f,0.0f); glVertex2i(170,90);	// Bottom Right
			glTexCoord2f(1.0f,1.0f); glVertex2i(170,0);		// Top Right
			glTexCoord2f(0.0f,1.0f); glVertex2i(0,0);		// Top Left
		glEnd();
	glEndList();
	//---------------------------------------------------------------------------------------------
	// LISTA
	Skin.ListGL[MGL_LISTA] = Base + 3;
	glNewList(Skin.ListGL[MGL_LISTA],GL_COMPILE);
		glBegin(GL_QUADS);									// Kreslime stvorec
			glTexCoord2f(0.0f,0.0f); glVertex2i(0,322);		// Bottom Left
			glTexCoord2f(1.0f,0.0f); glVertex2i(364,322);	// Bottom Right
			glTexCoord2f(1.0f,1.0f); glVertex2i(364,0);		// Top Right
			glTexCoord2f(0.0f,1.0f); glVertex2i(0,0);		// Top Left
		glEnd();
	glEndList();
	//---------------------------------------------------------------------------------------------
	// PONUKA
	Skin.ListGL[MGL_PONUKA] = Base + 4;
	glNewList(Skin.ListGL[MGL_PONUKA],GL_COMPILE);
		glBegin(GL_QUADS);									// Kreslime stvorec
			glTexCoord2f(0.0f,0.0f); glVertex2i(0,333);		// Bottom Left
			glTexCoord2f(1.0f,0.0f); glVertex2i(240,333);	// Bottom Right
			glTexCoord2f(1.0f,1.0f); glVertex2i(240,0);		// Top Right
			glTexCoord2f(0.0f,1.0f); glVertex2i(0,0);		// Top Left
		glEnd();
	glEndList();
	//------------------------------------------------------------------------------------------------
	// SIPKAVLAVO
	Skin.ListGL[MGL_SIPKAVLAVO] = Base + 5;
	glNewList(Skin.ListGL[MGL_SIPKAVLAVO],GL_COMPILE);
		glDisable(GL_TEXTURE_2D);
		glBegin(GL_POLYGON);
			glVertex2i(0,13);
			glVertex2i(50,25);
			glVertex2i(40,13);
			glVertex2i(50,0);
		glEnd();
		glEnable(GL_TEXTURE_2D);
	glEndList();
	//---------------------------------------------------------------------------------------------
	// SIPKAVPRAVO
	Skin.ListGL[MGL_SIPKAVPRAVO] = Base + 6;
	glNewList(Skin.ListGL[MGL_SIPKAVPRAVO],GL_COMPILE);
		glDisable(GL_TEXTURE_2D);
		glBegin(GL_POLYGON);
			glVertex2i(50,13);
			glVertex2i(0,0);
			glVertex2i(10,13);
			glVertex2i(0,25);
		glEnd();
		glEnable(GL_TEXTURE_2D);
	glEndList();
	//---------------------------------------------------------------------------------------------
	// LISTAPROF
	Skin.ListGL[MGL_LISTAPROF] = Base + 7;
	glNewList(Skin.ListGL[MGL_LISTAPROF],GL_COMPILE);
		glBegin(GL_QUADS);									// Kreslime stvorec
			glTexCoord2f(0.0f,0.0f); glVertex2i(0,350);		// Bottom Left
			glTexCoord2f(1.0f,0.0f); glVertex2i(350,350);	// Bottom Right
			glTexCoord2f(1.0f,1.0f); glVertex2i(350,0);		// Top Right
			glTexCoord2f(0.0f,1.0f); glVertex2i(0,0);		// Top Left
		glEnd();
	glEndList();
	//---------------------------------------------------------------------------------------------
	// STRELA
	Skin.ListGL[MGL_STRELA] = Base + 8;
	glNewList(Skin.ListGL[MGL_STRELA],GL_COMPILE);
		glBegin(GL_QUADS);									// Kreslime stvorec
			glTexCoord2f(0.0f,0.0f); glVertex2i(-8,8);		// Bottom Left
			glTexCoord2f(1.0f,0.0f); glVertex2i(8,8);	// Bottom Right
			glTexCoord2f(1.0f,1.0f); glVertex2i(8,-8);		// Top Right
			glTexCoord2f(0.0f,1.0f); glVertex2i(-8,-8);		// Top Left
		glEnd();
	glEndList();	
	//---------------------------------------------------------------------------------------------
	// VERTISIPKY
	Skin.ListGL[MGL_VERTISIPKY] = Base + 9;
	glNewList(Skin.ListGL[MGL_VERTISIPKY],GL_COMPILE);
		glDisable(GL_TEXTURE_2D);			
		glBegin(GL_TRIANGLES);
			glColor3ub(255,170,54);
			glVertex2i(580,280);
			glColor3ub(247,94,37);
			glVertex2i(570,310);
			glColor3ub(150,0,0);
			glVertex2i(590,310);
			glColor3ub(247,94,37);
			glVertex2i(590,320);
			glColor3ub(150,0,0);
			glVertex2i(570,320);
			glColor3ub(255,170,54);
			glVertex2i(580,350);
		glEnd();
		glColor3ub(255,255,255);
		glEnable(GL_TEXTURE_2D);
	glEndList();	
	//---------------------------------------------------------------------------------------------
	return true;
};
void TSkinClass::DestroyList()
{
	glDeleteLists(Skin.Base,MGL_LIST_NUM);
}
//===================================================================< END >=======================