/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Konstanty
############################################################################################*/

#ifndef TUNELLER_MAKROS_H
#define TUNELLER_MAKROS_H

#define MUSIC_DURATION			144000	//dlzka hudby v menu v milisekundach kvoli opakovaniu
#define MUSICINGAME2_DURATION	41000	//dlzka hudby v hre v milisekundach kvoli opakovaniu
//===================================================================< IMAGECLASS >================
// LISTY
#define MGL_LIST_NUM				11	//pocet listov
#define MGL_FONT				0		//font
#define MGL_CURSOR				1		//kurzor mysi
#define MGL_BUTTON				2		//hlavne tlacitko
#define MGL_BUTTOND				3		//tlacitko na dolnom okraji obrazovky
#define MGL_LISTA				4		//li�ta nalavo
#define MGL_PONUKA				5		//ponuka napravo
#define	MGL_SIPKAVLAVO			6		//sipka vlavo (vyber profilu)
#define MGL_SIPKAVPRAVO			7		//sipka vpravo (vyber profilu)
#define MGL_LISTAPROF			8		//li�ta nalavo s dvoma tlacitkami
#define MGL_STRELA				9		//strela
#define MGL_VERTISIPKY			10		//vertikalne sipky

// TEXTURY
#define TEX_TEXTURE_NUM				31	//pocet textur
#define TEX_FONT				0		//jednotlive textury:
#define TEX_BUTTON				1
#define TEX_BUTTONSELECT		2
#define	TEX_BUTTONDOLE			3
#define TEX_NADPIS				4
#define TEX_DIABLO				5
#define TEX_DRAGON				6
#define TEX_HOLKA				7
#define TEX_PREDATOR			8
#define TEX_SKELET				9
#define TEX_TIGER				10
#define TEX_VLK					11
#define TEX_ROBOCOP				12
#define TEX_SELMA				13
#define TEX_POZADIE				14
#define TEX_DESK1				15
#define TEX_DESK2				16
#define TEX_LISTA				17
#define TEX_PONUKA				18
#define TEX_POZADIEBLACK		19
#define TEX_REDTANK				20
#define TEX_BLUETANK			21
#define TEX_LISTAPROF			22
#define	TEX_KRUZOK1				23
#define	TEX_KRUZOK2				24
#define	TEX_KRUZOK3				25
#define	TEX_KRUZOK4				26
#define	TEX_KRUZOK5				27
#define	TEX_KRUZOK6				28
#define	TEX_KRUZOK7				29
#define TEX_STRELA				30
//===================================================================< END >=======================

#endif // TUNELLER_MAKROS_H