/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Obrazovka vysledkov
############################################################################################*/

#include <windows.h>						// hlavickovy subor pre winapi
#include <gl\gl.h>							// hlavickovy subor pre OpenGL
#include <gl\glu.h>							// hlavickovy subor pre Glu
#include <stdio.h>							// standardny vstup / vystup
#include <stdarg.h>							// funkcie s variabilnym poctom argumentov
#include <string.h>							// praca s retazcami
#include "Tuneller.h"						// hlavickovy subor tejto hry
//===================================================================< DEFINICIE OBJEKTOV >========
TResultsClass	Results;
//===================================================================< ResultsCLASS >================
TResultsClass::TResultsClass()
{
	BOK.SetMe(440,400,"OK");
	Scroll = 0;
	MapaVisible = true;
};
void TResultsClass::Redraw()
{
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	if(MapaVisible)
	{
		Image.DrawPicture(Image.VyslednaMapa.texID,0,0,640,480);
		BOK.Redraw();
		Cursor.Redraw();
		return;
	}
	Image.DrawPicture(Image.ListTEX[TEX_POZADIEBLACK].texID,0,0,640,480);	
	Image.DrawPicture(Image.ListTEX[TEX_NADPIS].texID,110,30,530,130);
	BOK.Redraw();
	glLoadIdentity();
	if(Profils.PocetP > 7) 
	{
		glCallList(Skin.ListGL[MGL_VERTISIPKY]);
	}
	switch(Vitaz.ObrID)
	{
		case 0: Image.DrawPicture(Image.ListTEX[TEX_PREDATOR].texID,280,120,360,200); break;
		case 1: Image.DrawPicture(Image.ListTEX[TEX_ROBOCOP].texID,280,120,360,200); break;
		case 2: Image.DrawPicture(Image.ListTEX[TEX_DRAGON].texID,280,120,360,200); break;
		case 3: Image.DrawPicture(Image.ListTEX[TEX_HOLKA].texID,280,120,360,200); break;
		case 4: Image.DrawPicture(Image.ListTEX[TEX_DIABLO].texID,280,120,360,200); break;
		case 5: Image.DrawPicture(Image.ListTEX[TEX_SKELET].texID,280,120,360,200); break;
		case 6: Image.DrawPicture(Image.ListTEX[TEX_TIGER].texID,280,120,360,200); break;
		case 7: Image.DrawPicture(Image.ListTEX[TEX_VLK].texID,280,120,360,200); break;
		case 8: Image.DrawPicture(Image.ListTEX[TEX_SELMA].texID,280,120,360,200); break;
		default: break;
	};
	glColor3ub(100,100,200);
	CText.DrawGLTextStred(0,115,640,"VYTAZ:",false);
	glColor3ub(84,188,44);
	CText.DrawGLTextStred(0,225,640,Vitaz.Nick,false);
	glColor3ub(100,100,200);
	CText.DrawGLText(300,250,"Pocet hier:",false);
	CText.DrawGLText(430,250,"Pocet vyhier:",false);
	glColor3ub(200,10,10);
	glDisable(GL_TEXTURE_2D);	
	Skin.DrawRect(25,250,615,390);
	glEnable(GL_TEXTURE_2D);
	char pom[255];
	glScissor(25, 90, 525, 140);
	glEnable(GL_SCISSOR_TEST);
	for(int i=0; i<Profils.PocetP; i++)
	{
		switch(Vsetci[i].ObrID)
		{
			case 0: Image.DrawPicture(Image.ListTEX[TEX_PREDATOR].texID,
						30,270+i*20-Scroll-20,50,270+i*20-Scroll); break;
			case 1: Image.DrawPicture(Image.ListTEX[TEX_ROBOCOP].texID,
						30,270+i*20-Scroll-20,50,270+i*20-Scroll); break;
			case 2: Image.DrawPicture(Image.ListTEX[TEX_DRAGON].texID,
						30,270+i*20-Scroll-20,50,270+i*20-Scroll); break;
			case 3: Image.DrawPicture(Image.ListTEX[TEX_HOLKA].texID,
						30,270+i*20-Scroll-20,50,270+i*20-Scroll); break;
			case 4: Image.DrawPicture(Image.ListTEX[TEX_DIABLO].texID,
						30,270+i*20-Scroll-20,50,270+i*20-Scroll); break;
			case 5: Image.DrawPicture(Image.ListTEX[TEX_SKELET].texID,
						30,270+i*20-Scroll-20,50,270+i*20-Scroll); break;
			case 6: Image.DrawPicture(Image.ListTEX[TEX_TIGER].texID,
						30,270+i*20-Scroll-20,50,270+i*20-Scroll); break;
			case 7: Image.DrawPicture(Image.ListTEX[TEX_VLK].texID,
						30,270+i*20-Scroll-20,50,270+i*20-Scroll); break;
			case 8: Image.DrawPicture(Image.ListTEX[TEX_SELMA].texID,
						30,270+i*20-Scroll-20,50,270+i*20-Scroll); break;
			default: break;
		};
		glColor3ub(84,188,44);
		CText.DrawGLText(55,270+i*20-Scroll,Vsetci[i].Nick,false);
		sprintf(pom,"%d",Vsetci[i].CountOfGame);
		CText.DrawGLText(350,270+i*20-Scroll,pom,false);
		sprintf(pom,"%d",Vsetci[i].CountOfWins);
		CText.DrawGLText(480,270+i*20-Scroll,pom,false);
	}	
	glDisable(GL_SCISSOR_TEST);	
	Cursor.Redraw();
};
void TResultsClass::Update()
{
	Zvuky.PustiHudbu(Zvuky.HudbaMenu);
	if(Input.Key[VK_ESCAPE] && !Input.ShadeKey[VK_ESCAPE])
	{
		Game.SetScreen(Game.InMENU);
	};
	if(MapaVisible)
	{
		if(BOK.Update())
			MapaVisible = false;
		return;
	}
	if(BOK.Update())
	{
		Game.SetScreen(Game.InMENU);
	}
	if(Input.IsMouseInR(570,320,20,30) && Input.Mouse.LeftB && Scroll<(Profils.PocetP-2-7)*20)
	{
		Scroll+=1;		//scrollovanie zoznamu
	}
	if(Input.IsMouseInR(570,280,20,30) && Input.Mouse.LeftB && Scroll>0)
	{
		Scroll-=1;		//scrollovanie zoznamu
	}			
};
bool TResultsClass::Init()
{
	glLoadIdentity();
	Image.DrawPicture(Image.ListTEX[TEX_POZADIEBLACK].texID,0,0,640,480);
	glColor3ub(84,188,44);
	CText.DrawGLTextStred(0,245,640,"LOADING ...",false);
	ReSwapBuffers();
	//---------------------------------------------------------------
	glLoadIdentity();
	Image.DrawPicture(Image.ListTEX[TEX_POZADIEBLACK].texID,0,0,640,480);
	glDisable(GL_TEXTURE_2D);
	float PomerX = float(Game2.MapW) / 600.0;
	float PomerY = float(Game2.MapH) / 400.0;
	for(int i=0; i<600; i++)
		for(int j=0; j<400; j++)
		{
			glColor3ub(	Game2.Mapa[int(i*PomerX)][int(j*PomerY)].R,
						Game2.Mapa[int(i*PomerX)][int(j*PomerY)].G,
						Game2.Mapa[int(i*PomerX)][int(j*PomerY)].B);
			glRecti(20+i,20+j,21+i,21+j);
		}
	glEnable(GL_TEXTURE_2D);
	if(!Image.AllocateMemmory(&Image.VyslednaMapa,640,480,4))
	{
		MessageBox(NULL,"Nedostatok pam�te pre vyslednu mapu!","Chyba",MB_OK | MB_ICONERROR);
		ExitTuneller();
	}
	glReadPixels(0,0,640,480,GL_RGBA,GL_UNSIGNED_BYTE,Image.VyslednaMapa.imageData);
	glBindTexture(GL_TEXTURE_2D, Image.VyslednaMapa.texID);				
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	// Mipmapovan� textura
	gluBuild2DMipmaps(GL_TEXTURE_2D,4,Image.VyslednaMapa.width,Image.VyslednaMapa.height,
		GL_RGBA,GL_UNSIGNED_BYTE,Image.VyslednaMapa.imageData);
	//---------------------------------------------------------------
	BOK.Reset(true,true,true);
	Zvuky.ZastavHudbu(Zvuky.HudbaGame2);
	TPlayerClass pom[100],pom1;
	for(int i=0; i<Profils.PocetP; i++)
		pom[i] = Profils.Hraci[i];
	for(int i=0; i<Profils.PocetP; i++)
	{
		Vsetci[i] = pom[i];
		for(int j=i; j<Profils.PocetP; j++) 
			if(pom[j].CountOfWins > Vsetci[i].CountOfWins)
			{
				pom1 = Vsetci[i];
				Vsetci[i] = pom[j];
				pom[j] = pom1;
			}
	}
	Scroll = 0;

	return true;
};
bool TResultsClass::DeInit()
{
	return true;
};
//===================================================================< END >=======================