/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Obrazovka so samotnou hrou							
############################################################################################*/

#include <windows.h>						// hlavickovy subor pre winapi
#include <gl\gl.h>							// hlavickovy subor pre OpenGL
#include <gl\glu.h>							// hlavickovy subor pre Glu
#include "Tuneller.h"						// hlavickovy subor tejto hry
//===================================================================< DEFINICIE OBJEKTOV >========
TGame2Class	Game2;
//===================================================================< GAME2CLASS >================
TGame2Class::TGame2Class()
{
	MapZoom = 5;
	MapNumW = MapNumH = 8;
	MapW = MapH = TankSize = SubMapW = SubMapH = 0;
	SmuhyTimR = SmuhyTimB = PocWinL = PocWinP = 0;
	PocetVyhier = 3;
	ZnicitelnyDomcek = true;	
	Koniec = VybuchDelay;	
};
void TGame2Class::Redraw()
{
	int R,G;
	TStrelaClass Strela;

	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	Image.DrawPicture(Image.ListTEX[TEX_DESK2].texID,0,0,640,480);
	glDisable(GL_TEXTURE_2D);
	//-----------------------------------------------------
	glLoadIdentity();
	Percent = float(RedLTank.HP*100)/float(TTankClass::MaxTHP);
	G = (Percent <= 50) ? int(2*Percent) : 100;
	R = (Percent >  50) ? int(200-4*(Percent-50)) : 200;
	glColor3ub((GLubyte)R,(GLubyte)G,0);
	if(ZnicitelnyDomcek)
	{
		if(Percent >= 0) glRecti(30,410,int(1.25*Percent)+30,430);
		glColor3ub(150,150,150);
		Skin.DrawRect(30,410,155,430);
		Percent = float(RedLDom.HP*100)/float(TDomcekClass::MaxDHP);
		G = (Percent <= 50) ? int(2*Percent) : 100;
		R = (Percent >  50) ? int(200-4*(Percent-50)) : 200;
		glColor3ub((GLubyte)R,(GLubyte)G,0);
		if(Percent >= 0) glRecti(165,410,int(1.25*Percent)+165,430);
		glColor3ub(150,150,150);
		Skin.DrawRect(165,410,290,430);
	}
	else
	{
		if(Percent >= 0) glRecti(30,410,int(2.6*Percent)+30,430);
		glColor3ub(150,150,150);
		Skin.DrawRect(30,410,290,430);
	}
	Percent = float(RedLTank.Energy*100)/float(TTankClass::MaxTEnergy);
	G = (Percent <= 50) ? int(2*Percent) : 100;
	R = (Percent >  50) ? int(200-4*(Percent-50)) : 200;
	glColor3ub((GLubyte)R,(GLubyte)G,0);
	if(Percent >= 0) glRecti(30,385,int(2.6*Percent)+30,405);
	glColor3ub(150,150,150);
	Skin.DrawRect(30,385,290,405);
	//-----------------------------------------------------
	glScissor(30,150,260,300);
	glEnable(GL_SCISSOR_TEST);
	glLoadIdentity();
	glTranslatef((float)30,(float)30,(float)0);
	if(((Percent <= 25)&&(rand()%(int(Percent)<5 ? 5:int(Percent)) == 1))||(SmuhyTimR >0))
	{
		if(SmuhyTimR <= 0) SmuhyTimR = SmuhyC;
		else SmuhyTimR -= Time.Sec;
		for(i=0; i<SubMapW; i++)
			for(j=0; j<SubMapH; j++)
			{
				GLubyte Seda = GLubyte( rand()%250 );
				glColor3ub(Seda,Seda,Seda);
				glRecti(i*MapZoom,j*MapZoom,(i+1)*MapZoom,(j+1)*MapZoom);
			}
	}
	else
	{
		for(i=0, Tx=(RedLTank.x-SubMapW/2); i<SubMapW; i++,Tx++)
			for(j=0, Ty=(RedLTank.y-SubMapH/2); j<SubMapH; j++,Ty++)
			{
				glColor3ub(Mapa[Tx][Ty].R,Mapa[Tx][Ty].G,Mapa[Tx][Ty].B);
				glRecti(i*MapZoom,j*MapZoom,(i+1)*MapZoom,(j+1)*MapZoom);
			}
	
		glEnable(GL_TEXTURE_2D);
		glLoadIdentity();
		glTranslatef((float)160+(BluePTank.x-RedLTank.x)*MapZoom,
			(float)180+(BluePTank.y-RedLTank.y)*MapZoom,(float)0);
		BluePTank.Redraw();
		glLoadIdentity();
		glTranslatef((float)160,(float)180,(float)0);
		RedLTank.Redraw();

		for(int i=0; i<int(Strely.RedSee.size()); i++)		
		{
			Strela = Strely.RedSee.front();
			Strely.RedSee.pop();
			glLoadIdentity();
			glTranslatef((float)160-(RedLTank.x-Strela.x)*MapZoom,
				(float)180-(RedLTank.y-Strela.y)*MapZoom,(float)0);
			Strela.Redraw();
			Strely.RedSee.push(Strela);
		}
		glDisable(GL_TEXTURE_2D);
	}
	glDisable(GL_SCISSOR_TEST);
	//-----------------------------------------------------
	glLoadIdentity();
	Percent = float(BluePTank.HP*100)/float(TTankClass::MaxTHP);
	G = (Percent <= 50) ? int(2*Percent) : 100;
	R = (Percent >  50) ? int(200-4*(Percent-50)) : 200;
	glColor3ub((GLubyte)R,(GLubyte)G,0);
	if(ZnicitelnyDomcek)
	{
		if(Percent >= 0) glRecti(350,410,int(1.25*Percent)+ 350,430);
		glColor3ub(150,150,150);
		Skin.DrawRect(350,410,475,430);
		Percent = float(BluePDom.HP*100)/float(TDomcekClass::MaxDHP);
		G = (Percent <= 50) ? int(2*Percent) : 100;
		R = (Percent >  50) ? int(200-4*(Percent-50)) : 200;
		glColor3ub((GLubyte)R,(GLubyte)G,0);
		if(Percent >= 0) glRecti(485,410,int(1.25*Percent)+485,430);
		glColor3ub(150,150,150);
		Skin.DrawRect(485,410,610,430);
	}
	else
	{
		if(Percent >= 0) glRecti(350,410,int(2.6*Percent)+ 350,430);
		glColor3ub(150,150,150);
		Skin.DrawRect(350,410,610,430);
	}
	Percent = float(BluePTank.Energy*100)/float(TTankClass::MaxTEnergy);
	G = (Percent <= 50) ? int(2*Percent) : 100;
	R = (Percent >  50) ? int(200-4*(Percent-50)) : 200;
	glColor3ub((GLubyte)R,(GLubyte)G,0);
	if(Percent >= 0) glRecti(350,385,int(2.6*Percent)+350,405);
	glColor3ub(150,150,150);
	Skin.DrawRect(350,385,610,405);	
	//-----------------------------------------------------
	glScissor(350,150,260,300);	
	glEnable(GL_SCISSOR_TEST);
	glLoadIdentity();
	glTranslatef((float)350,(float)30,(float)0);
	if(((Percent <= 25)&&(rand()%(int(Percent)<5 ? 5:int(Percent)) == 0))||(SmuhyTimB >0))
	{
		if(SmuhyTimB <= 0) SmuhyTimB = SmuhyC;
		else SmuhyTimB -= Time.Sec;
		for(i=0; i<SubMapW; i++)
			for(j=0; j<SubMapH; j++)
			{
				GLubyte Seda = GLubyte( rand()%250 );
				glColor3ub(Seda,Seda,Seda);
				glRecti(i*MapZoom,j*MapZoom,(i+1)*MapZoom,(j+1)*MapZoom);
			}
	}
	else
	{
		for(i=0, Tx=(BluePTank.x-SubMapW/2); i<SubMapW; i++,Tx++)
			for(j=0, Ty=(BluePTank.y-SubMapH/2); j<SubMapH; j++,Ty++)
			{
				glColor3ub(Mapa[Tx][Ty].R,Mapa[Tx][Ty].G,Mapa[Tx][Ty].B);
				glRecti(i*MapZoom,j*MapZoom,(i+1)*MapZoom,(j+1)*MapZoom);
			}
	
		glEnable(GL_TEXTURE_2D);
		glLoadIdentity();
		glTranslatef((float)480+(RedLTank.x-BluePTank.x)*MapZoom,
			(float)180+(RedLTank.y-BluePTank.y)*MapZoom,(float)0);
		RedLTank.Redraw();
		glLoadIdentity();
		glTranslatef((float)480,(float)180,(float)0);	 
		BluePTank.Redraw();

		for(int i=0; i<int(Strely.BluSee.size()); i++)		
		{
			Strela = Strely.BluSee.front();
			Strely.BluSee.pop();
			glLoadIdentity();
			glTranslatef((float)480-(BluePTank.x-Strela.x)*MapZoom,
				(float)180-(BluePTank.y-Strela.y)*MapZoom,(float)0);
			Strela.Redraw();
			Strely.BluSee.push(Strela);
		}
		glDisable(GL_TEXTURE_2D);
	}
	glDisable(GL_SCISSOR_TEST);
	//-----------------------------------------------------
	glEnable(GL_TEXTURE_2D);
	char p[15];
	glColor3ub(100,100,200);
	sprintf(p,"Wins: %d",PocWinL);
	CText.DrawGLTextStred(30,370,260,p,false);
	sprintf(p,"Wins: %d",PocWinP);
	CText.DrawGLTextStred(350,370,260,p,false);
	//glColor3ub(150,150,0);
	glColor3ub(255,200,0);
	if(ZnicitelnyDomcek)
	{
		CText.DrawGLTextStred(350,425,125,"TANK HP",false);
		CText.DrawGLTextStred(485,425,125,"FORT HP",false);
		CText.DrawGLTextStred(30,425,125,"TANK HP",false);
		CText.DrawGLTextStred(165,425,125,"FORT HP",false);
	}
	else
	{
		CText.DrawGLTextStred(30,425,260,"TANK HP",false);
		CText.DrawGLTextStred(350,425,260,"TANK HP",false);
	}
	CText.DrawGLTextStred(350,400,260,"ENERGY",false);
	CText.DrawGLTextStred(30,400,260,"ENERGY",false);
};
void TGame2Class::Update()
{
	Zvuky.PustiHudbu(Zvuky.HudbaGame2);
	if(Input.Key[VK_ESCAPE] && !Input.ShadeKey[VK_ESCAPE])
	{
		Game.SetScreen(Game.InMENU);
	};
	Strely.Update();
	RedLTank.Update();
	BluePTank.Update();
	RedLDom.AtFortres(&BluePTank);
	BluePDom.AtFortres(&RedLTank);
	if((RedLTank.Energy <= 0)||(RedLTank.HP <= 0)||(RedLDom.HP <= 0))
	{		
		if(!RedLTank.Vybuch)
		{
			int Sx, Sy, Smer;
			for(int i=-5; i<6; i++)
				if(i!=0 && i!=4 && i!=-4)
                    for(int j=0; j<3; j++)
					{
						Smer = i;
						Sx = RedLTank.x; Sy = RedLTank.y;
						Strely.AddShoot(Sx,Sy,Smer,RedLTank.ID);
					}
			Zvuky.PrehrajZvuk(Zvuky.explosion);
			RedLTank.Vybuch = true;
		}		
		Koniec -= Time.Sec;		
		if(Koniec < 0)
		{
			RedLDom.Reset();
			BluePDom.Reset();
			PocWinP++;
			Koniec = VybuchDelay;
			RedLTank.Vybuch = false;
			BluePTank.Vybuch = false;			
		}
	}
	if((BluePTank.Energy <= 0)||(BluePTank.HP <= 0)||(BluePDom.HP <= 0))
	{		
		if(!BluePTank.Vybuch)
		{
			int Sx, Sy, Smer;
			for(int i=-5;i<6;i++)
				if(i!=0 && i!=4 && i!=-4)
                    for(int j=0;j<3;j++)
					{
						Smer = i;
						Sx = BluePTank.x; Sy = BluePTank.y;
						Strely.AddShoot(Sx,Sy,Smer,BluePTank.ID);
					}
			Zvuky.PrehrajZvuk(Zvuky.explosion);
			BluePTank.Vybuch = true;
		}
		Koniec -= Time.Sec;		
		if(Koniec < 0)
		{
			RedLDom.Reset();
			BluePDom.Reset();
			PocWinL++;
			Koniec = VybuchDelay;
			RedLTank.Vybuch = false;
			BluePTank.Vybuch = false;
		}
	}	
	if(PocWinL == PocetVyhier)
	{		
		Profils.RedLPlayer.CountOfWins++;
		Profils.BluePPlayer.CountOfGame++;
		Profils.RedLPlayer.CountOfGame++;
		Results.Vitaz = Profils.RedLPlayer;
	}
	else
	if(PocWinP == PocetVyhier)
	{
		Profils.BluePPlayer.CountOfWins++;
		Profils.BluePPlayer.CountOfGame++;
		Profils.RedLPlayer.CountOfGame++;
		Results.Vitaz = Profils.BluePPlayer;
	}
	if(PocWinL == PocetVyhier || PocWinP == PocetVyhier)
	{
		Profils.Hraci[Profils.RPL] = Profils.RedLPlayer;
		Profils.Hraci[Profils.BPL] = Profils.BluePPlayer;
		Zvuky.PrehrajZvuk(Zvuky.koniec);
		Game.SetScreen(Game.InRESULTS);
	}		
};
bool TGame2Class::Init()
{
	//glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	Image.DrawPicture(Image.ListTEX[TEX_POZADIEBLACK].texID,0,0,640,480);
	glColor3ub(84,188,44);
	CText.DrawGLTextStred(0,245,640,"LOADING ...",false);
	ReSwapBuffers();
	//------------------------------------------->> zrusenie starej mapy <<----
	if(Mapa != NULL)
	{	
		for(int k=MapW-1; k>=0; k--)
		{
			if(Mapa[k] != NULL)
				free(Mapa[k]);
		}
		free(Mapa);
	}
	//------------------------------------------->> Loading MAPY <<------
	MapW = MapNumW * 260/MapZoom;
	MapH = MapNumH * 300/MapZoom;
	TankSize = (40/MapZoom);
	SubMapW = 260/MapZoom;
	SubMapH = 300/MapZoom;
	LoopC = 10/MapZoom;
	PohybTimC = float(PohybDelayC)/float(TankSize * LoopC);
	VrtTimC = float(VrtDelayC)/float(TankSize * LoopC);
	LossEnergyC = float(MapZoom)/float(LoopC);	
	Koniec = VybuchDelay;

	Mapa = (Farba**) malloc (sizeof(FarbaPtr) * MapW);
	if(Mapa == NULL)
	{
		MessageBox(NULL,"Nedostatok pam�te!","Chyba",MB_OK | MB_ICONERROR);
		ExitTuneller();
	}
	for(int k=0; k<MapW; k++)
	{
		Mapa[k] = (Farba*) malloc(sizeof(Farba) * MapH);
		if(Mapa[k] == NULL)
		{
			MessageBox(NULL,"Nedostatok pam�te!","Chyba",MB_OK | MB_ICONERROR);
			ExitTuneller();
		}
	}
	
	srand(Time.Sec);
	for(i=0; i<MapW; i++)
		for(j=0; j<MapH; j++)
		{	 
			if( (i<SubMapW/2) || (i>=(MapW-SubMapW/2)) ||
				(j<SubMapH/2) || (j>=(MapH-SubMapH/2)))
			{
				UCHAR Incre = UCHAR( 75 + rand()%20 );
				Mapa[i][j].R = Mapa[i][j].G = Mapa[i][j].B = Incre;
				Mapa[i][j].I = 2;
			}
			else
			{
				Mapa[i][j].R = UCHAR( 160+rand()%20 );
				Mapa[i][j].G = UCHAR( 140+rand()%20 );
				Mapa[i][j].B = UCHAR( 100+rand()%20 );
				Mapa[i][j].I = 1;
			}
		};
	//ZLAVA
	int Pocet;
	for(Pocet=30,i=0; i<(MapH-SubMapH); i++)
	{
		Pocet += (rand()%5 - rand()%5);
		if(Pocet<0) Pocet = 0;
		if(Pocet>SubMapW) Pocet = SubMapW;
		for(j=0; j<Pocet; j++)
		{
			UCHAR Incre = UCHAR( 75 + rand()%20 );
			Mapa[SubMapW/2+j][SubMapH/2+i].R = Incre;
			Mapa[SubMapW/2+j][SubMapH/2+i].G = Incre;
			Mapa[SubMapW/2+j][SubMapH/2+i].B = Incre;
			Mapa[SubMapW/2+j][SubMapH/2+i].I = 2;
		}
	}
	//SPRAVA
	for(Pocet=10,i=0; i<(MapH-SubMapH); i++)
	{
		Pocet += (rand()%5 - rand()%5);
		if(Pocet<0) Pocet = 0;
		if(Pocet>SubMapW) Pocet = SubMapW;
		for(j=0; j<Pocet; j++)
		{
			UCHAR Incre = UCHAR( 75 + rand()%20 );
			Mapa[MapW-SubMapW/2-j][SubMapH/2+i].R = Incre;
			Mapa[MapW-SubMapW/2-j][SubMapH/2+i].G = Incre;
			Mapa[MapW-SubMapW/2-j][SubMapH/2+i].B = Incre;
			Mapa[MapW-SubMapW/2-j][SubMapH/2+i].I = 2;
		}
	}
	//ZHORA
	for(Pocet=10,i=0; i<(MapW-SubMapW); i++)
	{
		Pocet += (rand()%5 - rand()%5);
		if(Pocet<0) Pocet = 0;
		if(Pocet>SubMapH) Pocet = SubMapH;
		for(j=0; j<Pocet; j++)
		{
			UCHAR Incre = UCHAR( 75 + rand()%20 );
			Mapa[SubMapW/2+i][SubMapH/2+j].R = Incre;
			Mapa[SubMapW/2+i][SubMapH/2+j].G = Incre;
			Mapa[SubMapW/2+i][SubMapH/2+j].B = Incre;
			Mapa[SubMapW/2+i][SubMapH/2+j].I = 2;
		}
	}
	//ZDOLA
	for(Pocet=10,i=0; i<(MapW-SubMapW); i++)
	{
		Pocet += (rand()%5 - rand()%5);
		if(Pocet<0) Pocet = 0;
		if(Pocet>SubMapH) Pocet = SubMapH;
		for(j=0; j<Pocet; j++)
		{
			UCHAR Incre = UCHAR( 75 + rand()%20 );
			Mapa[SubMapW/2+i][MapH-SubMapH/2-j].R = Incre;
			Mapa[SubMapW/2+i][MapH-SubMapH/2-j].G = Incre;
			Mapa[SubMapW/2+i][MapH-SubMapH/2-j].B = Incre;
			Mapa[SubMapW/2+i][MapH-SubMapH/2-j].I = 2;
		}
	}
	//------------------------------------------->>
    RedLDom.ID = 0;
	BluePDom.ID = 1;
	RedLDom.VrtajDomcek(&RedLTank,NULL);
	BluePDom.VrtajDomcek(&BluePTank,&RedLDom);
	RedLDom.Reset();
	BluePDom.Reset();
	///
	//RedLTank.x = BluePTank.x = RedLTank.y = 100;	
	//BluePTank.y = 120; 
	///
	RedLTank.SetOwner(&Profils.RedLPlayer);
	BluePTank.SetOwner(&Profils.BluePPlayer);
	RedLTank.SetEnemy(&BluePTank);
	BluePTank.SetEnemy(&RedLTank);
	PocWinL = PocWinP = 0;
	Zvuky.ZastavHudbu(Zvuky.HudbaMenu);	
	
	return true;
};
bool TGame2Class::DeInit()
{
	Zvuky.ZastavHudbu(Zvuky.HudbaGame2);
	return true;
};
//===================================================================< END >=======================