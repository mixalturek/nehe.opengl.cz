/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Winapi a obsluha sprav, inicializacia
############################################################################################*/

#include <windows.h>						// hlavickovy subor pre winapi
#include <gl\gl.h>							// hlavickovy subor pre OpenGL
#include <gl\glu.h>							// hlavickovy subor pre Glu
#include <stdlib.h>
#include "Tuneller.h"						// hlavickovy subor tejto hry

#pragma comment( lib, "opengl32.lib" )	// Prilinkovanie kni�nice pre OpenGL
#pragma comment( lib, "glu32.lib" )		// Prilinkovanie kni�nice pre Glu
#pragma comment( lib, "winmm.lib" )		// Prilinkovanie kni�nice pre Windows Multimedia

#define WM_TOFULL (WM_USER + 1)			// Vlastn� spr�va proced�re okna pre zmenu Fullscreen/Window

//===================================================================< DEFINITIONS >===============
typedef struct							// �trukt�ra pre uchovanie v�etk�ch glob�lnych premenn�ch
{
	HINSTANCE	hINST;					// In�tancia
	HWND		hWND;					// Handle okna
	HDC			hDC;					// Device Contex
	HGLRC		hRC;					// Rendering Context
	const char	*ClassName;				// Meno triedy
	char		*Title;					// Titulok Okna
	int			Width;					// ��rka okna
	int			Height;					// H�bka okna
	int			BPP;					// po�et bitov na pixel
	bool		IsFullScreen;			// Pr�znak Fullscreen/window
	bool		IsVisible;				// Pr�znak vidite�nosti
} WinStruct;

static WinStruct	Win;
static bool			ProgGO;				// Glob�lne premenn� pre riadenie cyklu programu
static bool			GoFullScreen;		// Glob�lna premenn� pre riadenie zmeny fullscreen/window

LRESULT CALLBACK WindowProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
//===================================================================< TERMINATEAPP >==============
void TerminateApp()							// Ukon�� program
{
	PostMessage (Win.hWND, WM_QUIT, 0, 0);	// Po�le spr�vu WM_QUIT, ktorou sa ukon�� cyklus spr�v
	ProgGO = false;							// Ukon�� aj cyklus programu
}
//===================================================================< RESIZESCENE >===============
void ResizeScene (int width, int height)
{	
	if(height == 0) height=1;
	glViewport (0, 0, (GLsizei)(width), (GLsizei)(height));
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	glOrtho(0, width , height, 0, -1, 1);
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity ();
}
//===================================================================< CHANGESCREENRESOLUTION >====
bool ChangeScreenResolution (int width, int height, int bitsPerPixel) // Zmen� rozl�enie obrazovky
{
	// Tento podprogram vytvor� vlastn� m�d, v ktorom nastav� svoje po�iadavky a nech� syst�mu
	// vybra� vhodn� rozl�enie
	DEVMODE ScreenDM;									// Device Mode
	ZeroMemory (&ScreenDM, sizeof (DEVMODE));			// Znuluje pame�
	ScreenDM.dmSize				= sizeof (DEVMODE);		// Nastav� ve�kos� �trukt�ry
	ScreenDM.dmPelsWidth		= width;				// Nastav� po�adovan� ��rku
	ScreenDM.dmPelsHeight		= height;				// Nastav� po�adovan� h�bku
	ScreenDM.dmBitsPerPel		= bitsPerPixel;			// Nastav� po�et bitov na pixel
	ScreenDM.dmFields			= DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
														// Pr�znaky ukazuj�ce, ktor� veci chceme nastavi�
	if (ChangeDisplaySettings (&ScreenDM, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
		return false;									// Po�adovan� nastavenie zlyhalo
	return true;										// Po�adovan� nastavenie je OK
}
//===================================================================< DESTROYGLWIN >==============
bool DestroyGLWin()										// Zru�� vytvoren� okno a uvoln� jeho zdroje
{
	if (Win.hWND != 0)									// Ak okno m� "Handle"
	{	
		if (Win.hDC != 0)								// Ak okno m� "Device Context"
		{
			wglMakeCurrent (Win.hDC, 0);				// Nastav aktu�lny "Rendering Context" na nulu
			if (Win.hRC != 0)							// Ak okno m� "Rendering Context"
			{
				wglDeleteContext (Win.hRC);				// Uvolni "Rendering Context"
				Win.hRC = 0;							// Nastav "Rendering Context" na nulu
			}
			ReleaseDC (Win.hWND, Win.hDC);				// Uvolni "Device Context"
			Win.hDC = 0;								// Nastav "Device Context" na nulu
		}
		DestroyWindow (Win.hWND);						// Zru� okno
		Win.hWND = 0;									// Nastav "Handle" na nulu
	}
	if (Win.IsFullScreen)								// Ak sme vo Fullscreen mode	
		ChangeDisplaySettings(NULL, 0);					// Zmen�me na p�vodn� nastavenie
	ShowCursor(true);
	return true;										// V�etko OK
}
//===================================================================< CREATEGLWIN >===============
bool CreateGLwin()										// Vytvor� okno
{
	//DWORD windowStyle = WS_OVERLAPPEDWINDOW;			// Defin�cia Window �t�lu 
	DWORD windowStyle = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX ;
														// Defin�cia Window roz�iruj�ceho �t�lu
	DWORD windowExtendedStyle = WS_EX_APPWINDOW|WS_EX_WINDOWEDGE;	
	ShowCursor(FALSE);									// Zak�e kurzor
	PIXELFORMATDESCRIPTOR pfd =							// Vytvor�me vlastn� PFD, kde nastav�me svoje po�iadavky
	{
		sizeof (PIXELFORMATDESCRIPTOR),					// Nastav�me ve�kos� �trukt�ry
		1,												// ��slo verzie (default)
		PFD_DRAW_TO_WINDOW |							// Chceme podporu kreslenia do okna
		PFD_SUPPORT_OPENGL |							// Chceme podporu OpenGL
		PFD_DOUBLEBUFFER,								// Chceme podporu Double Buffering
		PFD_TYPE_RGBA,									// Chceme RGBA form�t
		BYTE(Win.BPP),									// Nastavenie bitov na pixel
		0, 0, 0, 0, 0, 0,								// Farebnost� biti s� ignorovan�
		0,												// Nechceme Alpha Buffer
		0,												// Ignorovan� Shift Bit
		0,												// Nechceme Accumulation Buffer
		0, 0, 0, 0,										// Ignorovan� Accumulation Bits
		16,												// Chceme 16Bit Z-Buffer (Depth Buffer)  
		0,												// Nechceme Stencil Buffer
		0,												// Nechceme Auxiliary Buffer
		PFD_MAIN_PLANE,									// Hlavna vrstva kreslenia
		0,												// Rezervovan�
		0, 0, 0											// Ignorovan� Layer Masks
	};
	
	RECT windowRect = {0,0,Win.Width,Win.Height};		// Definujeme poz�ciu a rozmery okna
	int PixelFormat;									// Premenn� pre vhodn� Pixel Format
	if (Win.IsFullScreen)								// Ak treba nastavy� Fullscreen
	{
		if (ChangeScreenResolution (Win.Width,Win.Height,Win.BPP) == FALSE)
		{
			// FullScreen mod zlyhal, ozn�mime to a vr�time sa do window m�du
			MessageBox (HWND_DESKTOP,"Zmena m�du zlyhala.\nNastavuje sa Windows m�d.","Error", MB_OK | MB_ICONEXCLAMATION);
			Win.IsFullScreen = FALSE;					// Nastav�me window m�d
		}
		else											// Ak je fullScreen m�d OK
		{
			windowStyle = WS_POPUP;						// Nastav�me Window �t�l na Popup
			windowExtendedStyle |= WS_EX_TOPMOST;		// Prid�me pr�znak do roz�iruj�ceho �t�lu
		}												// (Top Window je nad ostatn�mi)
	}
	else												// Ak sa po�aduje window m�d
	{
		// Pridanie okna s na�imi nastaveniami (pri fullscreen to ni� nerob�)
		AdjustWindowRectEx (&windowRect, windowStyle, 0, windowExtendedStyle);
	}
	// Vytvorenie okna pomocou funkcie CreateWindowEx()
	Win.hWND = CreateWindowEx  (windowExtendedStyle,	// Roz��ren� �t�l
								Win.ClassName,			// Meno triedy
								Win.Title,				// Titulok okna
								windowStyle,			// Window �t�l
								CW_USEDEFAULT,			// Window X poz�cia
								CW_USEDEFAULT,			// Window Y poz�cia
								windowRect.right - windowRect.left,	// Window Width
								windowRect.bottom - windowRect.top,	// Window Height
								HWND_DESKTOP,			// Rodi�om okna je Desktop
								0,						// �iadne menu
								Win.hINST,				// In�tancia okna
								NULL);					// �iadny parameter to WM_CREATE

	if (Win.hWND == 0)									// Bolo okno vytvoren�
		return !(DestroyGLWin());
	
	Win.hDC = GetDC (Win.hWND);							// Vytvorenie "Device Context"
	if (Win.hDC == 0)									// Ak nebolo vytvoren�
		return !(DestroyGLWin());
	
    PixelFormat = ChoosePixelFormat(Win.hDC, &pfd);		// Nech�me syst�m n�js� vhodn� rozl�enie (PF)
	if (PixelFormat == 0)								// Ak sa nena�lo
		return !(DestroyGLWin());

	if (SetPixelFormat (Win.hDC, PixelFormat, &pfd) == FALSE)	// Pok�sime sa nastavi� rozl�enie (PF)
		return !(DestroyGLWin());

	Win.hRC = wglCreateContext (Win.hDC);				// Pok�sime sa vytvori� "Rendering Context"
	if (Win.hRC == 0)									// Ak sa nevytvoril 
		return !(DestroyGLWin());

	if (wglMakeCurrent (Win.hDC, Win.hRC) == FALSE)		// Prepoj�me "Device Context" a "Rendering Context"
		return !(DestroyGLWin());

	Win.IsVisible = false;								// Nastav�me pr�znak vidite�nosti
	ResizeScene (Win.Width, Win.Height);				// Nastav�me rozmery
	ShowCursor(false);									// Znevidite�n�me kurzor

	return true;										// Okno bolo vytvoren� OK
}
//===================================================================< REGISTERWINDOWCLASS >=======
bool RegisterWindowClass ()								// Zaregistruje na�e okno
{																		
	WNDCLASSEX windowClass;												// Window Class
	ZeroMemory (&windowClass, sizeof (WNDCLASSEX));						// Znulujeme pame�
	windowClass.cbSize			= sizeof (WNDCLASSEX);					// Nastav�me ve�kos� �trukt�ry
	windowClass.style			= CS_OWNDC | CS_HREDRAW | CS_VREDRAW;	// Prekreslenia pri pohybe/zmene
	windowClass.lpfnWndProc		= (WNDPROC)(WindowProc);				// Funkcia spracovania spr�v
	windowClass.hInstance		= Win.hINST;							// Nastav�me in�tanciu okna
	windowClass.hIcon			= LoadIcon(NULL, IDI_APPLICATION );
	windowClass.hbrBackground	= (HBRUSH)(COLOR_APPWORKSPACE);			// Farba pozadia
	windowClass.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Nastav�me kurzor
	windowClass.lpszClassName	= Win.ClassName;						// Nastav�me meno triedy
	if (RegisterClassEx (&windowClass) == 0)							// Pok�sime sa zaregistrova�
		return false;									// Nepodarilo sa zaregistrova�
	return true;										// Registr�cia je OK
}
//===================================================================< TOGGLEFULLSCREEN >==========
void ToggleFullscreen()								// Glob�lna funkcia pre zmenu Fullscreen/window
{
 	PostMessage (Win.hWND, WM_TOFULL, 0, 0);		// V�etko potrebn� sa vykon� v spr�ve WM_TOFULL
}
//===================================================================< RESWAPBUFFERS >=============
void ReSwapBuffers()								// Glob�lna funkcia pre prekreslenia bufrov
{
	SwapBuffers(Win.hDC);
}
//===================================================================< WINDOWPROC >================
LRESULT CALLBACK WindowProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)										// Zist�me typ spr�vy
	{	
		case WM_ERASEBKGND:								// Okno chce smaza� pozadie
			return 0;									// Z�kaz mazania (prevencia blikania)
		case WM_SYSCOMMAND:								// Intercept System Commands
			{
				switch (wParam)							// Skontrolujeme podtyp
				{                                           
					case SC_SCREENSAVE:					// System chce nahodi� �etri� obrazovky
					case SC_MONITORPOWER:				// System chce nahodi� �sporn� re�im
					return 0;							// Zabr�nime vtom
				}
				break;
			}
			break;
        case WM_CLOSE:									// Aplik�cia sa m� ukon�i�
			TerminateApp();								
			return 0;
        case WM_SIZE:									// Ve�kos� okna bola zmenen�
			switch (wParam)								// Kontrola podtypu zmeny
			{
				case SIZE_MINIMIZED:					// Okno bolo minimalizovan�
					Win.IsVisible = false;				// Nastav�me pr�znak vidite�nosti
					return 0;								
				case SIZE_MAXIMIZED:					// Okno bolo maximalizovan�
					Win.IsVisible = true;				// Nastav�me pr�znak vidite�nosti
					ResizeScene (LOWORD (lParam), HIWORD (lParam));	
														// Zmen�me rozmery sc�ny LoWord=Width, HiWord=Height
					return 0;								
				case SIZE_RESTORED:						// Ve�kos� okna bola zmenen�
					Win.IsVisible = true;				// Nastav�me pr�znak vidite�nosti
					ResizeScene (LOWORD (lParam), HIWORD (lParam));
														// Zmen�me rozmery sc�ny LoWord=Width, HiWord=Height
					return 0;								
			}
			break;											
        case WM_KEYDOWN:								// Bola stla�en� kl�vesa
			if ((wParam >= 0) && (wParam <= 255))		// Kontrola rozsahu
			{
				(wParam == 255) ? Input.VirtualKey = 0 : Input.VirtualKey = (int)wParam;
				Input.Key[wParam] = true;				// Nastav�me pr�znak stla�enia pre dan� kl�vesu
				GetKeyNameText((long)lParam,Input.KeyName,12);				

				return 0;								
			}
			break;											
        case WM_KEYUP:									// Bola uvolnen� kl�vesa
			if ((wParam >= 0) && (wParam <= 255))		// Kontrola rozsahu
			{
				Input.VirtualKey = 0;
				Input.Key[wParam] = false;				// Nastav�me pr�znak stla�enia pre dan� kl�vesu
				Input.ShadeKey[wParam] = false;			// Nastav�me pr�znak opakovan�ho stla�enia
				
				return 0;								
			}
			break;
		case WM_CHAR:
			if((wParam >= 0) && (wParam <= 255))
			{
				Input.InputChar = (char) wParam;				
			}
			break;
		case WM_TOFULL:									// Na�a spr�va pre zmenu fullscreen/window
			GoFullScreen = (GoFullScreen == true) ? false:true;	 // Znegujeme pr�znak
			PostMessage(Win.hWND,WM_QUIT,0,0);			// Zr���me cyklus spr�v
			break;
        case WM_LBUTTONDOWN:							// �av� tla�idlo my�ky bolo stla�en�
			{
				Input.Mouse.LeftB = true;				// Nastav�me pr�znak
	            Input.Mouse.x = LOWORD(lParam);         // Nastav�me polohu my�ky 
				Input.Mouse.y = HIWORD(lParam);
			}
			break;
		case WM_LBUTTONUP:								// �av� tla�idlo my�ky bolo uvolnen�
			{
				Input.Mouse.LeftB = false;				// Nastav�me pr�znak
				Input.Mouse.LBDown = false;
				Input.Mouse.x = LOWORD(lParam);         // Nastav�me polohu my�ky 
				Input.Mouse.y = HIWORD(lParam);
			}
			break;
		case WM_RBUTTONDOWN:							// Prav� tla�idlo my�ky bolo stla�en�
			{
				Input.Mouse.RightB = true;				// Nastav�me pr�znak
				Input.Mouse.x = LOWORD(lParam);         // Nastav�me polohu my�ky
				Input.Mouse.y = HIWORD(lParam);
			}
			break;
		case WM_RBUTTONUP:								// Prav� tla�idlo my�ky bolo uvolnen�
			{
				Input.Mouse.RightB = false;				// Nastav�me pr�znak
				Input.Mouse.RBDown = false;
				Input.Mouse.x = LOWORD(lParam);         // Nastav�me polohu my�ky
				Input.Mouse.y = HIWORD(lParam);
			}
			break;
		case WM_MOUSEMOVE:								// My�ka zmenila svoju poz�ciu
			{
	            Input.Mouse.x = LOWORD(lParam);         // Nastav�me polohu my�ky
				Input.Mouse.y = HIWORD(lParam);
			}
			break;
	}

	return DefWindowProc (hWnd, uMsg, wParam, lParam);	// Ostatn� spr�vy prenech�me windows-u
}
//===================================================================< WINMAIN >===================
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	MSG		msg;										// �trukt�ra Window Message
	bool	MsgLoop;

	Win.ClassName = "TunellerClass";					// Meno triedy
	Win.hINST = hInstance;								// In�tancia
	Win.IsFullScreen = true;							// Defaultne je nastaven� Fullscreen m�d
	Win.Title = "Tuneller";

	if (LoadTuneller() == false)						// Inicializujeme aplik�ciu
	{   // Failure
		MessageBox(HWND_DESKTOP, "Zlyhala inicializ�cia !", "Error", MB_OK | MB_ICONEXCLAMATION);
		return -1;
	}
	Win.Width	= GraphMode[0];							// Inicializ�cia nastav� rozl�enie
	Win.Height	= GraphMode[1];
	Win.BPP		= GraphMode[2];
	// Sp�tame sa, �i m� program be�a� vo fullscreen m�de 
	if (MessageBox(HWND_DESKTOP, " Chcete Window m�d ? ", "Start FullScreen?", MB_YESNO | MB_ICONQUESTION) == IDYES)
		Win.IsFullScreen = false;						// Ak nie, nastav�me pr�znak
	// Zaregistrujeme okno
	if (RegisterWindowClass() == false)					// Ak registr�cia zlyhala
	{   // Failure
		MessageBox(HWND_DESKTOP, "Registr�cia okna zlyhala!", "Error", MB_OK | MB_ICONEXCLAMATION);
		ExitTuneller();									// Deinicializ�cia aplik�cie
		return -1;										// Ukon�enie programu
	}
	srand(GetTickCount());
	//*********************************************************************** Cyklus Programu *****
	GoFullScreen = Win.IsFullScreen;					// Inicializ�cia pr�znaku pod�a �elania
	ProgGO = true;										// Inicializ�cia pr�znaku behu programu
	
	while (ProgGO)										// Cyklus programu
	{	
		Win.IsFullScreen = GoFullScreen;				// Nastav�me pr�znak Fullscreen/window
		if(CreateGLwin())								// Vytvor�me okno
		{
			if(Game.Init())								// Inicializujeme hru
			{	
				ShowWindow (Win.hWND, SW_SHOW);
				Win.IsVisible = true;
				MsgLoop = true;							// Inicializujeme pr�znak cyklu spr�v
				while(MsgLoop)							// Cyklus spr�v
				{										// Zist�me pr�tomnos� spr�vy
					if (PeekMessage (&msg, Win.hWND, 0, 0, PM_REMOVE) != 0)
					{									// Ak je nejak� spr�va
						if (msg.message != WM_QUIT)		// Ak nejde o WM_QUIT spr�vu pre ukon�enie cyklu spr�v
						{
							TranslateMessage(&msg);		// Prelo�� spr�vu
							DispatchMessage (&msg);		// Spracuje spr�vu
						}
						else							// Ak ide o WM_QUIT spr�vu
							MsgLoop = false;			// Unon��me cyklus spr�v
					}
					else								// Ak nem�me �iadne spr�vy
					{
						if (!Win.IsVisible)				// Zist�me vidite�nos� okna
							WaitMessage();				// Ak je okno nevidite�n�, program �ak�
						else							// Ak je okno vidite�n�
						{									
							Time.NowTick = (unsigned long) GetTickCount ();	// Z�skame aktu�lny �as
							Time.Sec =	Time.NowTick - Time.LastTick;		// Zist�me rozdiel
							Game.Update();									// Vol�me Update funkciu
							Time.LastTick = Time.NowTick;					// Nastav�me �as
							Game.ReDraw();									// Prekresl�me sc�nu
							SwapBuffers(Win.hDC);		// Vymen�me bufre (Double Buffering)
						}
					}
				}										// Cyklus spr�v pokia� MsgLoop == true
			}
			else										// Zlyhala OpenGL inicializ�cia
			{
				MessageBox(HWND_DESKTOP,"Chyba GLInit !","Error",MB_OK | MB_ICONEXCLAMATION);
				TerminateApp();							// Ukon�enie aplik�cie
			}
			Game.Deinit();							// Deinicializ�cia hry
			DestroyGLWin();								// Zru�enie vytvoren�ho okna
		}
		else											// Zlyhalo vytvorenie okna
		{
			MessageBox(HWND_DESKTOP,"Chyba CreateGLWin !","Error",MB_OK | MB_ICONEXCLAMATION);
			ProgGO = false;								// Ukon�enie programu
		}
	}
	// Aplik�cia skon�ila
	UnregisterClass(Win.ClassName,Win.hINST);			// Odregistrovanie triedy
	ExitTuneller();										// Deinicializ�cia aplik�cie
		
	return 0;
}														// Koniec WinMain()
//===================================================================< END WINMAIN >===============