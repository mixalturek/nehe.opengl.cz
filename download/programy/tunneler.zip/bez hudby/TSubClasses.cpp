/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Implementacia tried pre samotnu hru
############################################################################################*/

#include "Tuneller.h"						// hlavickovy subor tejto hry
#include "TMakros.h"						// hlavickovy subor s konstantami
//===================================================================< TANKCLASS >=================
bool TTankClass::ShootMe(int Sx, int Sy,int Dam,int ID)
{
	if(ID == this->ID)
		return false;
	if((Sx >= (x-Game2.TankSize/2))&&(Sx < (x+Game2.TankSize/2)) && !Vybuch)
		if((Sy >= (y-Game2.TankSize/2))&&(Sy < (y+Game2.TankSize/2)))
		{
			HP -= Dam;			
			return true;
		}
	return false;
};
bool TTankClass::CanMove(int xx,int yy)
{
	if( (xx > (x-Game2.TankSize))&&(xx < (x+Game2.TankSize))&&
		(yy > (y-Game2.TankSize))&&(yy < (y+Game2.TankSize)) )
		return false;
	return true;
};
void TTankClass::SetOwner(TPlayerClass *Player)
{
    Owner = Player;
	if( (*Player).UI )
	{
		IAmUI = true;
		MyMind.Rozdiel = int(Game2.LoopC);
		MyMind.INowWhere = false;
		if( (*Player).ObrID == 0)
			MyMind.IamPredator = true;
		else
			MyMind.IamPredator = false;
	}
	else IAmUI = false;
};
void TTankClass::SetEnemy(TTankClass *Enemy)
{
	MyEnemy = Enemy;
};
void TTankClass::Reset()
{
	HP = TTankClass::MaxTHP;
	Energy = TTankClass::MaxTEnergy;
	r = SnimkyVybuchu = 0;
	PohybTime = VrtTime = 0;
	MyMind.Reset();
	Smer = 3;
};
void TTankClass::ReCharge(int Plus)
{
	Energy = ((Energy + Plus) > TTankClass::MaxTEnergy) ? TTankClass::MaxTEnergy : 
			(Energy + Plus);
};
void TTankClass::ReHealt(int Plus)
{
	HP = ((HP + Plus) > TTankClass::MaxTHP) ? TTankClass::MaxTHP : (HP + Plus);
}
void TTankClass::Redraw()
{
	if(!Vybuch)
	{
		switch(Smer)
		{
			case 3	/*SH*/: glRotated(90,0,0,1); break;
			case -3	/*SD*/: glRotated(-90,0,0,1); break;
			case 2	/*SP*/: glRotated(-180,0,0,1); break;
			case -2	/*SL*/: break;
			case 1	/*SHL*/:glRotated(45,0,0,1); break;
			case 5	/*SHP*/:glRotated(135,0,0,1); break;
			case -5	/*SDL*/:glRotated(-45,0,0,1); break;
			case -1	/*SDP*/:glRotated(-135,0,0,1);	break;
		};

		glEnable(GL_BLEND);	
		glDisable(GL_TEXTURE_2D);
		//glColor3ub(0,100,0);
		//glRecti(-20,-20,20,20);
		glEnable(GL_TEXTURE_2D);
		if(ID == 0) Image.DrawPicture(Image.ListTEX[TEX_REDTANK].texID,-20,-20,20,20);
		else Image.DrawPicture(Image.ListTEX[TEX_BLUETANK].texID,-20,-20,20,20);	
		glDisable(GL_BLEND);
	}
	else
	{
		glDisable(GL_TEXTURE_2D);					
		for(int i=15; i>0; i--)
		{
			glColor3ub(220,GLubyte(70+i*10),0);			
			if(r < 7) gluDisk(quadratic,6*r+i,6*r+3+i,20,1);
		}						
		glEnable(GL_TEXTURE_2D);
	}
};
void TTankClass::Update()
{
	bool Dasa,WithTime = false;
	int tx, ty, i, j, loop, Sx, Sy;
	float LossE = 0;
	int Polka = (Game2.TankSize/4) +1;

	if(Vybuch) 
	{
		SnimkyVybuchu += Time.Sec;
		if(SnimkyVybuchu > 33)
		{
			r++;
			SnimkyVybuchu = 0;
		}
		return;
	}
	PohybTime -= Time.Sec;
	VrtTime   -= Time.Sec;
	DalsiaStrela -= Time.Sec;
	if((PohybTime <= 0) && (VrtTime <= 0))
	{
		PohybTime = VrtTime = 0;
		GoHoriz = GoVerti = 0;
		GoFire = false;
		//-------------------------- ziskanie dalsieho pohybu ---------
		if(IAmUI)
		{
			MyMind.VratNovySmer(&GoHoriz,&GoVerti,&GoFire);
			WithTime = true;
		}
		else
		{
			if(Input.Key[(*Owner).Controls.Up])		GoVerti += 3;
			if(Input.Key[(*Owner).Controls.Down])	GoVerti -= 3;
			if(Input.Key[(*Owner).Controls.Left])	GoHoriz -= 2;
			if(Input.Key[(*Owner).Controls.Right])	GoHoriz += 2;
			if(Input.Key[(*Owner).Controls.Fire] && Input.ShadeKey[(*Owner).Controls.Fire])
			{				
				GoFire = WithTime = true;
			}
			if(Input.Key[(*Owner).Controls.Fire] && !Input.ShadeKey[(*Owner).Controls.Fire])
			{	
				Input.ShadeKey[(*Owner).Controls.Fire] = true;
				GoFire = true;
			}
		}
		//-------------------------------------------------------------
		if(GoFire)
		{
			if((DalsiaStrela <= 0) || !WithTime)
			{
				Sx = x; Sy = y;
				switch(Smer)
				{
					case  3	/*SH*/:	Sy -= Game2.TankSize/2;		break;
					case -3	/*SD*/:	Sy += Game2.TankSize/2 - 1;	break;
					case  2	/*SP*/:	Sx += Game2.TankSize/2 - 1;	break;
					case -2	/*SL*/: Sx -= Game2.TankSize/2;		break;
					case  1	/*SHL*/:Sy -= Game2.TankSize/2 - 1;
									Sx -= Game2.TankSize/2 - 1;	break;
					case  5	/*SHP*/:Sy -= Game2.TankSize/2 - 1;
									Sx += Game2.TankSize/2 - 1;	break;
					case -5	/*SDL*/:Sy += Game2.TankSize/2 - 1;
									Sx -= Game2.TankSize/2 - 1;	break;
					case -1	/*SDP*/:Sy += Game2.TankSize/2 - 2;
									Sx += Game2.TankSize/2 - 2;	break;
					default: break;
				}
				if(PocetStriel < Game2.Strely.MaxStriel/2)
				{
					PocetStriel++;
					Game2.Strely.AddShoot(Sx,Sy,Smer,ID);
					Energy -= ShootLoss;
					Zvuky.PrehrajZvuk(Zvuky.psibolt);
				}
				DalsiaStrela = TTankClass::PauzaStriel;
			}
		}
		for(loop=0; loop<Game2.LoopC; loop++)
		{
			if(GoVerti == 3)
			{	
				tx =x -(Game2.TankSize/2);
				ty =y -(Game2.TankSize/2+1);
				for(i=0,j=Polka,Dasa=true; i<Game2.TankSize; i++)
				{
					if( i<=(Game2.TankSize/4) ) j--;
					if( i>=(3*(Game2.TankSize/4)) ) j++;
					if(Game2.Mapa[tx+i][ty+j].I > 1) Dasa = false;
				}
				if(!((*MyEnemy).CanMove(x,y-1))) Dasa = false;
				if(Dasa)
				{
					for(i=0,j=Polka; i<Game2.TankSize; i++)
					{
						if( i<=(Game2.TankSize/4) ) j--;
						if( i>=(3*(Game2.TankSize/4)) ) j++;
						if(Game2.Mapa[tx+i][ty+j].I > 0)
						{
							VrtTime += Game2.VrtTimC;
							LossE += Game2.LossEnergyC;
							Game2.Mapa[tx+i][ty+j].R = UCHAR( 50 + rand()%10 );
							Game2.Mapa[tx+i][ty+j].G = UCHAR( 50 + rand()%10 );
							Game2.Mapa[tx+i][ty+j].B = UCHAR( 10 + rand()%10 );
							Game2.Mapa[tx+i][ty+j].I = 0;
						}
					}
					y = ((y-1)<Game2.SubMapH/2) ? y : y-1;
				}
			};
			if(GoHoriz == 2)
			{	
				tx =x +(Game2.TankSize/2);
				ty =y -(Game2.TankSize/2);
				for(i=0,j=Polka,Dasa=true; i<Game2.TankSize; i++)
				{
					if( i<=(Game2.TankSize/4) ) j--;
					if( i>=(3*(Game2.TankSize/4)) ) j++;
					if(Game2.Mapa[tx-j][ty+i].I > 1) Dasa = false;
				}
				if(!((*MyEnemy).CanMove(x+1,y))) Dasa = false;
				if(Dasa)
				{
					for(i=0,j=Polka; i<Game2.TankSize; i++)
					{
						if( i<=(Game2.TankSize/4) ) j--;
						if( i>=(3*(Game2.TankSize/4)) ) j++;
						if(Game2.Mapa[tx-j][ty+i].I > 0)
						{
							VrtTime += Game2.VrtTimC;
							LossE += Game2.LossEnergyC;
							Game2.Mapa[tx-j][ty+i].R = UCHAR( 50 + rand()%10 );
							Game2.Mapa[tx-j][ty+i].G = UCHAR( 50 + rand()%10 );
							Game2.Mapa[tx-j][ty+i].B = UCHAR( 10 + rand()%10 );
							Game2.Mapa[tx-j][ty+i].I = 0;
						}
					}
					x = ((x+1)>(Game2.MapW-Game2.SubMapW/2)) ? x : x+1;
				}
			};
			if(GoHoriz== -2)
			{	 
				tx =x -(Game2.TankSize/2+1);
				ty =y -(Game2.TankSize/2);
				for(i=0,j=Polka,Dasa=true; i<Game2.TankSize; i++)
				{
					if( i<=(Game2.TankSize/4) ) j--;
					if( i>=(3*(Game2.TankSize/4)) ) j++;
					if(Game2.Mapa[tx+j][ty+i].I > 1) Dasa = false;
				}
				if(!((*MyEnemy).CanMove(x-1,y))) Dasa = false;
				if(Dasa)
				{
					for(i=0,j=Polka; i<Game2.TankSize; i++)
					{
						if( i<=(Game2.TankSize/4) ) j--;
						if( i>=(3*(Game2.TankSize/4)) ) j++;
						if(Game2.Mapa[tx+j][ty+i].I > 0)
						{
							VrtTime += Game2.VrtTimC;
							LossE += Game2.LossEnergyC;
							Game2.Mapa[tx+j][ty+i].R = UCHAR( 50 + rand()%10 );
							Game2.Mapa[tx+j][ty+i].G = UCHAR( 50 + rand()%10 );
							Game2.Mapa[tx+j][ty+i].B = UCHAR( 10 + rand()%10 );
							Game2.Mapa[tx+j][ty+i].I = 0;
						}
					}  
					x = ((x-1)<Game2.SubMapW/2) ? x : x-1;
				}
			};
			if(GoVerti == -3)
			{	
				tx =x -(Game2.TankSize/2);
				ty =y +(Game2.TankSize/2);
				for(i=0,j=Polka,Dasa=true; i<Game2.TankSize; i++)
				{
					if( i<=(Game2.TankSize/4) ) j--;
					if( i>=(3*(Game2.TankSize/4)) ) j++;
					if(Game2.Mapa[tx+i][ty-j].I > 1) Dasa = false;
				}
				if(!((*MyEnemy).CanMove(x,y+1))) Dasa = false;
				if(Dasa)
				{
					for(i=0,j=Polka; i<Game2.TankSize; i++)
					{
						if( i<=(Game2.TankSize/4) ) j--;
						if( i>=(3*(Game2.TankSize/4)) ) j++;
						if(Game2.Mapa[tx+i][ty-j].I > 0)
						{
							VrtTime += Game2.VrtTimC;
							LossE += Game2.LossEnergyC;
							Game2.Mapa[tx+i][ty-j].R = UCHAR( 50 + rand()%10 );
							Game2.Mapa[tx+i][ty-j].G = UCHAR( 50 + rand()%10 );
							Game2.Mapa[tx+i][ty-j].B = UCHAR( 10 + rand()%10 );
							Game2.Mapa[tx+i][ty-j].I = 0;
						}
					}   
					y = ((y+1)>(Game2.MapH-Game2.SubMapH/2)) ? y : y+1;
				}
			};
		}
		PohybTime = TGame2Class::PohybDelayC;
		Energy -= int(LossE);
		Smer = ((GoHoriz+GoVerti) == 0) ? Smer : (GoHoriz+GoVerti);
		if((GoHoriz+GoVerti) != 0) Energy -= TTankClass::StrataEnergie;
	}
};
//===================================================================< STRELACLASS >===============
void TStrelaClass::Redraw()
{
	static float rot = 1;
	glEnable(GL_BLEND);	
	glColor3ub(220,150,0);
	glBindTexture(GL_TEXTURE_2D,Image.ListTEX[TEX_STRELA].texID);
	glCallList(Skin.ListGL[MGL_STRELA]);
	glColor3ub(200,250,60);
	glRotatef(rot,0,0,1);
	glCallList(Skin.ListGL[MGL_STRELA]);
	rot += 0.5;
	if(rot>360) rot = 0;
	glDisable(GL_BLEND);	
};
bool TStrelaClass::Update()
{	
	int k = int(float(Game2.LoopC) * (float(Time.Sec)/12.5));
	if(k<1) k=1;	
	for(int i=0; i<k; i++)
	{
		switch(Smer)
		{
			case  3	/*SH*/:	y--; break;
			case -3	/*SD*/:	y++; break;
			case  2	/*SP*/:	x++; break;
			case -2	/*SL*/: x--; break;
			case  1	/*SHL*/:y--; x--; break;
			case  5	/*SHP*/:y--; x++; break;
			case -5	/*SDL*/:y++; x--; break;
			case -1	/*SDP*/:y++; x++; break;
			default: break;
		}

		if(Game2.RedLTank.ShootMe(x,y,Dam,ID))
			return false;
		if(Game2.BluePTank.ShootMe(x,y,Dam,ID))
			return false;
		if(Game2.Mapa[x][y].I == 2)
			return false;	
		if(Game2.Mapa[x][y].I == 3)
		{
			Game2.RedLDom.ShootMe(Dam);
			return false;
		}
		if(Game2.Mapa[x][y].I == 4)
		{
			Game2.BluePDom.ShootMe(Dam);
			return false;
		}
		if(Game2.Mapa[x][y].I == 1)
		{		
			for(int l=0;l<Game2.LoopC;l++)
			{
				int Pocet = (rand()%8) + 2;
				int Dier = (rand()%(6*(10/Game2.MapZoom)))+ 2;
				for(int i=0; i<Pocet; i++)
					for(int j=0,Mx=0,My=0; j<Dier; j++)
					{ 
						if(rand()%2 == 1) Mx--;
						if(rand()%2 == 1) Mx++;
						if(rand()%2 == 1) My--;
						if(rand()%2 == 1) My++;
						if(Game2.Mapa[x+Mx][y+My].I == 1)
						{
							Game2.Mapa[x+Mx][y+My].R = UCHAR( 50+rand()%10 );
							Game2.Mapa[x+Mx][y+My].G = UCHAR( 50+rand()%10 );
							Game2.Mapa[x+Mx][y+My].B = UCHAR( 10+rand()%10 );
							Game2.Mapa[x+Mx][y+My].I = 0;
						}
					}
			}
			return false;
		}
	}
	if(Game2.Mapa[x][y].I == 0)
		return true;
	return false;
}
//===================================================================< STRELYCLASS >===============
void TStrelyClass::Update()
{
	if(FrontS.empty() == false)
	{
		StrelaTime -= Time.Sec;
		if(StrelaTime <= 0)
		{
			StrelaTime = TStrelyClass::StrelaTimC;
			TStrelaClass Strela;
			int NumS = int(FrontS.size());
			int s = (int)RedSee.size();
			for(int i=0; i<s; i++)
				RedSee.pop();
			s = (int)BluSee.size();
			for(int i=0; i<s; i++)
				BluSee.pop();
			for(int i=0; i<NumS; i++)
			{
				Strela = FrontS.front();
				FrontS.pop();
				
				if(!Strela.Update())
				{
					if(Strela.ID == 0 && Game2.RedLTank.PocetStriel>0)
						Game2.RedLTank.PocetStriel--;
					if(Strela.ID == 1 && Game2.BluePTank.PocetStriel>0)
						Game2.BluePTank.PocetStriel--;
					break;
				}			
				else
				{
					FrontS.push(Strela);	
					if((Strela.x >= (Game2.RedLTank.x-Game2.SubMapW/2))&&
						(Strela.x <= (Game2.RedLTank.x+Game2.SubMapW/2)))
						if((Strela.y >= (Game2.RedLTank.y-Game2.SubMapH/2))&&
							(Strela.y <= (Game2.RedLTank.y+Game2.SubMapH/2)))
							RedSee.push(Strela);
					if((Strela.x >= (Game2.BluePTank.x-Game2.SubMapW/2))&&
						(Strela.x <= (Game2.BluePTank.x+Game2.SubMapW/2)))
						if((Strela.y >= (Game2.BluePTank.y-Game2.SubMapH/2))&&
							(Strela.y <= (Game2.BluePTank.y+Game2.SubMapH/2)))
							BluSee.push(Strela);
				}
				
			}
		}
	}
};
void TStrelyClass::AddShoot(int x,int y,int Smer,int ID)
{
	if(FrontS.size() < MaxStriel)
	{
		TStrelaClass	Strela;
		Strela.x = x;
		Strela.y = y;
		Strela.Smer = Smer;
		Strela.ID = ID;
		FrontS.push(Strela);
	}
};
//===================================================================< DOMCEKCLASS >===============
void TDomcekClass::VrtajDomcek(TTankClass *Tank,TDomcekClass *Domcek)
{
	int Mapx, Mapy;
	DomS = 160/Game2.MapZoom;
	MurS = 10/Game2.MapZoom;
	Stena = 50/Game2.MapZoom;
	srand(Time.NowTick);

	for(;;)
	{		
		Mapx = Game2.SubMapW + DomS + rand()%(Game2.MapW - 2*Game2.SubMapW - 2*DomS);
		Mapy = Game2.SubMapH + DomS + rand()%(Game2.MapH - 2*Game2.SubMapH - 2*DomS);
		if(Domcek == NULL) break;
		if(Mapx<((*Domcek).x-DomS)||(Mapx>((*Domcek).x+DomS)))
			if(Mapy<((*Domcek).y-DomS)||(Mapy>((*Domcek).y+DomS)))
				break;
	};
	MyTank = Tank; (*MyTank).ID = ID; (*MyTank).MyFort = this;								
	x = Mapx; y = Mapy;
	BodAX = BodBX = x; BodAY = y - DomS; BodBY = y + DomS;
	Mapx -= DomS/2; Mapy -= DomS/2;
	
	for(int i=0; i<DomS; i++)
		for(int j=0; j<DomS; j++)	 
			if( (i<MurS) || (i>=(DomS-MurS)) || ((j<MurS)&&(i<Stena)) ||
				((j<MurS)&&(i>=(DomS-Stena)))|| ((j>=(DomS-MurS))&&(i<Stena)) ||
				((j>=(DomS-MurS))&&(i>=(DomS-Stena))))
			{
				Game2.Mapa[Mapx+i][Mapy+j].R = UCHAR( ((ID == 0)?180:20)+rand()%40 );
				Game2.Mapa[Mapx+i][Mapy+j].G = UCHAR( 20+rand()%10 );
				Game2.Mapa[Mapx+i][Mapy+j].B = UCHAR( ((ID == 1)?180:20)+rand()%40 );
				Game2.Mapa[Mapx+i][Mapy+j].I = ((ID == 0)?3:4);
			}   
			else	
			{
				Game2.Mapa[Mapx+i][Mapy+j].R = UCHAR( 50+rand()%10 );
				Game2.Mapa[Mapx+i][Mapy+j].G = UCHAR( 50+rand()%10 );
				Game2.Mapa[Mapx+i][Mapy+j].B = UCHAR( 10+rand()%10 );
				Game2.Mapa[Mapx+i][Mapy+j].I = 0;
			}
};
void TDomcekClass::AtFortres(TTankClass *OtherTank)
{
	FreshTime -= Time.Sec;
	if(FreshTime <= 0)
	{
		FreshTime = FreshC;
		if(((*MyTank).x > x-DomS/2)&&((*MyTank).x < x+DomS/2) && !(*MyTank).Vybuch)
			if(((*MyTank).y > y-DomS/2)&&((*MyTank).y < y+DomS/2))
			{
				(*MyTank).ReCharge(50);
				(*MyTank).ReHealt(5);
			}
		if(((*OtherTank).x > x-DomS/2)&&((*OtherTank).x < x+DomS/2) && !(*OtherTank).Vybuch)
			if(((*OtherTank).y > y-DomS/2)&&((*OtherTank).y < y+DomS/2))
				(*OtherTank).ReCharge(10);
	}
};
bool TDomcekClass::AtHome()
{
	if(((*MyTank).x > x-DomS/2)&&((*MyTank).x < x+DomS/2))
		if(((*MyTank).y > y-DomS/2)&&((*MyTank).y < y+DomS/2))
			return true;
	return false;
};
bool TDomcekClass::InFort(int xx,int yy)
{
	if((xx > x-DomS/2)&&(xx < x+DomS/2))
		if((yy > y-DomS/2)&&(yy < y+DomS/2))
			return true;
	return false;
};
void TDomcekClass::Reset()
{
	HP = TDomcekClass::MaxDHP;
	(*MyTank).x = x;
	(*MyTank).y = y;
	(*MyTank).Reset();	
};
void TDomcekClass::ShootMe(int Dam)
{
	if(Game2.ZnicitelnyDomcek) HP -= Dam;
}
//===================================================================< END >=======================