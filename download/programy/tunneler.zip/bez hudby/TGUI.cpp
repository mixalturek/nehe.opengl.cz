/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Implementacia grafickeho pouzivatelskeho rozhrania
############################################################################################*/

#include <windows.h>						// hlavickovy subor pre winapi
#include <gl\gl.h>							// hlavickovy subor pre OpenGL
#include <gl\glu.h>							// hlavickovy subor pre Glu
#include <stdio.h>							// standardny vstup / vystup
#include <stdarg.h>							// funkcie s variabilnym poctom argumentov
#include <string.h>							// praca s retazcami
#include "Tuneller.h"						// hlavickovy subor tejto hry
#include "TMakros.h"						// hlavickovy subor s konstantami
//===================================================================< DEFINICIE OBJEKTOV >========
TTextClass		CText;
TFPSClass		FPSC;
TCursorClass	Cursor;
//===================================================================< FPSCLASS >==================
TFPSClass::TFPSClass()
{
	LastFrameTick = Time.NowTick;
};
void TFPSClass::DrawFPS()
{
	Frames++;
	if((Time.NowTick - LastFrameTick) > 1000)
	{
		LastFrameTick = Time.NowTick;
		sprintf(text,"FPS je <%d>",Frames);
		Frames = 0;
	}
	glColor3ub(255,255,255);
	CText.DrawGLText(10,20,text,true);
};
//===================================================================< FLATBUTTON >================
TFlatButton::TFlatButton(int W,int H)
{
	BX = BY = GoX = Width = Height = 0;
	MouseOver = IsVisible = IsActivated = false;
	Text[0] = NULL;
	Width = W; Height = H;
};
void TFlatButton::SetMe(int x,int y,char text[])
{
	BX = x; BY = y;
	strcpy(Text,text);
};
void TFlatButton::SetMySize(int W,int H)
{
	Width = W; Height = H;
};
void TFlatButton::Reset(bool Visible,bool Active,bool Roll)
{
	IsVisible = Visible;
	IsActivated = Active;
	if(Roll) GoX = Width;
	else GoX = 0;
};
void TFlatButton::Redraw()
{
	if(IsVisible)
	{
		if(Text != NULL)
		{
			if(IsActivated && MouseOver)
				glColor3ub(250,188,44);
			else
			if(IsActivated)
				glColor3ub(84,188,44);
			else
				glColor3ub(84,84,84);
			//int Plus = (Height - 14)/2;
			CText.DrawGLTextStred(BX,BY+Height,Width,Text,true);
		}
	}
};
bool TFlatButton::Update()
{
	if(IsVisible)
	{
		if(GoX > 0) GoX -= int(Time.Sec/2);
		else
		{
			GoX = 0;
			if(IsActivated)
			{
				if(Input.IsMouseIn(BX,BY,BX+Width,BY+Height))
				{
					if(!MouseOver)
					{
						MouseOver = true;
						Zvuky.PrehrajZvuk(Zvuky.mouseover);						
					}
					if((Input.Mouse.LeftB)&&(!Input.Mouse.LBDown))
					{
						Input.Mouse.LBDown = true;
						Zvuky.PrehrajZvuk(Zvuky.mousedown);						
						return true;
					}
				}
				else MouseOver = false;
			}
		}
	}
	else GoX = Width;
	
	return false;
};
bool TFlatButton::IsMouseOver()
{
	return (
	((Input.Mouse.x>BX)&&(Input.Mouse.x<BX+Width)&&(Input.Mouse.y>BY)
	&&(Input.Mouse.y<BY+Height)) ? true : false);
};
//===================================================================< INBOXCLASS >===============
void TInboxClass::Reset(bool Visible,bool Active)
{
	TFlatButton::Reset(Visible,Active,false);
	InputPos = Cas = 0;
	InsertToMe = Finished = ZobrazKurzor = false;
};
bool TInboxClass::Update()
{
	if(IsVisible)
	{
		if(Cas > 500) 
		{
			ZobrazKurzor = !ZobrazKurzor;
			Cas = 0;
		}
		Cas += Time.Sec;
		if(GoX > 0) GoX -= int(Time.Sec/2);
		else
		{
			GoX = 0;
			if(IsActivated)
			{
				if(InsertToMe && (Input.InputChar > 0))
				{
					if(Input.VirtualKey == VK_RETURN)
					{
						InsertToMe = false;
						Text[InputPos] = '\0';
						Input.InputChar = 0;
						Input.VirtualKey = 0;
						Finished = true;
					}
					else
					if(Input.VirtualKey == VK_BACK)
					{
						if(InputPos >0) Text[--InputPos] = '\0';
						Input.InputChar = 0;
						Input.VirtualKey = 0;
					}
					else
					if(InputPos< int(Width/11)-1 && Input.VirtualKey != VK_BACK)
					{	
						Text[InputPos++] = Input.InputChar;
						Input.InputChar = 0;
						Input.VirtualKey = 0;
					}					
				}
				if(InsertToMe)
					if(ZobrazKurzor)
					{
						Text[InputPos] = '_';
						Text[InputPos+1] = 0;
					}
					else Text[InputPos] = ' ';
				if(Input.IsMouseIn(BX,BY,BX+Width,BY+Height))
				{
					if(!MouseOver)
					{
						MouseOver = true;
						Zvuky.PrehrajZvuk(Zvuky.mouseover);						
					}
					if((Input.Mouse.LeftB)&&(!Input.Mouse.LBDown))
					{
						Input.Mouse.LBDown = true;
						Input.InputChar = 0;
						Input.VirtualKey = 0;
						if(!InsertToMe && !Finished)
						{
							for(int i=0; i<18; i++)
								Text[i] = 0;
						}
						Zvuky.PrehrajZvuk(Zvuky.mousedown);					
						InsertToMe = !InsertToMe;
						Finished = !InsertToMe;
						return true;
					}
				}
				else MouseOver = false;
			}
			else
			if(InsertToMe)
			{
				InsertToMe = false;
				Text[InputPos] = '\0';
				Input.InputChar = 0;
				Finished = true;
			}
		}
	}
	else GoX = Width;
	if(Finished && (Text[InputPos]==' ' || Text[InputPos]=='_')) Text[InputPos] = 0;

	return false;
};
//===================================================================< BUTTONCLASS >===============
void TButtonClass::Redraw()
{
	if(IsVisible)
	{
		glLoadIdentity();
		glTranslatef((float)BX+GoX,(float)BY,(float)0);
		glEnable(GL_BLEND);					// Zapne blending
		glColor3ub(255,255,255);
		if((MouseOver)&&(IsActivated))
			glBindTexture(GL_TEXTURE_2D,Image.ListTEX[TEX_BUTTONSELECT].texID);
		else
			glBindTexture(GL_TEXTURE_2D,Image.ListTEX[TEX_BUTTON].texID);
		glCallList(Skin.ListGL[MGL_BUTTON]);
		glDisable(GL_BLEND);				// Vypne blending
		if(IsActivated && MouseOver)
			glColor3ub(250,188,44);
		else
		if(IsActivated)
			glColor3ub(84,188,44);
		else
			glColor3ub(84,84,84);
		CText.DrawGLText(BX+15+GoX,BY+27,Text,false);
	}
};
bool TButtonClass::Update()
{
	if(IsVisible)
	{
		if(GoX > 0)
		{
			if(GoX == Width) Zvuky.PrehrajZvuk(Zvuky.swishin);
			GoX	-= int(Time.Sec/2);
		}
		else
		{
			GoX = 0;
			if(IsActivated)
			{
				if(Input.IsMouseIn(BX+3,BY+2,BX+180,BY+32))
				{
					if(!MouseOver)
					{
						MouseOver = true;
						Zvuky.PrehrajZvuk(Zvuky.mouseover);						
					}
					if((Input.Mouse.LeftB)&&(!Input.Mouse.LBDown))
					{
						Input.Mouse.LBDown = true;
						Zvuky.PrehrajZvuk(Zvuky.mousedown);						
						return true;
					}
				}
				else MouseOver = false;
			}
		}
	}
	else GoX = Width;
	
	return false;
};
//===================================================================< BUTTONDCLASS >===============
void TButtonDClass::Reset(bool Visible,bool Active,bool Roll)
{
	TFlatButton::Reset(Visible,Active,Roll);
	if(Roll) GoX = Height;
};
void TButtonDClass::Redraw()
{
	if(IsVisible)
	{
		glLoadIdentity();
		glTranslatef((float)BX,(float)BY+GoX,(float)0);
		glEnable(GL_BLEND);					// Zapne blending
		glColor3ub(255,255,255);
		glBindTexture(GL_TEXTURE_2D,Image.ListTEX[TEX_BUTTONDOLE].texID);
		glCallList(Skin.ListGL[MGL_BUTTOND]);
		glDisable(GL_BLEND);				// Vypne blending
		if(IsActivated && MouseOver)
			glColor3ub(250,188,44);
		else
		if(IsActivated)
			glColor3ub(84,188,44);
		else
			glColor3ub(84,84,84);
		CText.DrawGLText(BX+28,BY+35+GoX,Text,false);
	}
};
bool TButtonDClass::Update()
{
	if(IsVisible)
	{
		if(GoX > 0)
		{
			if(GoX == Height) Zvuky.PrehrajZvuk(Zvuky.swishin);
			GoX	-= int(Time.Sec/5);
		}
		else
		{
			GoX = 0;
			if(IsActivated)
			{
				if(Input.IsMouseIn(BX+13,BY+16,BX+163,BY+43))
				{
					if(!MouseOver)
					{
						MouseOver = true;						
						Zvuky.PrehrajZvuk(Zvuky.mouseover);
					}
					if((Input.Mouse.LeftB)&&(!Input.Mouse.LBDown))
					{
						Input.Mouse.LBDown = true;						
						Zvuky.PrehrajZvuk(Zvuky.mousedown);
						return true;
					}
				}
				else MouseOver = false;
			}
		}
	}
	else GoX = Height;
	
	return false;
};
//===================================================================< LISTACLASS >================
void TListaClass::Redraw()
{
	if(IsVisible)
	{
		glLoadIdentity();
		glTranslatef((float)BX-GoX,(float)BY,(float)0);
		glEnable(GL_BLEND);					// Zapne blending
		glColor3ub(255,255,255);
		glBindTexture(GL_TEXTURE_2D,Image.ListTEX[TEX_LISTA].texID);
		glCallList(Skin.ListGL[MGL_LISTA]);
		glDisable(GL_BLEND);				// Vypne blending
		glColor3ub(84,188,255);
		CText.DrawGLText(BX+55-GoX,BY+90,Text,true);
	};
};
bool TListaClass::Update()
{
	if(IsVisible)
	{
		if(GoX > 0)
		{
			if(GoX == Width) Zvuky.PrehrajZvuk(Zvuky.swishin);
			GoX	-= int(Time.Sec);
		}
		else
		{
			GoX = 0;
			if(IsActivated)
			{
				if(Input.IsMouseIn(BX+60,BY+90,BX+364,BY+322))
				{
					if(!MouseOver) MouseOver = true;
					if(Input.Mouse.LeftB)
					{						
						Zvuky.PrehrajZvuk(Zvuky.swishout);
						return true;
					}
				}
				else MouseOver = false;
			}
		}
	}
	else GoX = Width;

	return false;
};
//===================================================================< LISTAPROFCLASS >================
TZoznamPClass::TZoznamPClass()
{
	SetMySize(350,350);
	FBNew.SetMe(44,328,"Novy");
	FBNew.SetMySize(156,17);
	FBNew.Reset(true,true,false);
	FBDel.SetMe(218,328,"Zmazat");
	FBDel.SetMySize(124,17);
	FBDel.Reset(true,true,false);
	VybratyProfil = Scroll = 0;
	New = Del = false;
};
void TZoznamPClass::Reset(bool Visible,bool Active,bool Roll)
{
	TFlatButton::Reset(Visible,Active,Roll);
	VybratyProfil = Scroll = 0;
	New = Del = false;
};
void TZoznamPClass::Redraw()
{
	if(IsVisible)
	{
		glLoadIdentity();
		glTranslatef((float)BX-GoX,(float)BY,(float)0);
		glEnable(GL_BLEND);					// Zapne blending
		glColor3ub(255,255,255);
		glBindTexture(GL_TEXTURE_2D,Image.ListTEX[TEX_LISTAPROF].texID);
		glCallList(Skin.ListGL[MGL_LISTAPROF]);
		glDisable(GL_BLEND);				// Vypne blending
		glColor3ub(84,188,255);
		CText.DrawGLText(BX+55-GoX,BY+90,Text,true);
		if(GoX == 0) FBNew.Redraw();
		if(GoX == 0) FBDel.Redraw();
		if(GoX == 0 && (Profils.PocetP-2) > 13) 
		{
			glDisable(GL_TEXTURE_2D);			
			glBegin(GL_TRIANGLES);
				glColor3ub(255,170,54);
				glVertex2i(320,160);
				glColor3ub(247,94,37);
				glVertex2i(310,190);
				glColor3ub(150,0,0);
				glVertex2i(330,190);
				glColor3ub(247,94,37);
				glVertex2i(330,200);
				glColor3ub(150,0,0);
				glVertex2i(310,200);
				glColor3ub(255,170,54);
				glVertex2i(320,230);
			glEnd();
			glColor3ub(255,255,255);
			glEnable(GL_TEXTURE_2D);
		}
		glScissor(56-GoX, 175, 281, 209);
		glEnable(GL_SCISSOR_TEST);
		glColor3ub(251,167,47);
		for(int i=0; i<Profils.PocetP-2; i++)
		{
			if(i == VybratyProfil)
			{
				glColor3ub(251,47,47);
				CText.DrawGLText(58-GoX, 113+(i*16) - Scroll, Profils.Hraci[i+2].Nick, true);				
				glColor3ub(251,167,47);				
			}
			else
				CText.DrawGLText(58-GoX, 113+(i*16) - Scroll, Profils.Hraci[i+2].Nick, true);
		}
		glDisable(GL_SCISSOR_TEST);	
	};
};
bool TZoznamPClass::Update()
{
	if(IsVisible)
	{
		if(GoX > 0)
		{
			if(GoX == Width) Zvuky.PrehrajZvuk(Zvuky.swishin);
			GoX	-= int(Time.Sec);
		}
		else
		{
			GoX = 0;
			if(IsActivated)
			{
				if(FBNew.Update()) { New  = true; };
				if(FBDel.Update()) { Del = true; };
				if(Input.IsMouseIn(BX+0,BY+0,BX+350,BY+350))
				{
					if(Input.IsMouseIn(56,96,305,305) && Input.Mouse.LeftB 
						&& !Input.Mouse.LBDown)						
					{
						Input.Mouse.LBDown = true;
						int y = Input.Mouse.y-97-4;		//profily v zozname
						VybratyProfil = (int)((float)y/16.0 + (float)Scroll/16.0);
						if(VybratyProfil >= Profils.PocetP-2) 
							VybratyProfil = Profils.PocetP-3;
					}						
					if(Input.IsMouseInR(310,200,20,30) && Input.Mouse.LeftB 
						&& Scroll<(Profils.PocetP-2-13)*16)
					{
						Scroll+=1;		//scrollovanie zoznamu
					}
					if(Input.IsMouseInR(310,160,20,30) && Input.Mouse.LeftB && Scroll>0)
					{
						Scroll-=1;		//scrollovanie zoznamu
					}					
					if(!MouseOver) MouseOver = true;
					if(Input.Mouse.LeftB)
					{						
						return true;
					}
				}
				else MouseOver = false;
			}
		}
	}
	else GoX = Width;

	return false;
};
//===================================================================< NEWPROFCLASS >==========
TNovyPClass::TNovyPClass()
{
	SetMySize(364,322);
	ObrSet.SetMe(62,153);
	IBName.SetMe(175,126,"<klikni sem>");
	IBName.SetMySize(180,16);
	for(int i=0;i<5;i++)
	{	
		FBOvladanie[i].SetMe(175,158+i*32,"<klikni sem>");
		FBOvladanie[i].SetMySize(180,16);
		Kody[i] = 0;
	}	
	KtoreTlacitko = -1;
	VsetkoZadane = false;
};
void TNovyPClass::Reset(bool Visible,bool Active,bool Roll)
{
	TFlatButton::Reset(Visible,Active,Roll);
	IBName.Reset(Visible,Active);
	strcpy(IBName.Text,"<klikni sem>");
	for(int i=0; i<5; i++)
	{
		FBOvladanie[i].Reset(Visible,Active,Roll);
		strcpy(FBOvladanie[i].Text,"<klikni sem>");
		Kody[i] = 0;
	}
	ObrSet.Reset(Visible,Active);
	Input.InputChar = 0;
	KtoreTlacitko = -1;
	VsetkoZadane = false;
}
void TNovyPClass::Redraw()
{
	if(IsVisible)
	{
		glLoadIdentity();
		glTranslatef((float)BX-GoX,(float)BY,(float)0);
		glEnable(GL_BLEND);					
		glColor3ub(255,255,255);
		glBindTexture(GL_TEXTURE_2D,Image.ListTEX[TEX_LISTA].texID);
		glCallList(Skin.ListGL[MGL_LISTA]);
		glDisable(GL_BLEND);				
		glColor3ub(84,188,255);
		CText.DrawGLText(BX+55-GoX,BY+90,Text,true);
		if(GoX == 0)
		{
			ObrSet.Redraw();
			glColor3ub(100,100,200);
			CText.DrawGLText(175,126,"Nick:",true);
			CText.DrawGLText(175,158,"Hore",true);
			CText.DrawGLText(175,190,"Dole:",true);
			CText.DrawGLText(175,222,"Vlavo:",true);
			CText.DrawGLText(175,254,"Vpravo:",true);
			CText.DrawGLText(175,286,"Strelba:",true);
			glColor3ub(255,255,255);
			IBName.Redraw();
			for(int i=0; i<5; i++)
				FBOvladanie[i].Redraw();
		}
	};
};
bool TNovyPClass::Update()
{
	if(IsVisible)
	{
		if(GoX > 0)
		{
			if(GoX == Width) Zvuky.PrehrajZvuk(Zvuky.swishin);
			GoX	-= int(Time.Sec);
		}
		else
		{
			GoX = 0;
			if(IsActivated)
			{
				ObrSet.Update();
				if(IBName.Finished) ActivateAll();
				if(KtoreTlacitko > 0 && KtoreTlacitko < 6)
				{
					if(Input.VirtualKey>0)
					{
						strcpy(FBOvladanie[KtoreTlacitko-1].Text,Input.KeyName);
						Kody[KtoreTlacitko-1] = Input.VirtualKey;
						ActivateAll();
						KtoreTlacitko = 0;
					}
					else strcpy(FBOvladanie[KtoreTlacitko-1].Text,"");
				}
				if(Input.IsMouseIn(BX+60,BY+90,BX+364,BY+322))
				{
					if(IBName.Update())
					{
						DeactivateAll(0);
						KtoreTlacitko = 0;						
					}
					for(int i=0; i<5; i++)
					{
						if(FBOvladanie[i].Update())
						{
							DeactivateAll(i+1);
							KtoreTlacitko = i+1;
						}
					}					
					if(!MouseOver) MouseOver = true;
					if(Input.Mouse.LeftB)
					{						
						return true;
					}
				}
				else MouseOver = false;
			}
		}
	}
	else GoX = Width;

	bool rovnake = false;
	for(int i=0; i<5; i++)
	{
		if(Kody[i] == 0) break;
		for(int j=0; j<5; j++)
			if(Kody[j] == Kody[i] && j!=i) 
			{
				rovnake=true;
				strcpy(FBOvladanie[j].Text,"Konflikt!");
				Kody[j] = 0;
				Setting.BSav.Reset(false,false,false);
				VsetkoZadane = false;
			}
		if(i==4 && !rovnake) VsetkoZadane = true;
	}
	if(IBName.Text[0]==0 || strcmp(IBName.Text,"<klikni sem>")==0 || IBName.InsertToMe)
	{
		VsetkoZadane = false;
		Setting.BSav.Reset(false,false,true);
	}
	if(VsetkoZadane && !Setting.BSav.IsActivated && !Setting.Menenie) 
	{
		Setting.BSav.Reset(true,true,true);
	}

	return false;
}
void TNovyPClass::ActivateAll()
{
	for(int i=0; i<5; i++)
		FBOvladanie[i].IsActivated = true;
	IBName.IsActivated = true;
}
void TNovyPClass::DeactivateAll(int okrem)
{
	for(int i=0; i<5; i++)
		if((i+1) != okrem) FBOvladanie[i].IsActivated = false;
	if(okrem > 0) IBName.IsActivated = false;	
}
//===================================================================< PONUKACLASS >===============
void TPonukaClass::Redraw()
{
	if(IsVisible)
	{
		glLoadIdentity();
		glTranslatef((float)BX+GoX,(float)BY,(float)0);
		glEnable(GL_BLEND);
		glColor3ub(255,255,255);
		glBindTexture(GL_TEXTURE_2D,Image.ListTEX[TEX_PONUKA].texID);
		glCallList(Skin.ListGL[MGL_PONUKA]);
		glDisable(GL_BLEND);
	};
};
bool TPonukaClass::Update()
{
	if(IsVisible)
	{
		if(GoX > 0)
		{
			if(GoX == Width) Zvuky.PrehrajZvuk(Zvuky.swishin);
			GoX	-= int(Time.Sec/2);
		}
		else
		{
			GoX = 0;
			if(IsActivated)
			{
				if(Input.IsMouseIn(BX+5,BY+50,BX+210,BY+328))
				{
					if(!MouseOver) MouseOver = true;
					if((Input.Mouse.LeftB))
					{
						return true;
					}
				}
				else MouseOver = false;
			}
		}
	}
	else GoX = Width;

	return false;
};
//===================================================================< CURSORCLASS >===============
void TCursorClass::Redraw()
{
	glLoadIdentity();
	glTranslatef((float)Input.Mouse.x,(float)Input.Mouse.y,(float)0);
	glCallList(Skin.ListGL[MGL_CURSOR]);
};
void TCursorClass::Suradnice()
{
	sprintf(x,"x:%d",Input.Mouse.x);
	sprintf(y,"y:%d",Input.Mouse.y);
	glColor3ub(255,255,255);
	CText.DrawGLText(10,40,x,true);
	CText.DrawGLText(10,60,y,true);
}
//===================================================================< INDEXSETCLASS >=============
void TIndexSetClass::SetMe(int x,int y)
{
	TFlatButton::SetMe(x,y,"");
};
void TIndexSetClass::Reset(bool Visible,bool Active)
{
	TFlatButton::Reset(Visible,Active,false);
	Select = MinSelect;
	MouseOverLeft = MouseOverRight = false;
};
void TIndexSetClass::Redraw()
{
	if(IsVisible)
	{
		glColor3ub(0,(MouseOverLeft?200:0),250);
		glLoadIdentity();
		glTranslatef((float)BX,(float)BY,(float)0);
		glCallList(Skin.ListGL[MGL_SIPKAVLAVO]);
		glColor3ub(0,(MouseOverRight?200:0),250);
		glLoadIdentity();
		glTranslatef((float)BX+Width-50,(float)BY,(float)0);
		glCallList(Skin.ListGL[MGL_SIPKAVPRAVO]);
	}
};
bool TIndexSetClass::Update()
{
	if(IsVisible)
	{
		if(Input.IsMouseIn(BX,BY,BX+110,BY+25)&&IsActivated)
		{
			if(!MouseOver) MouseOver = true;
			if(Input.IsMouseIn(BX,BY,BX+50,BY+25))
				MouseOverLeft = true;
			else
				MouseOverLeft = false;
			if(Input.IsMouseIn(BX+60,BY,BX+110,BY+25))
				MouseOverRight = true;
			else
				MouseOverRight = false;
			if((Input.Mouse.LeftB)&&(!Input.Mouse.LBDown)&&(MouseOverLeft))
			{
				Input.Mouse.LBDown = true;
				((Select == MaxSelect) ? Select = MinSelect : Select++);
				Zvuky.PrehrajZvuk(Zvuky.swishlock);				
			}
			if((Input.Mouse.LeftB)&&(!Input.Mouse.LBDown)&&(MouseOverRight))
			{
				Input.Mouse.LBDown = true;
				((Select == MinSelect) ? Select = MaxSelect : Select--);
				Zvuky.PrehrajZvuk(Zvuky.swishlock);				
			}
		}
		else MouseOver = MouseOverLeft = MouseOverRight = false;
	}
	
	return false;
};
//===================================================================< PROFILSETCLASS >============
void TProfilSetClass::Redraw()
{
	if(IsVisible)
	{
		glLoadIdentity();
		glTranslatef((float)BX,(float)BY,(float)0);
		glColor3ub(200,200,200);
		glEnable(GL_BLEND);
		switch(Profils.Hraci[Select].ObrID)
		{
			case 0: Image.DrawPicture(Image.ListTEX[TEX_PREDATOR].texID,60,0,140,80);
					CText.DrawGLTextStred(BX,BY+110,200,Profils.Hraci[Select].Nick,true); 
					break;
			case 1: Image.DrawPicture(Image.ListTEX[TEX_ROBOCOP].texID,60,0,140,80);
					CText.DrawGLTextStred(BX,BY+110,200,Profils.Hraci[Select].Nick,true); 
					break;
			case 2: Image.DrawPicture(Image.ListTEX[TEX_DRAGON].texID,60,0,140,80);
					CText.DrawGLTextStred(BX,BY+110,200,Profils.Hraci[Select].Nick,true); 
					break;
			case 3: Image.DrawPicture(Image.ListTEX[TEX_HOLKA].texID,60,0,140,80);
					CText.DrawGLTextStred(BX,BY+110,200,Profils.Hraci[Select].Nick,true); 
					break;
			case 4: Image.DrawPicture(Image.ListTEX[TEX_DIABLO].texID,60,0,140,80);
					CText.DrawGLTextStred(BX,BY+110,200,Profils.Hraci[Select].Nick,true); 
					break;
			case 5: Image.DrawPicture(Image.ListTEX[TEX_SKELET].texID,60,0,140,80);
					CText.DrawGLTextStred(BX,BY+110,200,Profils.Hraci[Select].Nick,true); 
					break;
			case 6: Image.DrawPicture(Image.ListTEX[TEX_TIGER].texID,60,0,140,80);
					CText.DrawGLTextStred(BX,BY+110,200,Profils.Hraci[Select].Nick,true); 
					break;
			case 7: Image.DrawPicture(Image.ListTEX[TEX_VLK].texID,60,0,140,80);
					CText.DrawGLTextStred(BX,BY+110,200,Profils.Hraci[Select].Nick,true); 
					break;
			case 8: Image.DrawPicture(Image.ListTEX[TEX_SELMA].texID,60,0,140,80);
					CText.DrawGLTextStred(BX,BY+110,200,Profils.Hraci[Select].Nick,true); 
					break;
			case 9: CText.DrawGLTextStred(BX+60,BY+45,80,"None",false); 
					break;
		};
		glEnable(GL_BLEND);
		switch(Profils.Hraci[((Select == 0) ? Profils.PocetP-1 : Select-1)].ObrID)
		{
			case 0: Image.DrawPicture(Image.ListTEX[TEX_PREDATOR].texID,0,0,50,50);	break;
			case 1: Image.DrawPicture(Image.ListTEX[TEX_ROBOCOP].texID,0,0,50,50); break;
			case 2: Image.DrawPicture(Image.ListTEX[TEX_DRAGON].texID,0,0,50,50); break;
			case 3: Image.DrawPicture(Image.ListTEX[TEX_HOLKA].texID,0,0,50,50); break;
			case 4: Image.DrawPicture(Image.ListTEX[TEX_DIABLO].texID,0,0,50,50); break;
			case 5: Image.DrawPicture(Image.ListTEX[TEX_SKELET].texID,0,0,50,50); break;
			case 6: Image.DrawPicture(Image.ListTEX[TEX_TIGER].texID,0,0,50,50); break;
			case 7: Image.DrawPicture(Image.ListTEX[TEX_VLK].texID,0,0,50,50); break;
			case 8: Image.DrawPicture(Image.ListTEX[TEX_SELMA].texID,0,0,50,50); break;
			case 9: CText.DrawGLTextStred(BX,BY+30,50,"None",true); break;
		};
		glEnable(GL_BLEND);
		switch(Profils.Hraci[((Select == Profils.PocetP-1) ? 0 : Select+1)].ObrID)
		{
			case 0: Image.DrawPicture(Image.ListTEX[TEX_PREDATOR].texID,150,0,200,50); break;
			case 1: Image.DrawPicture(Image.ListTEX[TEX_ROBOCOP].texID,150,0,200,50); break;
			case 2: Image.DrawPicture(Image.ListTEX[TEX_DRAGON].texID,150,0,200,50); break;
			case 3: Image.DrawPicture(Image.ListTEX[TEX_HOLKA].texID,150,0,200,50); break;
			case 4: Image.DrawPicture(Image.ListTEX[TEX_DIABLO].texID,150,0,200,50); break;
			case 5: Image.DrawPicture(Image.ListTEX[TEX_SKELET].texID,150,0,200,50); break;
			case 6: Image.DrawPicture(Image.ListTEX[TEX_TIGER].texID,150,0,200,50); break;
			case 7: Image.DrawPicture(Image.ListTEX[TEX_VLK].texID,150,0,200,50); break;
			case 8: Image.DrawPicture(Image.ListTEX[TEX_SELMA].texID,150,0,200,50);	break;
			case 9: CText.DrawGLTextStred(BX+150,BY+30,50,"None",true); break;
		};
		glDisable(GL_BLEND);
		glColor3ub(0,(MouseOverLeft?200:0),250);
		glLoadIdentity();
		glTranslatef((float)BX,(float)BY+55,(float)0);
		glCallList(Skin.ListGL[MGL_SIPKAVLAVO]);
		glColor3ub(0,(MouseOverRight?200:0),250);
		glLoadIdentity();
		glTranslatef((float)BX+150,(float)BY+55,(float)0);
		glCallList(Skin.ListGL[MGL_SIPKAVPRAVO]);
	}
};
bool TProfilSetClass::Update()
{
	if(IsVisible)
	{
		if(Input.IsMouseIn(BX,BY,BX+200,BY+120)&&IsActivated)
		{
			if(!MouseOver) MouseOver = true;
			if(Input.IsMouseIn(BX,BY+55,BX+50,BY+80))
				MouseOverLeft = true;
			else
				MouseOverLeft = false;
			if(Input.IsMouseIn(BX+150,BY+55,BX+200,BY+80))
				MouseOverRight = true;
			else
				MouseOverRight = false;
			if((Input.Mouse.LeftB)&&(!Input.Mouse.LBDown)&&(MouseOverLeft))
			{
				Input.Mouse.LBDown = true;
				((Select==0) ? Select=Profils.PocetP-1 : Select--);
				Zvuky.PrehrajZvuk(Zvuky.swishlock);				
			}
			if((Input.Mouse.LeftB)&&(!Input.Mouse.LBDown)&&(MouseOverRight))
			{
				Input.Mouse.LBDown = true;
				((Select==Profils.PocetP-1) ? Select=0 : Select++);
				Zvuky.PrehrajZvuk(Zvuky.swishlock);			
			}
		}
		else MouseOver = MouseOverLeft = MouseOverRight = false;
	}
	
	return false;
};
//===================================================================< OBRSETCLASS >===============
void TObrSetClass::Redraw()
{
	if(IsVisible)
	{
		glLoadIdentity();
		glTranslatef((float)BX,(float)BY,(float)0);
		glColor3ub(200,200,200);
		switch(Select)
		{
			case 1: CText.DrawGLTextStred(BX+15,BY+45,80,"None",false); break;
			case 2: Image.DrawPicture(Image.ListTEX[TEX_DRAGON].texID,15,0,95,80); break;
			case 3: Image.DrawPicture(Image.ListTEX[TEX_HOLKA].texID,15,0,95,80); break;
			case 4: Image.DrawPicture(Image.ListTEX[TEX_DIABLO].texID,15,0,95,80); break;
			case 5: Image.DrawPicture(Image.ListTEX[TEX_SKELET].texID,15,0,95,80); break;
			case 6: Image.DrawPicture(Image.ListTEX[TEX_TIGER].texID,15,0,95,80); break;
			case 7: Image.DrawPicture(Image.ListTEX[TEX_VLK].texID,15,0,95,80); break;
			case 8: Image.DrawPicture(Image.ListTEX[TEX_SELMA].texID,15,0,95,80); break;
		};
		glColor3ub(0,(MouseOverLeft?200:0),250);
		glLoadIdentity();
		glTranslatef((float)BX,(float)BY+85,(float)0);
		glCallList(Skin.ListGL[MGL_SIPKAVLAVO]);
		glColor3ub(0,(MouseOverRight?200:0),250);
		glLoadIdentity();
		glTranslatef((float)BX+60,(float)BY+85,(float)0);
		glCallList(Skin.ListGL[MGL_SIPKAVPRAVO]);
	}
};
bool TObrSetClass::Update()
{
	if(IsVisible)
	{
		if(Input.IsMouseIn(BX,BY,BX+110,BY+110)&&IsActivated)
		{
			if(!MouseOver) MouseOver = true;
			if(Input.IsMouseIn(BX,BY+85,BX+50,BY+110))
				MouseOverLeft = true;
			else
				MouseOverLeft = false;
			if(Input.IsMouseIn(BX+60,BY+85,BX+110,BY+110))
				MouseOverRight = true;
			else
				MouseOverRight = false;
			if((Input.Mouse.LeftB)&&(!Input.Mouse.LBDown)&&(MouseOverLeft))
			{
				Input.Mouse.LBDown = true;
				((Select==8) ? Select=2 : Select++);
				Zvuky.PrehrajZvuk(Zvuky.swishlock);				
			}
			if((Input.Mouse.LeftB)&&(!Input.Mouse.LBDown)&&(MouseOverRight))
			{
				Input.Mouse.LBDown = true;
				((Select==2) ? Select=8 : Select--);
				Zvuky.PrehrajZvuk(Zvuky.swishlock);				
			}
		}
		else MouseOver = MouseOverLeft = MouseOverRight = false;
	}
	
	return false;
};
//===================================================================< TEXTCLASS >=================
void TTextClass::CreateFont()
{
	FontBase = glGenLists(256);								
	glBindTexture(GL_TEXTURE_2D,Image.ListTEX[MGL_FONT].texID);	
	for(int loop=0; loop<256; loop++)						
	{
		float cx=float(loop%16)/16.0f;						// X pozicia aktualneho pismenka
		float cy=float(loop/16)/16.0f;						// Y pozicia aktualneho pismenka

		glNewList(FontBase+loop,GL_COMPILE);				
			glBegin(GL_QUADS);								
				glTexCoord2f(cx,1.0f-cy-0.0625f);			// vlavo dole textura
				glVertex2i(0,0);							// vlavo dole 
				glTexCoord2f(cx+0.0625f,1.0f-cy-0.0625f);	// vpravo dole textura
				glVertex2i(16,0);							// vpravo dole
				glTexCoord2f(cx+0.0625f,1.0f-cy-0.001f);	// vpravo hore textura
				glVertex2i(16,16);							// vpravo hore
				glTexCoord2f(cx,1.0f-cy-0.001f);			// vlavo hore textura
				glVertex2i(0,16);							// vlavo hore
			glEnd();										
			glTranslated(14,0,0);							//posun doprava na dalsie pism.
		glEndList();										
	};														
};
void TTextClass::KillFont()
{
	glDeleteLists(FontBase,256);
};
void TTextClass::DrawGLText(int x,int y,char string[],bool UpSet)
{
	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_2D, Image.ListTEX[TEX_FONT].texID);	
	glMatrixMode(GL_PROJECTION);							
	glPushMatrix();											
	glLoadIdentity();										
	glOrtho(0,640,0,480,-1,1);								
	glMatrixMode(GL_MODELVIEW);								
	glPushMatrix();											
	glLoadIdentity();										
	glTranslated(x,480-y,0);								
	glListBase(TTextClass::FontBase-32+(UpSet?128:0));		
	if(!UpSet) glScalef(0.7f,0.7f,1.0f);
	else glScalef(0.8f,0.8f,1.0f);
	glCallLists((char)strlen(string),GL_BYTE,string);		
	glMatrixMode(GL_PROJECTION);							
	glPopMatrix();											
	glMatrixMode(GL_MODELVIEW);								
	glPopMatrix();											
	glDisable(GL_BLEND);
};
void TTextClass::DrawGLTextStred(int x,int y,int width,char string[],bool UpSet)
{
	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_2D, Image.ListTEX[TEX_FONT].texID);	
	glMatrixMode(GL_PROJECTION);							
	glPushMatrix();											
	glLoadIdentity();										
	glOrtho(0,640,0,480,-1,1);								
	glMatrixMode(GL_MODELVIEW);								
	glPushMatrix();											
	glLoadIdentity();										
	int Plus = (width - int( ((UpSet)?11:10) * strlen(string) ))/2;
	glTranslated(x+Plus,480-y,0);							
	glListBase(TTextClass::FontBase-32+(UpSet?128:0));		
	if(!UpSet) glScalef(0.7f,0.7f,1.0f);
	else glScalef(0.8f,0.8f,1.0f);
	glCallLists((char)strlen(string),GL_BYTE,string);		
	glMatrixMode(GL_PROJECTION);							
	glPopMatrix();											
	glMatrixMode(GL_MODELVIEW);								
	glPopMatrix();											
	glDisable(GL_BLEND);
};
//===================================================================< Kruzky >====================
TKruzokClass::TKruzokClass(int x, int y)
{
	cas = KtorySnimok = smer = 0;
	this->x = x;
	this->y = y;	
}
void TKruzokClass::Reset()
{
	cas = KtorySnimok = smer = 0;
}
void TKruzokClass::Redraw()
{
	if(cas>80)
	{
		(smer == 0) ? KtorySnimok++ : KtorySnimok--;
		cas = 0;
	}
	if(KtorySnimok>6) 
	{
		KtorySnimok = 6;
		smer = 1;
	}
	else
	if(KtorySnimok<0)
	{
		KtorySnimok = smer = 0;
	}
	glLoadIdentity();	
	Image.DrawPicture(Image.ListTEX[TEX_KRUZOK1 + KtorySnimok].texID,x,y,x+140,y+46);	
}
void TKruzokClass::Update()
{
	cas += Time.Sec;
}
void TKruzokClass::SetPosition(int x, int y)
{
    this->x = x;
	this->y = y;
}
//===================================================================< END >=======================