/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Implementacia umelej inteligencie
############################################################################################*/

#include "TMakros.h"						// hlavickovy subor s konstantami
#include "Tuneller.h"						// hlavickovy subor tejto hry
//===================================================================< DEFINITIONS >===============
//===================================================================< UICLASS >===================
void TUIClass::VratNovySmer(int *GoHoriz,int *GoVerti,bool *GoFire)
{
	//------------------------------------------- init cast ---------
	Tx = (*MyTank).x; Ty = (*MyTank).y;	THP = (*MyTank).HP;
	MyFortHP = (*(*MyTank).MyFort).HP;
	Sx = (*(*MyTank).MyEnemy).x; Sy = (*(*MyTank).MyEnemy).y;
	UIGoFire = false;
	
	InHome = (*(*MyTank).MyFort).AtHome();
	DamegeMe = ((*MyTank).HP < TTankClass::MaxTHP) ? true : false;
	BadDamage = ( int( float((*MyTank).HP *100)/float(TTankClass::MaxTHP) ) < 40)
		? true : false;
	MaloEnergy = ( int( float((*MyTank).Energy * 100)/float(TTankClass::MaxTEnergy) ) < 45)
		? true : false;
	GoodEnergy = ( int( float((*MyTank).Energy * 100)/float(TTankClass::MaxTEnergy) ) > 55)
		? true : false;
	FullEnergy = ((*MyTank).Energy == TTankClass::MaxTEnergy) ? true : false;
	SeeHunt =	( (Sx > (Tx - Game2.SubMapW/2))&&(Sx < (Tx + Game2.SubMapW/2))&&
				(Sy > (Ty - Game2.SubMapH/2))&&(Sy < (Ty + Game2.SubMapH/2)) )
				? true : false;
	InTray = ( ((Tx > (Sx-Game2.TankSize/2))&&(Tx < (Sx+Game2.TankSize/2))&&SeeHunt)||
			 ((*(*MyTank).MyFort).InFort(Sx,Sy)) )
				? true : false;
	SomeShootMe = (LTHP > THP) ? true : false;
	DamMyFort = (LMyFortHP > MyFortHP) ? true : false;
	DeadEnemy = ((*(*MyTank).MyEnemy).HP <= 0) ? true : false;
	//------------------------------------------- prikazova cast ----
	switch(UIMemo)
	{
		//*************************************************
		case 0: // < INFORT > tank je v domceku
			if(InHome)
			{
				if((!MaloEnergy || BadDamage) && InTray ) // obrana domceka
				{
					UIGoHoriz = UIGoVerti = 0;
					if(Tx > (Sx+Game2.TankSize/2)) UIGoHoriz = -2;
					if(Tx < (Sx-Game2.TankSize/2)) UIGoHoriz =  2;
					if(Ty > (Sy+Game2.TankSize/2)) UIGoVerti =  3;
					if(Ty < (Sy-Game2.TankSize/2)) UIGoVerti = -3;
					UIGoFire = CanFire();
					if(SmerGo == (UIGoHoriz+UIGoVerti))
					{
						UIGoHoriz = UIGoVerti = 0;
					}
					break;
				}
				if(IamPredator && SomeShootMe)
				{
					UIMemo = 3; break;
				}
				if(Obnovit)
				{
					if(FullEnergy && !DamegeMe) Obnovit = false;
					UIGoHoriz = UIGoVerti = 0; break;
				}
				if(IamPredator && INowWhere)
				{
					UIMemo = 4; break; // vies kde, tak chod a znic
				}
				if(Tx > ((*(*MyTank).MyFort).x + Rozdiel)) UIGoHoriz = -2;
				if(Tx < ((*(*MyTank).MyFort).x - Rozdiel)) UIGoHoriz = 2;
				if(UIGoVerti == 0) UIGoVerti = (rand()%2 == 1) ? -3 : 3;
				if((UIGoVerti ==  3)&&(Ty == LTy)) UIGoVerti = -3;
				if((UIGoVerti == -3)&&(Ty == LTy)) UIGoVerti =  3;
				break;
			}
			UIMemo = 1; // zacni prehladavat mapu
			Obnovit = true;
			break;
		//*************************************************
		case 1: // < SEARCHM > prehladavanie mapy
			if(InHome)
			{
				UIMemo = 0; break;
			}
			if(IamPredator && GoodEnergy && SeeHunt && !BadDamage)
			{
				UIMemo = 3; break; // zautoc
			}
			if(MaloEnergy || DamegeMe)
			{
				UIMemo = 2; break; // utek domov
			}
			if(++KratGo < (2*rand()%10 + 7) )	break;
			KratGo = 0;
			UIGoHoriz = UIGoVerti = 0;
			if(rand()%2 == 1) UIGoHoriz += 2;
			if(rand()%2 == 1) UIGoHoriz -= 2;
			if(rand()%2 == 1) UIGoVerti += 3;
			if(rand()%2 == 1) UIGoVerti -= 3;
			break;
		//*************************************************
		case 2: // < RETREAT > utek domov
			if(((UIGoHoriz != 0)&&(UIGoVerti != 0)&&(Tx == LTx)&&(Ty == LTy)&&Utekam) 
				|| BadDamage)
			{
				UIMemo = 5; break;
			}
			switch(UtekStav)
			{
				//-----------------------------------------
				case 0: // utekame do bodu A||B
					if(!DoBoduA && !DoBoduB)
						if(Ty > (*(*MyTank).MyFort).y)
							DoBoduB = true;
						else
							DoBoduA = true;
					Utekam = true;
					if(DoBoduA)
					{
						GoToPoint((*(*MyTank).MyFort).BodAX,(*(*MyTank).MyFort).BodAY);
					}
					if(DoBoduB)
					{
						GoToPoint((*(*MyTank).MyFort).BodBX,(*(*MyTank).MyFort).BodBY);
					}
					if((UIGoHoriz == 0) && (UIGoVerti == 0))
					{
						UtekStav = 1;
					}
					break;
				//-----------------------------------------
				case 1: // dovnutra domceka
					UIGoVerti = UIGoHoriz = 0;
					if( (Ty >= ((*(*MyTank).MyFort).y - Rozdiel))&&
						(Ty <= ((*(*MyTank).MyFort).y + Rozdiel))&&InHome)
					{
						DoBoduA = DoBoduB = Utekam = false;
						UtekStav = UIMemo = 0; break;
					}
					if(DoBoduA)
					{
						UIGoVerti = -3; break;
					}
					if(DoBoduB)
					{
						UIGoVerti = 3; break;
					}
					break;
				//-----------------------------------------
				default:
					break;
			}
			break;
		//*************************************************
		case 3: // < OFFENSIVE > ofenziva
			INowWhere = true;
			if(MaloEnergy || (DamMyFort && InHome))
			{
				UIMemo = 2; Obnovit = true; break;
			}
			UIGoHoriz = UIGoVerti = 0;
			if(Tx > (Sx+Game2.TankSize/2)) UIGoHoriz = -2;
			if(Tx < (Sx-Game2.TankSize/2)) UIGoHoriz =  2;
			if(Ty > (Sy+Game2.TankSize/2)) UIGoVerti =  3;
			if(Ty < (Sy-Game2.TankSize/2)) UIGoVerti = -3;
			if(SeeHunt || InHome || SomeShootMe)
				UIGoFire = CanFire();
			break;
		//*************************************************
		case 4: // < HUNT > takze zacina lov
            if(!DoBoduA && !DoBoduB)
				if(Ty < Sy)
					DoBoduB = true;
				else
					DoBoduA = true;
			if(DoBoduA)
			{
				DoBoduA = !GoToPoint((*(*MyTank).MyFort).BodAX,(*(*MyTank).MyFort).BodAY);
			}
			if(DoBoduB)
			{
				DoBoduB = !GoToPoint((*(*MyTank).MyFort).BodBX,(*(*MyTank).MyFort).BodBY);
			}
			if(!DoBoduA && !DoBoduB)
			{
				UIMemo = 3; break;
			}
			break;
		//*************************************************
		case 5: // < KAMIKADZE > neviem sa pohnut alebo uz nato nieje cas
			INowWhere = true;
			if(DeadEnemy || InHome)		// skon��me a� ke� padne nepriate� (alebo my)
			{
				UIMemo = 2; break;
			}
			UIGoHoriz = UIGoVerti = 0;
			if(Tx > (Sx+Game2.TankSize/2)) UIGoHoriz = -2;
			if(Tx < (Sx-Game2.TankSize/2)) UIGoHoriz =  2;
			if(Ty > (Sy+Game2.TankSize/2)) UIGoVerti =  3;
			if(Ty < (Sy-Game2.TankSize/2)) UIGoVerti = -3;
			if(SeeHunt)
				UIGoFire = CanFire();
			break;
		//*************************************************
		default:
			break;
	}
	//------------------------------------------- deinitializacna cast -
	LTx = Tx; LTy = Ty; LTHP = THP; LMyFortHP = MyFortHP;
	SmerGo = (UIGoHoriz + UIGoVerti);
	*GoHoriz = UIGoHoriz;
	*GoVerti = UIGoVerti;
	*GoFire = UIGoFire;
};
bool TUIClass::GoToPoint(int Px,int Py)
{
	UIGoHoriz = UIGoVerti = 0;
	if( (Tx >= (Px-Rozdiel)) && (Tx <= (Px+Rozdiel)) &&
		(Ty >= (Py-Rozdiel)) && (Ty <= (Py+Rozdiel)) )
		return true;
	if(Ty > (Py+Rozdiel)) UIGoVerti = 3;
	if(Ty < (Py-Rozdiel)) UIGoVerti = -3;
	if(Tx > (Px+Rozdiel)) UIGoHoriz = -2;
	if(Tx < (Px-Rozdiel)) UIGoHoriz = 2;
	return false;
};
bool TUIClass::CanFire()
{
	if( (Tx > (Sx-Game2.TankSize/2)) || (Tx < (Sx+Game2.TankSize/2)) ||
		(Ty > (Sy-Game2.TankSize/2)) || (Ty < (Sy+Game2.TankSize/2)) )
		return true;
	else
	{
		if(Tx > Sx)
		{
			if(Ty > Sy)
			{
				if( ((Tx-Sx) > ((Ty-Sy)-(Game2.TankSize/2-1))) ||
					((Tx-Sx) < ((Ty-Sy)+(Game2.TankSize/2-1))) )
					return true;
			}
			else
				if( ((Tx-Sx) > ((Sy-Ty)-(Game2.TankSize/2-1))) ||
					((Tx-Sx) < ((Sy-Ty)+(Game2.TankSize/2-1))) )
					return true;
		}
		else
		{
			if(Ty > Sy)
			{
				if( ((Sx-Tx) > ((Ty-Sy)-(Game2.TankSize/2-1))) ||
					((Sx-Tx) < ((Ty-Sy)+(Game2.TankSize/2-1))) )
					return true;
			}
			else
				if( ((Sx-Tx) > ((Sy-Ty)-(Game2.TankSize/2-1))) ||
					((Sx-Tx) < ((Sy-Ty)+(Game2.TankSize/2-1))) )
					return true;
		}
	}
	return false;
};
void TUIClass::Reset()
{
	InHome = DamegeMe = MaloEnergy = SomeShootMe = DamMyFort = Utekam = false;
	UIGoFire = DoBoduA = DoBoduB = BadDamage = SeeHunt = InTray = Obnovit = DeadEnemy = false;
	FullEnergy = GoodEnergy = true;

	KratGo = SmerGo = UIMemo = UIGoHoriz = UIGoVerti = UtekStav = 0;
	Tx = LTx = Ty = LTy = Sx = Sy = THP = LTHP = MyFortHP = LMyFortHP = 0;
};
//===================================================================< END >=======================