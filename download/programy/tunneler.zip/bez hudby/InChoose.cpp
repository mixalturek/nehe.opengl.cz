/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Obrazovka pre vyber dvoch profilov a zacatie samotnej hry
############################################################################################*/

#include <windows.h>						// hlavickovy subor pre winapi
#include <gl\gl.h>							// hlavickovy subor pre OpenGL
#include <gl\glu.h>							// hlavickovy subor pre Glu
#include <stdio.h>							// standardny vstup / vystup
#include <stdarg.h>							// funkcie s variabilnym poctom argumentov
#include <string.h>							// praca s retazcami
#include "Tuneller.h"						// hlavickovy subor tejto hry
//===================================================================< DEFINICIE OBJEKTOV >========
TChooseClass	Choose;
//===================================================================< CHOOSECLASS >===============
TChooseClass::TChooseClass()
{
	VyberL.SetMe(60,90);
	VyberP.SetMe(380,90);
	BPlay.SetMe(440,350,"Play !!");
	BCan.SetMe(440,400,"Cancel");
	BDSet.SetMe(50,390,"Profil Set");
	KruzokL.SetPosition(100,220);
	KruzokP.SetPosition(420,222);	
};
void TChooseClass::Redraw()
{
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	Image.DrawPicture(Image.ListTEX[TEX_POZADIEBLACK].texID,0,0,640,480);
	BPlay.Redraw();
	BCan.Redraw();
	BDSet.Redraw();
	VyberL.Redraw();
	VyberP.Redraw();
	KruzokL.Redraw();
	KruzokP.Redraw();
	glColor3ub(250,0,0);
	CText.DrawGLText(110,70,"Red Player",false);
	glColor3ub(0,0,250);
	CText.DrawGLText(425,70,"Blue Player",false);
	glColor3ub(0,250,0);
	CText.DrawGLTextStred(0,120,640,"VERSUS",true);
	Cursor.Redraw();
};
void TChooseClass::Update()
{
	Zvuky.PustiHudbu(Zvuky.HudbaMenu);
	if(BPlay.Update())
	{
		Profils.BluePPlayer = Profils.Hraci[VyberP.Select];
		Profils.BPL = VyberP.Select;
		Profils.RedLPlayer = Profils.Hraci[VyberL.Select];
		Profils.RPL = VyberL.Select;
		Game.SetScreen(Game.InGAME2);
		//Game.SetScreen(Game.InRESULTS);
	};
	if(VyberL.Select != VyberP.Select) BPlay.IsActivated = true;
	else BPlay.IsActivated = false;
	if(BCan.Update())
	{
		Game.SetScreen(Game.InMENU);
	};
	if(BDSet.Update())
	{
		Game.SetScreen(Game.InSET);				
		Setting.ZoznamProfilov.Reset(true,true,true);
		Setting.BZmenit.Reset(true,true,true);		
	};
	VyberL.Update();
	VyberP.Update();
	KruzokL.Update();
	KruzokP.Update();	
};
bool TChooseClass::Init()
{
	BPlay.Reset(true,true,true);
	BCan.Reset(true,true,true);
	BDSet.Reset(true,true,true);
	VyberL.Reset(true,true);	
	VyberP.Reset(true,true);
	VyberL.Select = 0;
	VyberP.Select = 0;
	KruzokL.Reset();
	KruzokP.Reset();

	return true;
};
bool TChooseClass::DeInit()
{	
	return true;
};
//===================================================================< END >=======================