/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Obrazovka nastaveni
############################################################################################*/

#include <windows.h>						// hlavickovy subor pre winapi
#include <gl\gl.h>							// hlavickovy subor pre OpenGL
#include <gl\glu.h>							// hlavickovy subor pre Glu
#include <stdio.h>							// standardny vstup / vystup
#include <stdarg.h>							// funkcie s variabilnym poctom argumentov
#include <string.h>							// praca s retazcami
#include "Tuneller.h"						// hlavickovy subor tejto hry
//===================================================================< DEFINICIE OBJEKTOV >========
TSetClass	Setting;
//===================================================================< SETCLASS >==================
TSetClass::TSetClass()
{
	BOK.SetMe(440,400,"OK");
	BSav.SetMe(440,350,"Uloz profil");
	BZrusit.SetMe(440,400,"Zrusit");
	BZmenit.SetMe(440,350,"Zmenit");
	ZoznamProfilov.SetMe(0,0,"PROFILY");
	NastavenieZvuku.SetMe(0,0,"ZVUK");
	NastavenieGrafiky.SetMe(0,0,"HRA a GRAFIKA");
	NovyProfil.SetMe(0,0,"Novy Profil");
	Ponuka.SetMe(400,0,"");
	FBProf.SetMe(410,80,"Profily");
	FBProf.SetMySize(190,20);
	FBZvuk.SetMe(410,100,"Zvuk");
	FBZvuk.SetMySize(190,20);
	FBZvuky.SetMe(150,90,"Zapnute");
	FBZvuky.SetMySize(190,20);
	FBHudba.SetMe(150,115,"Zapnuta");
	FBHudba.SetMySize(190,20);
	FBGrafika.SetMe(410,120,"Hra a grafika");
	FBGrafika.SetMySize(190,20);
	FBDetaily.SetMe(170,90,"Stredne");
	FBDetaily.SetMySize(190,20);
	FBHra.SetMe(170,115,"3");
	FBHra.SetMySize(190,20);
	FBDomcek.SetMe(170,140,"Ano");
	FBDomcek.SetMySize(190,20);
	BDAno.SetMe(50,390,"Ano");
	BDNie.SetMe(250,390,"Nie");
	Menenie = false;
};
void TSetClass::Redraw()
{
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	Image.DrawPicture(Image.ListTEX[TEX_POZADIE].texID,0,0,640,480);
	BOK.Redraw();
	BSav.Redraw();
	BZrusit.Redraw();
	BZmenit.Redraw();
	BDAno.Redraw();
	BDNie.Redraw();
	ZoznamProfilov.Redraw();
	NastavenieZvuku.Redraw();
		if(NastavenieZvuku.IsVisible)
		{
			if(NastavenieZvuku.GoX == 0)
			{
				glColor3ub(100,100,200);
				CText.DrawGLText(60,110,"Zvuky:",false);
				CText.DrawGLText(60,135,"Hudba:",false);
				FBZvuky.Redraw();
				FBHudba.Redraw();
			}
		};
	NastavenieGrafiky.Redraw();
		if(NastavenieGrafiky.IsVisible)
		{
			if(NastavenieGrafiky.GoX == 0)
			{	
				glColor3ub(100,100,200);
				CText.DrawGLText(60,110,"Detaily mapy:",false);				
				CText.DrawGLText(60,135,"Pocet vyhier:",false);
				CText.DrawGLText(60,160,"Znicitelny domcek:",false);
				FBDetaily.Redraw();
				FBHra.Redraw();
				FBDomcek.Redraw();
			}
		}
	NovyProfil.Redraw();
	Ponuka.Redraw();
		if(Ponuka.IsVisible)
		{
			if(Ponuka.GoX == 0)
			{				
				glColor3ub(100,100,200);
				CText.DrawGLTextStred(405,80,195,"NASTAVENIA",true);
				FBProf.Redraw();
				FBZvuk.Redraw();
				FBGrafika.Redraw();
			}
		};
	Cursor.Redraw();
};
void TSetClass::Update()
{
	Zvuky.PustiHudbu(Zvuky.HudbaMenu);
	if(BOK.Update())
	{
		Game.SetScreen(Game.GoBACK);
	};
	if(BSav.Update())
	{				
		strcpy(Profils.Hraci[Profils.PocetP].Nick,NovyProfil.IBName.Text);
		Profils.Hraci[Profils.PocetP].CountOfGame = 0;
		Profils.Hraci[Profils.PocetP].CountOfWins = 0;
		Profils.Hraci[Profils.PocetP].SetControls(NovyProfil.Kody[0],NovyProfil.Kody[1],
			NovyProfil.Kody[2],NovyProfil.Kody[3],NovyProfil.Kody[4]);
		Profils.Hraci[Profils.PocetP].SetControlsNames(NovyProfil.FBOvladanie[0].Text,
			NovyProfil.FBOvladanie[1].Text,NovyProfil.FBOvladanie[2].Text,
			NovyProfil.FBOvladanie[3].Text,NovyProfil.FBOvladanie[4].Text);
		Profils.Hraci[Profils.PocetP].ObrID = NovyProfil.ObrSet.Select;		
		NovyProfil.Reset(false,false,false);
		ZoznamProfilov.Reset(true,true,true);
		BZrusit.Reset(false,false,false);
		BZmenit.Reset(true,true,true);
		BSav.Reset(false,false,false);
		BOK.Reset(true,true,true);			
		ZoznamProfilov.VybratyProfil = Profils.PocetP-2;
		if(Profils.PocetP-2 >= 13) ZoznamProfilov.Scroll = (Profils.PocetP-1-13)*16;
		Profils.PocetP++;
	};
	if(BZrusit.Update())
	{
		Menenie = false;
		BOK.Reset(true,true,true);
		BZmenit.Reset(true,true,true);
		BZrusit.Reset(false,false,false);
		BSav.Reset(false,false,false);		
		NovyProfil.Reset(false,false,false);
		ZoznamProfilov.Reset(true,true,true);
		Ponuka.Reset(true,true,false);
	}
	if(BZmenit.Update())
	{
		int j = ZoznamProfilov.VybratyProfil+2;
		int s = ZoznamProfilov.Scroll;
		if(!Menenie)
		{			
			NovyProfil.Reset(true,true,true);		
			ZoznamProfilov.IsActivated = false;
			ZoznamProfilov.IsVisible = false;
			BOK.Reset(false,false,false);			
			BZrusit.Reset(true,true,true);					
			strcpy(NovyProfil.IBName.Text,Profils.Hraci[j].Nick);
			strcpy(NovyProfil.FBOvladanie[0].Text,Profils.Hraci[j].Controls.UpName);
			strcpy(NovyProfil.FBOvladanie[1].Text,Profils.Hraci[j].Controls.DownName);
			strcpy(NovyProfil.FBOvladanie[2].Text,Profils.Hraci[j].Controls.LeftName);
			strcpy(NovyProfil.FBOvladanie[3].Text,Profils.Hraci[j].Controls.RightName);
			strcpy(NovyProfil.FBOvladanie[4].Text,Profils.Hraci[j].Controls.FireName);
			NovyProfil.Kody[0] = Profils.Hraci[j].Controls.Up;
			NovyProfil.Kody[1] = Profils.Hraci[j].Controls.Down;
			NovyProfil.Kody[2] = Profils.Hraci[j].Controls.Left;
			NovyProfil.Kody[3] = Profils.Hraci[j].Controls.Right;
			NovyProfil.Kody[4] = Profils.Hraci[j].Controls.Fire;
			NovyProfil.ObrSet.Select = Profils.Hraci[j].ObrID;
			Menenie = true;		
			Ponuka.Reset(true,false,false);
		}
		else
		{			
			if(!NovyProfil.IBName.InsertToMe) 
				strcpy(Profils.Hraci[j].Nick,NovyProfil.IBName.Text);			
			Profils.Hraci[j].SetControls(NovyProfil.Kody[0],NovyProfil.Kody[1],
				NovyProfil.Kody[2],NovyProfil.Kody[3],NovyProfil.Kody[4]);
			Profils.Hraci[j].SetControlsNames(NovyProfil.FBOvladanie[0].Text,
				NovyProfil.FBOvladanie[1].Text,NovyProfil.FBOvladanie[2].Text,
				NovyProfil.FBOvladanie[3].Text,NovyProfil.FBOvladanie[4].Text);
			Profils.Hraci[j].ObrID = NovyProfil.ObrSet.Select;
			NovyProfil.Reset(false,false,false);
			ZoznamProfilov.Reset(true,true,true);
			ZoznamProfilov.VybratyProfil = j-2;
			ZoznamProfilov.Scroll = s;
			BZrusit.Reset(false,false,false);			
			BOK.Reset(true,true,true);	
			Menenie = false;	
			Ponuka.Reset(true,true,false);
		}
	}
	ZoznamProfilov.Update();	
	if((ZoznamProfilov.GoX == 0)&&(ZoznamProfilov.IsVisible))
	{
		if(ZoznamProfilov.New && Profils.PocetP<100)
		{			
			NovyProfil.Reset(true,true,true);			
			ZoznamProfilov.Reset(false,false,true);			
			BOK.Reset(false,false,false);
			BZmenit.Reset(false,false,false);
			BZrusit.Reset(true,true,true);
			ZoznamProfilov.New = false;
			Ponuka.Reset(true,false,false);
		}
		if(ZoznamProfilov.Del && Profils.PocetP>2)
		{
			ZoznamProfilov.IsActivated = false;
			BDAno.Reset(true,true,true);
			BDNie.Reset(true,true,true);
			ZoznamProfilov.Del = false;
			Ponuka.IsActivated = false;
			BOK.IsActivated = false;
			BZmenit.IsActivated = false;
		}
	};
	if(BDAno.Update())
	{
		int j = ZoznamProfilov.VybratyProfil + 2;
		if(j >= 2 && Profils.PocetP > 2)
		{
			for(int i=j; i<Profils.PocetP-1; i++)
			{
				Profils.Hraci[i] = Profils.Hraci[i+1];
			}
			Profils.PocetP--;
			if(ZoznamProfilov.VybratyProfil > 0) ZoznamProfilov.VybratyProfil--;
			if(ZoznamProfilov.Scroll >= 16) ZoznamProfilov.Scroll -= 16; 
		}		
		ZoznamProfilov.IsActivated = true;
		BDAno.Reset(false,false,true);
		BDNie.Reset(false,false,true);
		Ponuka.IsActivated = true;
		BOK.IsActivated = true;
		BZmenit.IsActivated = true;
	}
	if(BDNie.Update())
	{
		BDAno.Reset(false,false,true);
		BDNie.Reset(false,false,true);
		ZoznamProfilov.IsActivated = true;
		Ponuka.IsActivated = true;
		BOK.IsActivated = true;
		BZmenit.IsActivated = true;
	}
	NastavenieZvuku.Update();
	if(NastavenieZvuku.IsVisible && NastavenieZvuku.GoX==0)
	{
		FBZvuky.Reset(true,true,false);
		FBHudba.Reset(true,true,false);
		if(FBZvuky.Update())
		{
			if(Zvuky.Zvuky)
			{
				strcpy(FBZvuky.Text,"Vypnute");
				Zvuky.Zvuky = false;
			}
			else
			{
				strcpy(FBZvuky.Text,"Zapnute");
				Zvuky.Zvuky = true;
			}
		}
		if(FBHudba.Update())
		{
			if(Zvuky.Hudba)
			{
				strcpy(FBHudba.Text,"Vypnuta");
				Zvuky.Hudba = false;
				Zvuky.ZastavHudbu(Zvuky.HudbaMenu);
			}
			else
			{
				strcpy(FBHudba.Text,"Zapnuta");
				Zvuky.Hudba = true;
				Zvuky.PustiHudbu(Zvuky.HudbaMenu);
			}
		}
	}
	NastavenieGrafiky.Update();
	if(NastavenieGrafiky.GoX == 0 && NastavenieGrafiky.IsVisible)
	{
		FBDetaily.Reset(true,true,false);
		FBHra.Reset(true,true,false);
		FBDomcek.Reset(true,true,false);
		if(FBDetaily.Update())
		{
			if(Game2.MapZoom == 1) 
			{
				Game2.MapZoom = 10;
				strcpy(FBDetaily.Text,"Nizke");
			}
			else
			if(Game2.MapZoom == 2)
			{
				Game2.MapZoom = 1;
				strcpy(FBDetaily.Text,"Vysoke");
			}
			else
			if(Game2.MapZoom == 5) 
			{	
				Game2.MapZoom = 2;
				strcpy(FBDetaily.Text,"Slusne");
			}
			else
			if(Game2.MapZoom == 10) 
			{
				Game2.MapZoom = 5;
				strcpy(FBDetaily.Text,"Stredne");
			}
		}
		if(FBHra.Update())
		{
			((Game2.PocetVyhier+1) > 10) ? Game2.PocetVyhier = 1 : Game2.PocetVyhier++;
			char s[5];
			sprintf(s,"%d",Game2.PocetVyhier);
			strcpy(FBHra.Text,s);
		}
		if(FBDomcek.Update())
		{
			Game2.ZnicitelnyDomcek = !Game2.ZnicitelnyDomcek;
			if(Game2.ZnicitelnyDomcek)
				strcpy(FBDomcek.Text,"Ano");
			else strcpy(FBDomcek.Text,"Nie");
		}
	}
	NovyProfil.Update();
	if((NovyProfil.IsVisible && Menenie) || ZoznamProfilov.IsVisible) 
		BZmenit.IsVisible = true;
	else BZmenit.IsVisible = false;
	Ponuka.Update();
	if((Ponuka.GoX == 0) && Ponuka.IsVisible && !Ponuka.IsActivated)
	{
		FBProf.Reset(true,false,false);
		FBZvuk.Reset(true,false,false);
		FBGrafika.Reset(true,false,false);
	}
	if((Ponuka.GoX == 0) && Ponuka.IsVisible && Ponuka.IsActivated)
	{		
		FBProf.Reset(true,true,false);
		FBZvuk.Reset(true,true,false);
		FBGrafika.Reset(true,true,false);
		if(FBProf.Update())
		{			
			NastavenieZvuku.Reset(false,false,true);
			FBZvuky.Reset(false,false,false);
			FBHudba.Reset(false,false,false);
			NastavenieGrafiky.Reset(false,false,true);
			FBDetaily.Reset(false,false,false);	
			FBHra.Reset(false,false,false);
			FBDomcek.Reset(false,false,false);
			ZoznamProfilov.Reset(true,true,true);
			BZmenit.Reset(true,true,true);
			NovyProfil.Reset(false,false,true);
		};
		if(FBZvuk.Update())
		{			
			NastavenieZvuku.Reset(true,false,true);
			NastavenieGrafiky.Reset(false,false,true);
			FBDetaily.Reset(false,false,false);
			FBHra.Reset(false,false,false);
			FBDomcek.Reset(false,false,false);
			ZoznamProfilov.Reset(false,false,true);
			NovyProfil.Reset(false,false,true);
		};
		if(FBGrafika.Update())
		{
			NastavenieZvuku.Reset(false,false,true);
			FBZvuky.Reset(false,false,false);
			FBHudba.Reset(false,false,false);
			NastavenieGrafiky.Reset(true,false,true);
			ZoznamProfilov.Reset(false,false,true);
			NovyProfil.Reset(false,false,true);
		}
	};	
};
bool TSetClass::Init()
{
	BOK.Reset(true,true,true);
	BSav.Reset(false,false,false);
	BZrusit.Reset(false,false,false);
	BZmenit.Reset(false,false,false);
	Ponuka.Reset(true,true,true);
	ZoznamProfilov.Reset(false,false,true);
	NastavenieZvuku.Reset(false,false,true);
	NastavenieGrafiky.Reset(false,false,true);
	NovyProfil.Reset(false,false,true);
	FBProf.Reset(false,true,false);
	FBZvuk.Reset(false,true,false);
	FBZvuky.Reset(false,false,false);
	FBHudba.Reset(false,false,false);
	FBGrafika.Reset(false,false,false);
	FBDetaily.Reset(false,false,false);
	FBHra.Reset(false,false,false);
	FBDomcek.Reset(false,false,false);
	BDAno.Reset(false,false,true);
	BDNie.Reset(false,false,true);
	Menenie = false;

	return true;
};
bool TSetClass::DeInit()
{	
	return true;
};
//===================================================================< END >=======================