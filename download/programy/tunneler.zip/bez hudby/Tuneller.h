/*############################################################################################
Program:			Tunneler											 			 
Autori:				Vladim�r Hoffman - Gabriel G�cy									 
Datum:				9.2.2005
Verzia:				0.4.4
Ucel:				Hlavny hlavickovy subor so vsetkymi triedami
############################################################################################*/

#ifndef TUNELLER_GAME_H						// Kontrola p�znaku tohto hlavi�kov�ho s�boru
#define TUNELLER_GAME_H						// Defin�cia pr�znaku

#include <windows.h>						// hlavickovy subor pre winapi
#include <gl\gl.h>							// hlavickovy subor pre OpenGL
#include <gl\glu.h>							// hlavickovy subor pre Glu
#include "TMakros.h"						// hlavickovy subor s konstantami
#include <queue>							// fronta
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/ TKERNEL \XXXX
//===================================================================< GAMECLASS >=================
// Hlavna trieda hry, ktora prepina stavy a rozhoduje, co sa ma vykreslit a updatovat
class TGameClass							
{
	public:
		// jednotlive stavy, kde sa moze hra dostat
		enum	TStateE {InLOAD,InMENU,InSET,InCHOOSE,InRESULTS,InGAME2,GoBACK};
	private:
		TStateE	State, LastState;			// Aktu�lna a predo�l� sc�na
		bool	ShowFPS;					// Uk�za� Frame Per Second - FPS
		bool	ShowSXY;					// Uk�za� poz�ciu kurzora
	public:
		//------------------------------------------------------------------------------------
		TGameClass();						// konstruktor		
		//------------------------------------------------------------------------------------
		bool	Init();		// inicializuje opengl a nastavi screen na InMENU, vrati true, ak 
							// vsetko prebehne vporiadku, inak false
		//------------------------------------------------------------------------------------
		bool	Deinit();	// vola sa pri konceni programu, zastavi hudbu a odstrani textury
							// vrati true, ak vsetko prebehne vporiadku, inak false
		//------------------------------------------------------------------------------------
		void	GlobalKey();				// monitoruje globalne funkcne klavesy
		//------------------------------------------------------------------------------------
		bool	SetScreen(TStateE Screen);	// Nastav� nov� sc�nu, vrati true, ak uspesne, 
											// inak false
		//------------------------------------------------------------------------------------
		void	ReDraw();					// Prekreslenie sc�ny
		void	Update();					// Update sc�ny
};
//===================================================================< INPUTCLASS >================
// Trieda na narabanie so vstupmi z klavesnice a mysi
class TInputClass							
{
	public:
		struct								// �trukt�ra pre my�ku
		{
			int		x, y;					// Poz�cia x,y
			bool	LeftB, RightB;			// Pr�znak stla�enia �av�ho a prav�ho tla�idla
			bool	LBDown, RBDown;			// Priznak, ze lave alebo prave tlacidlo je
			bool	Showme;					// uz stlacene dlhsie
		} Mouse;

		bool		Key[256];				// Pr�znaky stla�enia kl�ves
		bool		ShadeKey[256];			// pr�znaky pre spracovanie opakovan�ho stla�enia
		char		InputChar;				// ASCII kod stlacenej klavesy
		char		KeyName[20];			// meno stlacenej klavesy
		int			VirtualKey;				// virtualny kod stlacenej klavesy
		//------------------------------------------------------------------------------------
		TInputClass();						//konstruktor
		//------------------------------------------------------------------------------------
		// metoda na zistenie pozicie mysi v urcitom obdlzniku, vracia true, ak sa kurzor
		// nachadza v zadanom obdlzniku, inak vracia false
		// parametre:	x - x-ova pozicia laveho horneho bodu obdlznika
		//				y - y-ova pozicia laveho horneho bodu obdlznika
		//				xx - x-ova pozicia praveho dolneho bodu obdlznika
		//				yy - y-ova pozicia praveho dolneho bodu obdlznika
		bool IsMouseIn(int x,int y,int xx,int yy);
		//------------------------------------------------------------------------------------
		// metoda na zistenie pozicie mysi v urcitom obdlzniku, vracia true, ak sa kurzor
		// nachadza v zadanom obdlzniku, inak vracia false
		// parametre:	x - x-ova pozicia laveho horneho bodu obdlznika
		//				y - y-ova pozicia laveho horneho bodu obdlznika
		//				W - sirka obdlznika
		//				H - vyska obdlznika
		bool IsMouseInR(int x,int y,int W,int H);
};
//===================================================================< TIMECLASS >=================
// Trieda na spracovanie casu
class TTimeClass							
{
	public:
		unsigned long LastTick;				// �as posledn�ho z�znamu �asu
		unsigned long NowTick;				// Aktu�lne zaznamenan� �as
		unsigned long Sec;					// Rozdiel medzi prekreslen�m v ms		
};
//===================================================================< ZVUKYCLASS >================
// Trieda na prehravanie zvukov a hudby
class TZvukyClass							
{
	public:
		enum THudbaE {HudbaMenu,HudbaGame2};			// typ hudby, ktora sa ma prehrat		
		enum TZvukE  {swishin,mouseover,mousedown,		// typ zvuku, ktory sa ma prehrat
			swishlock,swishout,psibolt,explosion,koniec};		
		unsigned long	MusicSec, MusicInGame2Sec;	// dlzka prehravania hudby
		bool			Hudba, Zvuky;				// priznak prehravania zvukov a hudby 
		//------------------------------------------------------------------------------------
		// konstruktor
		TZvukyClass(): Hudba(true),Zvuky(true),MusicSec(0),MusicInGame2Sec(0) {};
		//------------------------------------------------------------------------------------
		// pusta a kontroluje prehravanie zadaneho typu hudby, po skonceni
		// prehravania pusta hudbu od zaciatku, stale dokola, je nutne ju volat v update
		// parametre:	ktora - urcuje typ hudby, ktory sa ma prehravat
		void PustiHudbu(THudbaE ktora);
		//------------------------------------------------------------------------------------
		// zastavi zadanu hudbu
		// parametre:	ktora - urcuje typ hudby, ktora sa ma zastavit
		void ZastavHudbu(THudbaE ktora);
		//------------------------------------------------------------------------------------
		// prehra zadany zvuk
		// parametre:	ktory - urcuje typ zvuku, ktory sa ma prehrat
		void PrehrajZvuk(TZvukE ktory);	
};
//===================================================================< CONTROLCLASS >==============
// Trieda pre uchovanie ovl�dac�ch znakov v hre
class TControlsClass						
{
	public:
		int		Up, Down, Left, Right, Fire;	// virtualne kody ovladacich klaves
		// pomenovania jednotlivych ovladacich klaves
		char	UpName[20], DownName[20], LeftName[20], RightName[20], FireName[20];
};
//===================================================================< PLAYERCLASS >===============
// Trieda uchov�vaj�ca �daje o jednom hr��ovi
class TPlayerClass						
{
	public:
		TControlsClass	Controls;						// ovladanie
		char			Nick[256];						// prezyvka
		int				CountOfGame, CountOfWins, ObrID;// pocet hier, vyhier a obrazok
		bool			UI;								// urcuje, ci sa jedna o UI
		//------------------------------------------------------------------------------------
		TPlayerClass();									// kontruktor
		//------------------------------------------------------------------------------------
		// nastavuje ovladanie pre aktualneho hraca
		// parametre:	Up - klavesa pre smer hore
		//				Down - klavesa pre smer dole
		//				Left - klavesa pre smer dolava
		//				Right - klavesa pre smer doprava
		//				Fire - klavesa pre strelbu
		void SetControls(int Up,int Down,int Left,int Right,int Fire);
		//------------------------------------------------------------------------------------
		// nastavuje nazvy ovladacich klaves
		// parametre:	Up - nazov klavesy pre smer hore
		//				Down - nazov klavesy pre smer dole
		//				Left - nazov klavesy pre smer dolava
		//				Right - nazov klavesy pre smer doprava
		//				Fire - nazov klavesy pre strelbu
		void SetControlsNames(char* Up,char* Down,char* Left,char* Right,char* Fire);
};
//===================================================================< PROFILCLASS >===============
// Trieda v�etk�ch evidovan�ch hr��ov v hre
class TProfilClass							
{
	public:
		TPlayerClass	Hraci[100];					// pole vsetkych hracov, maximalne 100
		TPlayerClass	RedLPlayer, BluePPlayer;	// vybraty lavy a pravy hrac
		int				PocetP, RPL, BPL;			// celkovy pocet hracov, cislo laveho a
													// praveho hraca v poli
		//------------------------------------------------------------------------------------
		bool	LoadProfils();						// nacita profily zo suboru profiles.dat
		bool	SaveProfils();						// ulozi profily do zuboru profiles.dat
};
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/ TGRAPH \XXXXX
//===================================================================< IMAGECLASS >================
// Trieda pre pr�cu s obr�zkami
class TImageClass							
{
	public:
		typedef struct
		{
			GLubyte	*imageData;				// data obrazku
			GLuint	bpp;					// pocet bitov na pixel, farebna hlbka
			GLuint	width;					// sirka
			GLuint	height;					// vyska
			GLuint	texID;					// handle textury
			GLuint	type;					// typ obrazku
		} Textura;
		
		Textura ListTEX[TEX_TEXTURE_NUM];	// Pole pre v�etky text�ry
		Textura VyslednaMapa;
		//------------------------------------------------------------------------------------
		// alokuje miesto v pamati pre texturu, vracia true, ak sa operacia podari, false inac
		// parametre:	texture - ukazovatel na texturu, ktora sa ma ulozit do pamate
		//				Width - sirka textury
		//				Height - vyska textury
		//				BPP - farebna hlbka, v bitoch na pixel
		bool AllocateMemmory(Textura *texture,int Width,int Height,int BPP);
		//------------------------------------------------------------------------------------
		// nacita jeden obrazok typu TGA do struktury typu Textura
		// parametre:	tex - ukazovatel na texturu, ktoremu sa priradi novovytvorena textura
		//				filename - retazec, ktory obsahuje cestu k obrazku
		bool LoadTGA (Textura *tex, char *filename);
		//------------------------------------------------------------------------------------
		// vykresli obrazok/texturu na zadanu poziciu a v zadanych rozmeroch
		// parametre:	TextID - handle textury
		//				TLX - x-ova pozicia laveho horneho bodu obdlznika
		//				TLY - y-ova pozicia laveho horneho bodu obdlznika
		//				BRX - x-ova pozicia praveho dolneho bodu obdlznika
		//				BRY - y-ova pozicia praveho dolneho bodu obdlznika
		void DrawPicture(GLuint TextID,int TLX,int TLY,int BRX,int BRY);
		//------------------------------------------------------------------------------------
		void KillRAMImage();		// uvolni obrazok z pamate
		void BuildTextures();		// spravi z nacitanych obrazkov v poli ListTEX textury
		void KillGLTextures();		// odstrani textury z pamate
};
//===================================================================< SKINCLASS >=================
// Trieda pre tvorbu a uvolnovanie listov OpenGL
class TSkinClass							
{
	public:
		GLuint Base;						// zaklad pre glBuildList()
		GLuint ListGL[MGL_LIST_NUM];		// Listy OpenGL
		//------------------------------------------------------------------------------------
		bool CreateList();					// vytvori listy pre cele pole ListGL
		void DestroyList();					// uvolni vsetky listy
		//------------------------------------------------------------------------------------
		// vykresli obdlznik vobred na nastavenej farby na zadanu poziciu
		// parametre:	TLX - x-ova pozicia laveho horneho bodu obdlznika
		//				TLY - y-ova pozicia laveho horneho bodu obdlznika
		//				BRX - x-ova pozicia praveho dolneho bodu obdlznika
		//				BRY - y-ova pozicia praveho dolneho bodu obdlznika
		void DrawRect(int TLX,int TLY,int BRX,int BRY);
};
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/ TGUI \XXXXXXX
//===================================================================< FLATBUTTON >================
// Trieda tla��tka len s textom, bez okrajov
class TFlatButton							
{
	public:
		int		BX, BY, Width, Height, GoX;			// pozicia, sirka, vyska, rolovanie
		bool	MouseOver, IsVisible, IsActivated;	// myska nad tlacitkom, viditelnost
		char	Text[100];							// text tlacitka
		//------------------------------------------------------------------------------------
		// konstruktor, nastavi vysku a sirku, s parametrami:
		//		W - sirka
		//		H - vyska
		TFlatButton(int W,int H);
		TFlatButton() { TFlatButton(0,0); };		// standardny konstruktor
		//------------------------------------------------------------------------------------
		// nastavi poziciu a text tlacitka
		// parametre:	x - x-ova pozicia praveho horneho rohu
		//				y - y-ova pozicia praveho horneho rohu
		//				text - text tlacitka
		void SetMe(int x,int y,char text[]);
		//------------------------------------------------------------------------------------
		// nastavi velkost tlacitka, nastavy GoX na W
		// parametre:	W - sirka, H - vyska
		void SetMySize(int W,int H);
		//------------------------------------------------------------------------------------
		// nastavi viditelnost, funkcnost a nastavy roll na sirku tlacitka
		// parametre:	Visible - viditelnost tlacitka, pri false je neviditelne
		//				Active - funkcnost tlacitka, ak je false, tlacitko je sive
		//						 a neda sa stlacit				
		//				Roll - ak je true, nastavi sa GoX na sirku tlacitka
		void Reset(bool Visible,bool Active,bool Roll);
		//------------------------------------------------------------------------------------
		void Redraw();			// prekreslenie tlacitka
		//------------------------------------------------------------------------------------
		bool Update();			// update tlacitka, vracia true, ak bola myska nad 
								// tlacitkom a bolo stlacene lave tlacidlo na myske
		//------------------------------------------------------------------------------------
		bool IsMouseOver();		// vracia true, ak sa myska nachadza nad tlacitkom
								// inak vracia false
};
//===================================================================< INBOXCLASS >================
// Trieda InputBoxu - vkl�dacieho pol��ka
class TInboxClass : public TFlatButton		
{
	public:
		int		InputPos, Cas;			//pozicia vkladania textu, cas pre blikanie kurzora
		bool	InsertToMe, Finished, ZobrazKurzor; // vkladanie, dokoncenie vkladania,
													// zobrazenie blikajuceho kurzoru
		//------------------------------------------------------------------------------------
		TInboxClass(): TFlatButton(16,16),InputPos(0),InsertToMe(false),Finished(false),Cas(0),
			ZobrazKurzor(false) {};					// konstruktor
		//------------------------------------------------------------------------------------
		// nastavi viditelnost a funkcnost tlacitka
		// parametre:	Visible - viditelnost tlacitka, pri false je neviditelne
		//				Active - funkcnost tlacitka, ak je false, tlacitko je sive
		//						 a neda sa stlacit				
		void Reset(bool Visible,bool Active);
		//------------------------------------------------------------------------------------
		bool Update();			// update tlacitka, vracia true, ak bola myska nad 
								// tlacitkom a bolo stlacene lave tlacidlo na myske
};
//===================================================================< BUTTONCLASS >===============
// Trieda tla��tka roluj�ceho zprava
class TButtonClass : public TFlatButton		
{
	public:
		TButtonClass(): TFlatButton(200,40) {};		// konstruktor
		void Redraw();								// prekreslenie tlacitka
		//------------------------------------------------------------------------------------
		bool Update();			// update tlacitka, vracia true, ak bola myska nad 
								// tlacitkom a bolo stlacene lave tlacidlo na myske
};
//===================================================================< BUTTONDCLASS >==============
// Trieda tla��tka roluj�ceho zo spodu
class TButtonDClass : public TFlatButton	
{
	public:
		TButtonDClass(): TFlatButton(170,90) {};	// konstruktor
		//------------------------------------------------------------------------------------
		// nastavi viditelnost, funkcnost a nastavy roll na sirku tlacitka
		// parametre:	Visible - viditelnost tlacitka, pri false je neviditelne
		//				Active - funkcnost tlacitka, ak je false, tlacitko je sive
		//						 a neda sa stlacit				
		//				Roll - ak je true, nastavi sa GoX na sirku tlacitka
		void Reset(bool Visible,bool Active,bool Roll);
		//------------------------------------------------------------------------------------
		void Redraw();			// prekreslenie tlacitka
		//------------------------------------------------------------------------------------
		bool Update();			// update tlacitka, vracia true, ak bola myska nad 
								// tlacitkom a bolo stlacene lave tlacidlo na myske
};
//===================================================================< LISTACLASS >================
// Trieda "Li�ty" roluj�cej zlava
class TListaClass : public TFlatButton		
{
	public:
		TListaClass(): TFlatButton(364,322) {};		// konstruktor
		void Redraw();								// prekreslenie listy
		//------------------------------------------------------------------------------------
		bool Update();			// update listy, vracia true, ak bola myska nad 
								// listou a bolo stlacene lave tlacidlo na myske
};
//===================================================================< LISTAPROFCLASS >================
// Trieda zobrazuj�ca existuj�ce profily
class TZoznamPClass : public TFlatButton	
{
	public:
		TFlatButton	FBNew, FBDel;			// tlacitka na pridavanie a mazanie profilov
		int			VybratyProfil, Scroll;	// cislo vybrateho profilu a aktualny posun
		bool		New, Del;				// priznaky vytvarania noveho profilu a mazania
		//------------------------------------------------------------------------------------
		TZoznamPClass();					// konstruktor
		void Redraw();						// prekreslenie zoznamu
		//------------------------------------------------------------------------------------
		bool Update();			// update zoznamu, vracia true, ak bola myska nad 
								// zoznamom a bolo stlacene lave tlacidlo na myske
		//------------------------------------------------------------------------------------
		// nastavi viditelnost, funkcnost a nastavy roll na sirku zoznamu
		// parametre:	Visible - viditelnost zoznamu, pri false je neviditelny
		//				Active - funkcnost zoznamu, ak je false, zoznam je neaktivny				
		//				Roll - ak je true, nastavi sa GoX na sirku zoznamu
		void Reset(bool Visible,bool Active,bool Roll);
};
//===================================================================< PONUKACLASS >===============
// Trieda "Ponuky" roluj�cej zprava
class TPonukaClass : public TFlatButton		
{
	public:
		TPonukaClass(): TFlatButton(240,333) {};	// konstruktor
		void Redraw();								// prekreslenie ponuky
		//------------------------------------------------------------------------------------
		bool Update();			// update ponuky, vracia true, ak bola myska nad 
								// ponukou a bolo stlacene lave tlacidlo na myske
};
//===================================================================< CURSORCLASS >===============
// Trieda kurzora my�ky
class TCursorClass							
{
		char x[10], y[10];		// suradnice pri kurzore
	public:
		//------------------------------------------------------------------------------------
		TCursorClass() {};		// konstruktor
		void Redraw();			// prekreslovanie kurzora
		//void Update() {};		// update poziciu kurzora
        void Suradnice();		// vykresluje suradnice ku kurzoru
};
//===================================================================< INDEXSETCLASS >=============
// Trieda pre v�ber indexu - grafick� v�ber
class TIndexSetClass : public TFlatButton	
{
	public:
		int		Select, MinSelect, MaxSelect;	// ktory index je vybraty, minimalny a 
												// maximalny index
		bool	MouseOverLeft, MouseOverRight;	// ci je myska nad pravou alebo nad lavou 
												// sipkou		
		//------------------------------------------------------------------------------------
		// konstruktor s parametrami:
		//			W - sirka, H - vyska, Min - minimalny index, Max - maximalny index
		TIndexSetClass(int W,int H,int Min,int Max): TFlatButton(W,H),Select(Min),MinSelect(Min),
			MaxSelect(Max),MouseOverLeft(false),MouseOverRight(false) {};
		//------------------------------------------------------------------------------------
		TIndexSetClass() { TIndexSetClass(0,0,0,0); };	// default konstruktor
		//------------------------------------------------------------------------------------
		// nastavi poziciu, parametre:	x - x-ova pozicia laveho horneho bodu
		//								y - y-ova pozicia laveho horneho bodu		
		void SetMe(int x,int y);
		//------------------------------------------------------------------------------------
		// nastavi viditelnost a funkcnost vyberaca
		// parametre:	Visible - viditelnost vyberaca, pri false je neviditelny
		//				Active - funkcnost vyberaca, ak je false, je nefunkcny, 
		//						 ak je true je funkcny
		void Reset(bool Visible,bool Active);
		//------------------------------------------------------------------------------------
		void Redraw();		// prekreslenie vyberaca
		bool Update();		// update vyberaca, vzdy vracia false
};
//===================================================================< PROFILSETCLASS >============
// Trieda pre v�ber profilu - graficky
class TProfilSetClass : public TIndexSetClass		
{
	public:			
		TProfilSetClass(): TIndexSetClass(200,120,2,9) {};	//konstruktor
		void Redraw();			// prekreslenie vyberaca
		bool Update();			// update vyberaca, vzdy vracia false
};
//===================================================================< OBRSETCLASS >===============
// Trieda pre v�ber obr�zka profilu
class TObrSetClass : public TIndexSetClass	
{
	public:
		TObrSetClass(): TIndexSetClass(110,110,2,8) {};	// konstruktor
		void Redraw();			// prekreslenie vyberaca
		bool Update();			// update vyberaca, vzdy vracia false
};
//===================================================================< NOVYPCLASS >================
// Trieda pre zaevidovanie nov�ho profilu
class TNovyPClass : public TFlatButton		
{
	public:
		TInboxClass		IBName;		// policko pre zadavanie mena
		TObrSetClass	ObrSet;		// vyber obrazku
		TFlatButton		FBOvladanie[5]; // nastavenie ovladacich klaves hore, dole, dolava, 
										// doprava, strelba (v tomto poradi)
		int				KtoreTlacitko, Kody[5]; // ktore tlacitko sa prave nastavuje
												// virtualne kody jednotlivych tlacitok
		bool			VsetkoZadane;			// na zistovanie, ci sa uz moze novy profil
												// ulozit
		//------------------------------------------------------------------------------------
		TNovyPClass();							// konstruktor
		void Redraw();							// prekreslenie celeho panelu aj s tlacitkami
		bool Update();							// update panelu a vsetkych jeho tlacitok	
		//------------------------------------------------------------------------------------
		// nastavi viditelnost, funkcnost a nastavy roll na sirku panelu
		// parametre:	Visible - viditelnost panelu, pri false je neviditelny
		//				Active - funkcnost panelu, ak je false, panel je neaktivny				
		//				Roll - ak je true, nastavi sa GoX na sirku panelu
		void Reset(bool Visible,bool Active,bool Roll);
		//------------------------------------------------------------------------------------
	private:
		//------------------------------------------------------------------------------------
		// aktivuje vsetky tlacitka tejto triedy, pouziva sa pri 
		// zadavani ovladacich klaves a mena
        void ActivateAll();		
		//------------------------------------------------------------------------------------
		// deaktivuje vsetky tlacitka tejto triedy, okrem jedneho, pouziva sa pri zadavani 
		// ovladacich klaves a mena
		// parametre:	okrem - ktore tlacitko ma ostat aktivne, 0 - meno, 1 - 5 ovladacie kl.
		void DeactivateAll(int okrem);
};
//===================================================================< TEXTCLASS >=================
// Trieda pre pr�cu s textom
class TTextClass							
{
	public:
		GLuint	FontBase;		// zaklad listu pre text
		//------------------------------------------------------------------------------------
		void CreateFont();		// vytvori glListy pre kazde pismenko
		void KillFont();		// uvolni pamat zabratu fontom
		//------------------------------------------------------------------------------------
		// vypise text na zadanu poziciu, je mozne vybrat z dvoch pisiem
		// parametre:	x - x-ova pozicia laveho dolneho bodu, kde sa ma zacat pisat
		//				y - y-ova pozicia laveho dolneho bodu, kde sa ma zacat pisat
		//				string - retazec, ktory sa ma vypisat
		//				UpSet - true alebo false, urcuje typ pisma
		void DrawGLText(int x,int y,char string[],bool UpSet);
		//------------------------------------------------------------------------------------
		// vypise text do stredu zadaneho pasu, je mozne vybrat z dvoch pisiem
		// parametre:	x - x-ova pozicia laveho dolneho bodu pasu
		//				y - y-ova pozicia laveho dolneho bodu pasu
		//				width - sirka pasu
		//				string - retazec, ktory sa ma vypisat
		//				UpSet - true alebo false, urcuje typ pisma
		void DrawGLTextStred(int x,int y,int width,char string[],bool UpSet);
};
//===================================================================< FPSCLASS >==================
// Po��tadlo FPS - Frames Per Second
class TFPSClass								
{
	public:
		unsigned long	LastFrameTick;		// cas pred poslednym prekreslenim
		int				Frames;				// pocet frameov za sekundu
		char			text[10];			// na vypis textu na obrazovku
		//------------------------------------------------------------------------------------
		TFPSClass();						// kontruktor
		void DrawFPS();						// vypise da laveho horneho rohu FPS
};
//===================================================================< KRUZKY >====================
// Trieda na zobrazovanie modreho kruzku pri vyberani profilov
class TKruzokClass							
{
		int	cas, KtorySnimok, smer, x, y; // cas do dalsieho snimku, aktualny snimok,
										  // smer otacania a pozicia
	public:
		//------------------------------------------------------------------------------------
		// kontruktor, nastavi hodnoty x a y (pozicia, kde sa ma vykreslovat)
		// parametre:	x - x-ova suradnica laveho horneho bodu obdlznika
		//				y - y-ova suradnica laveho horneho bodu obdlznika
		TKruzokClass(int x,int y);
		//------------------------------------------------------------------------------------
		TKruzokClass() { TKruzokClass(0,0); };		// konstruktor
		void Redraw();								// prekreslovanie jednotlivych snimkov
		//------------------------------------------------------------------------------------
		void Update();								// pocita cas, kedy sa ma zacat 
													// prekreslovat dalsi snimok
		//------------------------------------------------------------------------------------
		void Reset();								// nastavi cas, snimok a smer na 0
		//------------------------------------------------------------------------------------
		// nastavi poziciu, kde budu vykreslovat jednotlive snimky animacie
		// parametre:	x - x-ova suradnica laveho horneho bodu obdlznika
		//				y - y-ova suradnica laveho horneho bodu obdlznika
		void SetPosition(int x,int y);
};
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/ TSUBCLASS \XXX
//===================================================================< DEKLARATIONS >==============
typedef unsigned char UCHAR;		// char bez znamienka = BYTE
typedef struct						// farba a typ pixelu
{
	unsigned char R,G,B,I;			// R,G,B - farebne zlozky, I - typ pixelu (zem, domcek...)
} Farba;
typedef Farba* FarbaPtr;			// ukazovatel na strukturu farba
typedef void*  voidPtr;				// prazdny ukazovatel
//===================================================================< UICLASS >===================
class TTankClass;							
// Trieda Umelej Inteligencie tanku
class TUIClass
{
	public:
		TTankClass	*MyTank;		// ukazovatel na vlastny tank
		bool	InHome, DamegeMe, MaloEnergy, IamPredator, FullEnergy, SomeShootMe, DamMyFort;
		bool	UIGoFire, DoBoduA, DoBoduB, BadDamage, GoodEnergy, SeeHunt, InTray, Obnovit;
		bool	INowWhere, DeadEnemy, Utekam;
		int		KratGo, SmerGo, UIMemo, UIGoHoriz, UIGoVerti, UtekStav, Rozdiel;
		int		Tx, LTx, Ty, LTy, Sx, Sy, THP, LTHP, MyFortHP, LMyFortHP;
		//------------------------------------------------------------------------------------
		TUIClass() { Reset(); IamPredator = INowWhere = false; Rozdiel = 0; }; // konstruktor
		//------------------------------------------------------------------------------------
		// inteligentne nastavi novy smer a to, ci sa ma strielat
		// parametre:	GoHoriz - adresa, kam sa ulozi horizontalny pohyb
		//				GoVerti - adresa, kam sa ulozi vertikalny pohyb
		//				GoFire - adresa, kam sa ulozi to, ci ma tank strielat
        void VratNovySmer(int *GoHoriz,int *GoVerti,bool *GoFire);
		//------------------------------------------------------------------------------------
		void Reset();	// nastavi vsetky premenne na pociatocne hodnoty
		bool CanFire();	// 
		//------------------------------------------------------------------------------------
		//
		// parametre:
		bool GoToPoint(int Px,int Py);
};
//===================================================================< TANKCLASS >=================
class TDomcekClass;							// Trieda reprezentuj�ca tank v hre
class TTankClass
{
	public:										// konstanty pre triedu
		static const int MaxTEnergy = 10000,	// maximalna energia
						 MaxTHP = 1000,			// maximalny zivot tanku
						 ShootLoss = 120,		// strata energie pri strielani
						 PauzaStriel = 150,		// pauza medzi vystrelenim dvoch striel
						 StrataEnergie = 1;		// strata energie pri pohybe v tunely
				
		TControlsClass	Control;	// ovladanie tanku
		TPlayerClass	*Owner;		// vlastnik tanku
		TDomcekClass	*MyFort;	// odkaz na domcek patriaci tomuto tanku
		TTankClass		*MyEnemy;	// ukazovatel na neprietelsky tank
		TUIClass		MyMind;		// ak sa jedna o umelu inteligenciu, spravanie
		GLUquadricObj	*quadratic;	// na vykreslovanie kruhu pri explozii
		int				HP, x, y,	// zdravie, pozicia tanku
						Energy, ID, GoHoriz,	// enegia, ID tanku, horizontalny smer pohybu
						GoVerti, Smer,			// vertikalny smer pohybu, celkovy smer
						PocetStriel;			// aktualny pocet striel patriaci tomuto tanku
		int				KratGo, LastSmerGo,		// 
						r, SnimkyVybuchu;		// polomer kruhu pri explozii, aktualny snimok
		bool			IAmUI,					// urcuje, ci sa jedna o UI
						GoFire, Vybuch;			// ci sa ma strielat a ci tank vybuchol
		float			PohybTime, VrtTime,		// cas od posledneho pohybu alebo vrtania
						DalsiaStrela;			// cas od vystrelenia poslednej strely
		//------------------------------------------------------------------------------------
		// kontruktor
		TTankClass(): x(0),y(0),ID(0),IAmUI(false),PocetStriel(0),DalsiaStrela((float)PauzaStriel),
			Vybuch(false)
			{
				Reset();
				quadratic = gluNewQuadric();
				MyMind.MyTank = this;
			};
		//------------------------------------------------------------------------------------
		// zistuje, ci sa nejaka strela trafila do tanku
		// parametre:	Sx, Sy - pozicia strely
		//				Dam - velkost poskodenia pri zasahu
		//				ID - ID vlastnika strely
		bool ShootMe(int Sx,int Sy,int Dam,int ID);
		//------------------------------------------------------------------------------------
		// nastavi vlastnika tanku
		// parametre:	Player - ukazovatel na vlastnika tanku
		void SetOwner(TPlayerClass *Player);
		//------------------------------------------------------------------------------------
		// nastavi nepriatela tanku
		// parametre:	Enemy - ukazovatel na nepriatela tanku
		void SetEnemy(TTankClass *Enemy);
		//------------------------------------------------------------------------------------
		void Redraw();	// prekresluje tank, pripadne jeho exploziu pri vybuchu
		//------------------------------------------------------------------------------------
		void Update();	// aktualizuje polohu a pohyb tanku, strielanie, pocita cas medzi
						// jednotlivymi snimkami vybuchu
		//------------------------------------------------------------------------------------
		void Reset();	// nastavi zivot a energiu naplno, nastavi vsetky casy na 0,
						// smer na 3 a zresetuje UI
		//------------------------------------------------------------------------------------
		// zabezpecuje dobijanie energie
		// parametre:	Pus - hodnota o kolko sa ma zvysit energia tanku
		void ReCharge(int Pus);
		//------------------------------------------------------------------------------------
		// zabezpecuje opravovanie tanku
		// parametre:	Plus - hodnota o kolko sa ma zvysit zdravie tanku
		void ReHealt(int Plus);
		//------------------------------------------------------------------------------------
		// zistuje, ci sa tank moze pohnut na zadanu poziciu
		// parametre:	xx,yy - pozicia, kam sa ma tank pohnut
		bool CanMove(int xx,int yy);
};
//===================================================================< STRELACLASS >===============
// Trieda reprezentuj�ca jednu strelu v hre
class TStrelaClass							
{
	public:
		int x, y, Dam, Smer, ID; // pozicia, znicujuci ucinok, smer a vlastnik strely
		//------------------------------------------------------------------------------------
		TStrelaClass(): x(0),y(0),Dam(50),Smer(0),ID(0) {};	// konstruktor
		//------------------------------------------------------------------------------------
		// aktualizuje polohu strely a zistuje, ci do nicoho nenarazila
		// vracia true ak strela este existuje, false pri naraze
		bool Update();			
		//------------------------------------------------------------------------------------
		void Redraw();	// prekresluje strelu pri jej pohybe, pokial do niecoho nenarazi
};
//===================================================================< STRELYCLASS >===============
// Trieda spracov�vaj�ca v�etky strely v hre
class TStrelyClass							
{
	public:				// kosntanty pre triedu:
		static const int StrelaTimC = 10,	// regulacia rychlosti striel
						 MaxStriel = 40;	// maximalny pocet sucasne existujucich striel

		std::queue<TStrelaClass> FrontS;	// fronta so vsetkymi strelami
		std::queue<TStrelaClass> RedSee;	// fronta so strelami, ktore vidi lavy hrac
		std::queue<TStrelaClass> BluSee;	// fronta so strelami, ktore vidi lavy hrac
		int	StrelaTime;						// cas medzi dvoma updatami striel
		//------------------------------------------------------------------------------------
		TStrelyClass(): StrelaTime(StrelaTimC) {};	// konstruktor
		//------------------------------------------------------------------------------------
		void Update();		// vola update vsetkych striel vo FrontS a zaraduje ich 
							// do prislusnej fronty
		//------------------------------------------------------------------------------------
		// prida do fronty novu strelu, ak je vsetkych striel je menej ako MaxStriel
		// parametre:	x,y - pociatocna pozicia strely
		//				Smer - smer strely
		//				ID - ID vlastnika strely
		void AddShoot(int x,int y,int Smer,int ID);
};
//===================================================================< DOMCEKCLASS >===============
// Trieda reprezentuj�ca dom�ek v hre
class TDomcekClass							
{
	public:			// konstanty tejto triedy:
		static const int MaxDHP = 10000,	// maximalne zdravie domceka
						 FreshC = 50;		// cas za ktory sa tanku v domceku raz prida 
											// zdravie a energia
		
		TTankClass	*MyTank;	// ukazovatel na tank, ktory patri k domceku
		int			x, y,		// pozicia domceka
					DomS, MurS, Stena, // sirka domceka, muru a steny
					ID, HP,		// ID a zdravie domceka
					FreshTime,	// odpocitavanie casu do dalsie obnovenia zdravia a energie t.
					BodAX, BodAY, BodBX, BodBY;
		//------------------------------------------------------------------------------------
		// konstruktor
		TDomcekClass(): x(0),y(0),DomS(0),MurS(0),Stena(0),ID(0),HP(MaxDHP),FreshTime(FreshC) {};
		//------------------------------------------------------------------------------------
		// "vyvrta" zadany domcek pre zadany tank do mapy
		// parametre:	Tank - ukazovatel na tank, ktory sa nastavi ako vlastnik domceka
		//				Domcek - ukazovatel na domcek, ktory sa ma vyvrtat
		void VrtajDomcek(TTankClass *Tank,TDomcekClass *Domcek);
		//------------------------------------------------------------------------------------
		// zistuje ci sa v domceku nachadza niektory z tankov a ak ano, tak ak sa jedna 
		// o vlastny tank, doplna mu rychlo energiu a zdravie, ak o nepriatelsky, doplna mu 
		// pomaly energiu
		// parametre:	OtherTank - smernik na nepriatelsky tank
		void AtFortres(TTankClass *OtherTank);
		//------------------------------------------------------------------------------------
		// obnovi zdravie domceka a nastavi pociatocnu polohu vlastneho tanku
		// na stred domceka a zavola reset tanku
		void Reset();	
		//------------------------------------------------------------------------------------
		// zavola sa, ak je tank zasiahnuty nejako strelou, uberie mu zadanu cast zdravia
		// parametre:	Dam - mnozstvo zdravia, ktore sa ma ubrat
		void ShootMe(int Dam);
		//------------------------------------------------------------------------------------
		// zistuje ci sa tank nachadza vo svojom domceku, vyuziva sa pre UI
		// vrati true, ak je v domceku, inak false
		bool AtHome(); 
		//------------------------------------------------------------------------------------
		// zistuje, ci sa zadana pozicia nachadza v domceku
		// vrati true, ak ano, inak false
		// parametre:	xx,yy - vysetrovana pozicia
		bool InFort(int xx,int yy);
};
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/ TSCREEN \XXXX
//===================================================================< MENUCLASS >=================
// Trieda sc�ny 1 - Hlavne menu hry
class TMenuClass								
{
	public:
		TButtonClass	BNew, BSet, BAut, BExt;// tlacitka Nova hra,Nastavenie,Autori a Koniec
		TListaClass		Lista;					// panel s autormi
		//------------------------------------------------------------------------------------
		TMenuClass();							// konstruktor
		//------------------------------------------------------------------------------------
		// inicializacia triedy, vola sa zakazdym, ked sa meni stav na InMENU, 
		// zavola reset vsetkych grafickych prvkov, vzdy vrati true
		bool	Init();
		//------------------------------------------------------------------------------------
		// zavola sa zakazdym pri prechode na inu obrazovku, vzdy vrati true (nerobi nic)
		bool	DeInit();
		//------------------------------------------------------------------------------------		
		void	Redraw();	// vykresluje menu, vola prekreslovanie vsetkych grafickych prvkov
		void	Update();	// aktualizuje graficke prvky a pusta hudbu
};
//===================================================================< SETCLASS >==================
// Trieda sc�ny 2 - Nastavenia
class TSetClass									
{
	public:
		TButtonClass	BOK, BSav, BZrusit, BZmenit;	// tlacitka OK, Ulozit, Zrusit, Zmenit
		TListaClass		NastavenieZvuku,		// ponuka s nastavenim zvuku a hudby
						NastavenieGrafiky;	// ponuka s nastavenim grafiky a moznostami hry
		TNovyPClass		NovyProfil;			// panel so zadavanim noveho profilu
		TZoznamPClass	ZoznamProfilov;		// panel so zoznamom vsetkych profilov
		TPonukaClass	Ponuka;				// panel s nazvami jednotlivych ponuk
		TFlatButton		FBProf, FBZvuk, FBGrafika,	// tlacitka pre jednotlive ponuky
						FBZvuky, FBHudba,			// nastavenie zvukov a hudby - zap./vyp.
						FBDetaily, FBHra,			// detaily mapy, pocet kol
						FBDomcek;					// znicitelnost domceka
		TButtonDClass	BDAno, BDNie;			// tlacitka na potvrdzovanie mazania
		bool			Menenie;			// true, ak sa meni niektore nastavenie profilu
		//------------------------------------------------------------------------------------
		TSetClass();						// konstruktor
		//------------------------------------------------------------------------------------
		// inicializacia triedy, vola sa zakazdym, ked sa meni stav na InSETTING;
		// zavola reset vsetkych grafickych prvkov, vzdy vrati true	
		bool	Init();
		//------------------------------------------------------------------------------------
		// zavola sa zakazdym pri prechode na inu obrazovku, vzdy vrati true (nerobi nic)
		bool	DeInit();
		//------------------------------------------------------------------------------------
		void	Redraw();	// vykresluje menu, vola prekreslovanie vsetkych grafickych prvkov
		void	Update();	// aktualizuje graficke prvky a pusta hudbu
};
//===================================================================< CHOOSECLASS >===============
// Trieda sc�ny 3 - V�ber s�pera
class TChooseClass								
{
	public:					
		TProfilSetClass	VyberL, VyberP; // graficke prvky na vyber profilu
		TButtonClass	BPlay, BCan;	// tlacidla Play!! a Cancel
		TButtonDClass	BDSet;			// dolne tlacitko Profily
		TKruzokClass	KruzokL, KruzokP;	// animacia pod vyberanim profilov
		//------------------------------------------------------------------------------------
		TChooseClass();						// konstruktor
		//------------------------------------------------------------------------------------
		// zavola reset vsetkych grafickych prvkov, vzdy vrati true		
		bool	Init();
		//------------------------------------------------------------------------------------
		// zavola sa zakazdym pri prechode na inu obrazovku, vzdy vrati true (nerobi nic)
		bool	DeInit();
		//------------------------------------------------------------------------------------
		void	Redraw();	// vykresluje menu, vola prekreslovanie vsetkych grafickych prvkov
		void	Update();	// aktualizuje graficke prvky a pusta hudbu			
};
//===================================================================< GAME2CLASS >================
// Trieda sc�ny 4 - Boj
class TGame2Class								
{
	public:				// konstanty tejto triedy:
		static const int PohybDelayC = 40,	// spomalenie normalneho pohybu v tuneloch
						 VrtDelayC = 200,	// spomalenie pohybu pri vrtani
						 SmuhyC = 60,		// pauza medzi zobrazovanim zrnenia
						 VybuchDelay = 2500;	// oneskorenie ukoncenia kola po vybuchu
		
		TTankClass		RedLTank, BluePTank;	// lavy a pravy tank
		TDomcekClass	RedLDom, BluePDom;		// domceky laveho a praveho hraca
		TStrelyClass	Strely;					// vsetky strely
		Farba			*SubMap, **Mapa;		// cast mapy a cela mapa
		int				i, j, Tx, Ty,
						PocWinL, PocWinP,		// pocet vyhier laveho a praveho hraca
						LoopC,					// 1/mapzoom
						SmuhyTimR, SmuhyTimB;	// odpocitavanie casu medzi zobrazovanim smuh
		int				MapZoom,				// velkost jednej kocky
						MapNumW, MapNumH, MapW, MapH; // sirka a vyska mapy
		int				TankSize,				// velkost tanku
						SubMapW, SubMapH,		// sirka a vyska casti mapy
						PocetVyhier,			// pocet vyhier, na kolko sa hra
						Koniec;					// cas do ukoncenia kola po zniceni tanku
		bool			ZnicitelnyDomcek;		// urcuje, ci je domcek mozne znicit
		float			PohybTimC, VrtTimC,		// spomalenie tankov pri vrtani a pri pohybe
						LossEnergyC, Percent;	// strata energie pri pohybe a pocet percet
												// na vykreslenie
		//------------------------------------------------------------------------------------
		TGame2Class();							// konstruktor
		//------------------------------------------------------------------------------------
		// vypocita vsetky konstanty spojene s roznymi detailami mapy a vytvori mapu podla
		// zvolenej urovne detailov, umiestni nahodne domceky s tankami, zastavi hudbu z menu,
		// nastavi pocty vyhier na 0, vzdy vrati true
		bool	Init();	
		//------------------------------------------------------------------------------------
		bool	DeInit();		// zastavi hudbu z hry, vzdy vrati true
		void	Redraw();		// prekresluje celu scenu a vola redraw funkcie objektov sceny
		void	Update();		// aktualizuje vsetky objekty na scene a pocitadla
};
//===================================================================< ResultsCLASS >================
// Trieda sc�ny 5 - V�sledok boja
class TResultsClass								
{
	public:
		TButtonClass	BOK;				// tlacitko OK
		TPlayerClass	Vitaz,				// kto je vitaz
						Vsetci[100];		// vsetky profily zoradene podla poctu vyhier
		int				Scroll;				// potrebne na scrollovanie zoznamu
		bool			MapaVisible;		// ci sa ma zobrazit zmensenina celej mapy
		//------------------------------------------------------------------------------------
		TResultsClass();					// konstruktor
		//------------------------------------------------------------------------------------
		// zobrazi zmensenu mapu bojiska a zotriedi profily podla poctu vyhier,
		// vzdy vracia true
		bool	Init();
		//------------------------------------------------------------------------------------
		// zavola sa zakazdym pri prechode na inu obrazovku, vzdy vrati true (nerobi nic)
		bool	DeInit();
		//------------------------------------------------------------------------------------
		void	Redraw();	// prekresluje celu scenu, vypisuje zoznam profilov
		void	Update();	// aktualizuje zoznam, tlacitko OK a zmensenu mapu
};
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/ OTHER \XXXXXX
//===================================================================< FUNCTIONS DECLARATIONS >====
void TerminateApp();						// Ukon�� program
void ToggleFullscreen();					// On/Off fullscreen m�d
void ReSwapBuffers();						// Re - swapne buffre
bool LoadTuneller();						// Loadne hru, nastav� parametre
bool ExitTuneller();						// Ukonci hru
//===================================================================< OBJECTS DECLARATIONS >======
extern TGameClass		Game;				// Trieda riadiaca hru
extern TInputClass		Input;				// Trieda pre pr�cu zo vstupom
extern TTimeClass		Time;				// Trieda pre pr�cu s �asom
extern TZvukyClass		Zvuky;				// Trieda pre pr�cu zo zvukom
extern TProfilClass		Profils;			// Trieda pre hr��ske profily
extern TImageClass		Image;				// Trieda pre pr�cu z obr�zkami
extern TSkinClass		Skin;				// Trieda pre vzh�ad
extern TCursorClass		Cursor;				// Trieda kurzora my�ky
extern TTextClass		CText;				// Trieda pre pr�cu s textom
extern TFPSClass		FPSC;				// Po��tadlo Frames Per Second - FPS
extern TMenuClass		Menu;				// Sc�na �.1 - Menu hry
extern TSetClass		Setting;			// Sc�na �.2 - Nastavenia
extern TChooseClass		Choose;				// Sc�na �.3 - V�ber s�pera
extern TGame2Class		Game2;				// Sc�na �.4 - Boj
extern TResultsClass	Results;			// Sc�na �.5 - V�sledok boja
extern int				GraphMode[4];		// Prvotn� nastavenie rozl�enia (po�adovan�)
//=================================================================================================
#endif //TUNELLER_GAME_H