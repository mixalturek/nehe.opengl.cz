/*
 *	c2html (K�dov� jm�no: fwc2hcfl - Free Woq's C To HTML Convertor For Linux)
 *	Ozna�kuje zdrojov� k�dy jazyka C/C++ pomoc� tag� HTML. Vhodn� pro v�pisy zdrojov�ch k�d� ve �l�nc�ch na webov�ch str�nk�ch.
 *
 *	Michal Turek - Woq, 30.1.2004
 *
 *	woq@email.cz
 *	http://woq.nipax.cz/
 *	http://nehe.opengl.cz/
 *
 *	Program i k�d je voln� �i�iteln� podle licence GNU GPL (http://www.gnu.cz/), pou�it� absolutn� bez z�ruky.
 *
 */

#include <stdio.h>
#include <string.h>

// "Oby�ejn�" C��ko nezn� datov� typ bool
#define bool int
#define false 0
#define true 1

// Po�et znak� nov�ho ��dku (Linux - 1, Windows - 2)
#define NL 1

// #define DEBUG_VYPISY

void Konverze(char* pData, long velikost_souboru, FILE* fw)// Funkce pro konverzi (jednodu��� je napsat ji znovu ne� se sna�it pochopit a upravit)
{
	unsigned long i;// Pro hlavn� cyklus

	bool komentar = false;// Flag koment��e (//)
	bool viceradkovy_komentar = false;// Flag v�ce��dkov�ho koment��e (/* */)
	unsigned int zanoreni = 0;// Berou se v �vahu pouze { a }
	int pom = 0;// Pomocn�

	fprintf(fw, "<p class=\"src0\">");// �vodn� tag

	for(i = 0; i < velikost_souboru; i++)// V�echny znaky v bufferu
	{
		if(pData[i] == '\t')// Tabul�tor
		{
			continue;// P�esko�it (Warning: spojuje slova, kdy� jsou kv�li zarovn�n� odd�len� tabul�torem m�sto mezerou)
		}

		if(pData[i] == 13)// '\n' jsou v MS(R) Windows(R)TM dva znaky 13 a 10 ('\r' a '\n') - h�zelo to zmaty
		{
			continue;// P�esko�it
		}

		if(pData[i] == '\n')// Nov� ��dek
		{
			if(zanoreni > 0)
			{
				pom = 0;

				while(++pom != 10)// Hled� uzav�rac� z�vorku (p�eskakuje taby na za�. ��dku). Po p�l roce: "To funguje?!"
				{
					if(pData[i + pom] == '}')
					{
						zanoreni--;
						break;
					}
				}
			}

			if(komentar)
			{
				if(pData[i + NL] == '\n')// Dva entry za sebou
				{
					fprintf(fw, "</span></p>\n<p>");
				}
				else
				{
					fprintf(fw, "</span></p>\n<p class=\"src%d\">", zanoreni);// \n
				}

				komentar = false;
			}
			else if(viceradkovy_komentar)
			{
				if(pData[i + NL] == '\n')// Dva entry za sebou
				{
					fprintf(fw, "</span></p>\n<p>");
				}
				else
				{
					fprintf(fw, "</span></p>\n<p class=\"src%d\"><span class=\"kom\">", zanoreni);// \n
				}
			}
			else if(pData[i + NL] == '\n')// Dva entry za sebou
			{
				fprintf(fw, "</p>\n<p>");// \n
			}
			else
			{
				fprintf(fw, "</p>\n<p class=\"src%d\">", zanoreni);// \n
			}
		}
		else if(pData[i] == '<')
		{
			fprintf(fw, "&lt;");// <
		}
		else if(pData[i] == '>')
		{
			fprintf(fw, "&gt;");// >
		}
		else if(pData[i] == '&')
		{
			fprintf(fw, "&amp;");// &
		}
		else if(pData[i] == '\"')
		{
			fprintf(fw, "&quot;");// "
		}
		else if(pData[i] == '{')
		{
			zanoreni++;//Zv�t�� zano�en�
			pom = 0;

			while(pData[i + pom] != '\n')
			{
				pom++;

				if(pData[i + pom] == '}')
				{
					zanoreni--;// Zmen�� zano�en�
					break;
				}
			}

			fprintf(fw, "{");// {
		}
		else if(pData[i] == '}')
		{
			// zanoreni -= 30;

			fprintf(fw, "}");// }
		}
		else if(pData[i] == '/')// Koment��e
		{
			if(pData[i + 1] == '/')// jedno��dkov� koment��
			{
				if(!komentar && !viceradkovy_komentar)
				{
					fprintf(fw, "<span class=\"kom\">");
				}

				komentar = true;
			}
			else if(pData[i + 1] == '*')// Za��tek v�ce��dkov�ho koment��e
			{
				if(!viceradkovy_komentar)
				{
					viceradkovy_komentar = true;

					if(!komentar)
					{
						fprintf(fw, "<span class=\"kom\">");
					}

					komentar = false;
				}
			}

			fprintf(fw, "/");// /

			if(i > 0)// Kv�li [i - 1] na n�sleduj�c�m ��dku (h�zelo to errory)
			{
				if(pData[i - 1] == '*')// Konec v�ce��dkov�ho koment��e
				{
					if(viceradkovy_komentar)
					{
						viceradkovy_komentar = false;
						komentar = false;

						fprintf(fw, "</span>");
					}
				}
			}
		}
		else// ��dn� speci�ln� znak
		{
			fputc(pData[i], fw);// Oby�ejn� vlo�en� do souboru
		}
	}

	fprintf(fw, "</p>");// Koncov� tag
}

int main(int argc, char** argv)
{
#ifdef DEBUG_VYPISY
	printf("DEBUG: Po�et parametr� p��kazov�ho ��dku: %d\n", argc);
#endif

	if(argc < 2)
	{
		fprintf(stderr, "ERROR: Program se mus� volat s parametrem, kter� ozna�uje cestu ke vstupn�mu (.c) souboru.\n");
		fprintf(stderr, "       Jm�no v�stupn�ho (.html) souboru se vygeneruje automaticky p�id�n�m p��pony .html k n�zvu.\n");
		return 1;
	}

	int i;

	for(i = 1; i < argc; i++)// V�echny parametry p��kazov�ho ��dku; aby se program mohl volat s v�ce parametry nebo "c2html *.c"
	{
		///// Generov�n� jm�na v�stupn�ho souboru /////

#ifdef DEBUG_VYPISY
		printf("DEBUG: D�lka �et�zce se jm�nem vstupn�ho souboru: %d znak�\n", strlen(argv[i]));
		printf("DEBUG: Jm�no vstupn�ho souboru: '%s'\n", argv[i]);
#endif

		char filename_out[strlen(argv[i]) + 6];// Alokace pam�ti pro �et�zec (jm�no + '.html' + '\0')

		strcpy(filename_out, argv[i]);// Kop�rov�n�
		strcat(filename_out, ".html");// Spojen�

#ifdef DEBUG_VYPISY
		printf("DEBUG: Jm�no v�stupn�ho souboru: '%s'\n", filename_out);
#endif

		///// Zji�t�n� velikosti vstupn�ho souboru /////

		FILE *fr = NULL;// Handle

		if((fr = fopen(argv[i], "rb")) == NULL)// Pro �ten� v BIN m�du
		{
			fprintf(stderr, "ERROR: Vstupn� soubor '%s' nelze otev��t, bu� neexituje, nebo nem�te dostate�n� pr�va.\n", argv[i]);
			return 3;
		}

		fseek(fr, 0L, SEEK_END);// P�esun na konec souboru (respektive o nula byt� od konce)
		long velikost_souboru = ftell(fr);// Pozice v souboru

		fclose(fr);
		fr = NULL;

#ifdef DEBUG_VYPISY
		printf("DEBUG: Velikost vstupn�ho souboru: %ld B\n", velikost_souboru);
#endif

		///// Na�ten� vstupn�ho souboru do pam�ti /////

		if((fr = fopen(argv[i], "r")) == NULL)// Otev�en� pro �ten�
		{
			fprintf(stderr, "ERROR: Vstupn� soubor '%s' nelze otev��t, bu� neexituje, nebo nem�te dostate�n� pr�va.\n", argv[i]);
			return 4;
		}

		char obsah_souboru[velikost_souboru + 1];// Alokace pam�ti pro data ze souboru
		int j;// Pro cyklus

		for(j = 0; j < velikost_souboru; j++)// Na�ten� do pam�ti
		{
			obsah_souboru[j] = getc(fr);
		}

		obsah_souboru[i] = '\0';// Ukon�ovac� znak

		fclose(fr);
		fr = NULL;

		///// "Konverze" C na HTML /////

		FILE *fw = NULL;

		if((fw = fopen(filename_out, "w")) == NULL)
		{
			fprintf(stderr, "ERROR: V�stupn� soubor '%s' nelze otev��t.\n", filename_out);
			return 5;
		}

		Konverze(obsah_souboru, velikost_souboru, fw);

		fclose(fw);
		fw = NULL;
	}

	return 0;// OK
}
