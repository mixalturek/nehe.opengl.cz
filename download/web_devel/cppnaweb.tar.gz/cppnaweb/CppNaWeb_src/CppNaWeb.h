// CppNaWeb.h : main header file for the CPPNAWEB application
//

#if !defined(AFX_CPPNAWEB_H__B5AFB925_18F7_11D7_A1EF_89AA008AD36A__INCLUDED_)
#define AFX_CPPNAWEB_H__B5AFB925_18F7_11D7_A1EF_89AA008AD36A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCppNaWebApp:
// See CppNaWeb.cpp for the implementation of this class
//

class CCppNaWebApp : public CWinApp
{
public:
	CCppNaWebApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCppNaWebApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCppNaWebApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CPPNAWEB_H__B5AFB925_18F7_11D7_A1EF_89AA008AD36A__INCLUDED_)
