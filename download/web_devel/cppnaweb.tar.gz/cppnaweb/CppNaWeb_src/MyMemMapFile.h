
class AFX_EXT_CLASS MyMemMapFile
{
public:
	MyMemMapFile();
	~MyMemMapFile();
	BOOL Open(DWORD size,LPCTSTR file = NULL);
	Close();
	Resize(DWORD newsize);
	void* GetDataPtr();
	DWORD GetSize();
protected:
	HANDLE hFile,hFileMapping;
	void* data,*data_ret;
	CString filename;
	DWORD velikost;
};