// CppNaWebDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CppNaWeb.h"
#include "CppNaWebDlg.h"

#include "MyMemMapFile.h"
#pragma comment(lib,"MyMemMapFile.lib")

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	afx_msg void OnNetWoq();
	afx_msg void OnNetNehe();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_BN_CLICKED(IDC_NET_WOQ, OnNetWoq)
	ON_BN_CLICKED(IDC_NET_NEHE, OnNetNehe)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCppNaWebDlg dialog

CCppNaWebDlg::CCppNaWebDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCppNaWebDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCppNaWebDlg)
	m_file_in = _T("");
	m_file_out = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCppNaWebDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCppNaWebDlg)
	DDX_Text(pDX, IDC_FILE_IN, m_file_in);
	DDX_Text(pDX, IDC_FILE_OUT, m_file_out);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCppNaWebDlg, CDialog)
	//{{AFX_MSG_MAP(CCppNaWebDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_KONVERT, OnKonvert)
	ON_BN_CLICKED(IDC_FILE_IN_BROWSE, OnFileInBrowse)
	ON_BN_CLICKED(IDC_FILE_OUT_BROWSE, OnFileOutBrowse)
	ON_BN_CLICKED(IDC_ZOBRAZIT_VYSLEDEK, OnZobrazitVysledek)
	ON_BN_CLICKED(IDC_ABOUT_L, OnAboutL)
	ON_BN_CLICKED(IDC_ABOUT_R, OnAboutR)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCppNaWebDlg message handlers

BOOL CCppNaWebDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_file_in="C:\\soubor.cpp";
	m_file_out="C:\\soubor.htm";
	GetDlgItem(IDC_ZOBRAZIT_VYSLEDEK)->EnableWindow(false);

	UpdateData(false);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCppNaWebDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCppNaWebDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCppNaWebDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCppNaWebDlg::OnKonvert() 
{
	// TODO: Add your control notification handler code here

	UpdateData();

	MyMemMapFile f_in;

	CFileStatus fs;
	
	if(!CFile::GetStatus(m_file_in,fs))
	{
		MessageBox("Vstupn� soubor neexistuje!","ERROR",MB_ICONERROR);
		return;
	}

	f_in.Open(fs.m_size,m_file_in);//otev�e vstupn� soubor

	char* pData = (char*)f_in.GetDataPtr();

	FILE* fw;
	fw=fopen(m_file_out,"w");

	DWORD i;//pro cyklus

	bool komentar=false;
	bool viceradkovy_komentar=false;
	UINT zanoreni=0;// po��taj� se { a }
	int pom=0;

	fprintf(fw,"<p class=\"src0\">");

	for(i = 0; i < f_in.GetSize(); i++)
	{
		if(pData[i]=='\t')// tabul�tor
			continue;

		if(pData[i]==13)// \n jsou dva znaky 13 a 10 (h�zelo to errory)
			continue;

		if(pData[i] == '\n')// nov� ��dek
		{
			if(zanoreni > 0)
			{
				pom = 0;

				while(++pom != 10)// Hled� uzav�rac� z�vorku (p�eskakuje tabul�tory; funguje - nev�m pro� :)
				{
					if(pData[i+pom]=='}')
					{
						zanoreni--;
						break;
					}
				}

			}

			if(komentar)
			{
				if(pData[i+2]=='\n')// Dva entry za sebou
				{
					fprintf(fw,"</span></p>\n<p>");
				}
				else
				{
					fprintf(fw,"</span></p>\n<p class=\"src%d\">", zanoreni);// \n
				}

				komentar=false;
			}

			else if(viceradkovy_komentar)
			{
				if(pData[i+2]=='\n')// Dva entry za sebou
				{
					fprintf(fw,"</span></p>\n<p>");
				}
				else
				{
					fprintf(fw,"</span></p>\n<p class=\"src%d\"><span class=\"kom\">", zanoreni);// \n
				}
			}

			else if(pData[i+2]=='\n')
				fprintf(fw,"</p>\n<p>");// \n

			else
				fprintf(fw,"</p>\n<p class=\"src%d\">", zanoreni);// \n
		}

		else if(pData[i]=='<')
			fprintf(fw,"&lt;");// <

		else if(pData[i]=='>')
			fprintf(fw,"&gt;");// >

		else if(pData[i]=='&')
			fprintf(fw,"&amp;");// &

		else if(pData[i]=='\"')
			fprintf(fw,"&quot;");// "

		else if(pData[i]=='{')
		{
			zanoreni++;//Zv�t�� zano�en�

			pom = 0;
			while(pData[i+pom] != '\n')
			{
				pom++;

				if(pData[i+pom] == '}')
				{
					zanoreni--;// Zmen�� zano�en�
					break;
				}
			}

			fprintf(fw,"{");// {
		}

		else if(pData[i]=='}')
		{
			//zanoreni-=30;
			fprintf(fw,"}");// }
		}

		else if(pData[i]=='/')//koment��e
		{
			if(pData[i+1]=='/')// jedno��dkov� koment��
			{
				if(!komentar && !viceradkovy_komentar)
					fprintf(fw,"<span class=\"kom\">");
				komentar=true;
			}

			else if(pData[i+1]=='*')//za��tek v�ce��dkov�ho koment��e
				if(!viceradkovy_komentar)
				{
					viceradkovy_komentar=true;
					if(!komentar)
						fprintf(fw,"<span class=\"kom\">");
					komentar=false;
				}

			fprintf(fw,"/");// /

			if(i>0)//kv�li [i-1] na n�sleduj�c�m ��dku
				if(pData[i-1]=='*')//konece v�ce��dkov�ho koment��e
					if(viceradkovy_komentar)
					{
						viceradkovy_komentar=false;
						komentar=false;
						fprintf(fw,"</span>");
					}			
		}
		
		else
			fputc(pData[i],fw);// p�vodn� znak
	}

	f_in.Close();
	fclose(fw);

	MessageBox("Hotovo","Hotovo",MB_ICONINFORMATION);
	GetDlgItem(IDC_ZOBRAZIT_VYSLEDEK)->EnableWindow(true);
}

void CCppNaWebDlg::OnFileInBrowse() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(true);
	if(dlg.DoModal()==IDOK)
		m_file_in=dlg.GetPathName();
	UpdateData(false);	
}

void CCppNaWebDlg::OnFileOutBrowse() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(false);
	if(dlg.DoModal()==IDOK)
		m_file_out=dlg.GetPathName();
	UpdateData(false);
}

void CCppNaWebDlg::OnZobrazitVysledek() 
{
	// TODO: Add your control notification handler code here
	::ShellExecute(GetSafeHwnd(),"open",m_file_out,NULL,NULL,SW_SHOWNORMAL);	
}

void CAboutDlg::OnNetWoq() 
{
	// TODO: Add your control notification handler code here
	::ShellExecute(GetSafeHwnd(),"open","http://woq.nipax.cz/",NULL,NULL,SW_SHOWNORMAL);
	
}

void CAboutDlg::OnNetNehe() 
{
	// TODO: Add your control notification handler code here
	::ShellExecute(GetSafeHwnd(),"open","http://nehe.opengl.cz/",NULL,NULL,SW_SHOWNORMAL);
}

void CCppNaWebDlg::OnAboutL() 
{
	// TODO: Add your control notification handler code here
	CAboutDlg dlg;
	dlg.DoModal();
}

void CCppNaWebDlg::OnAboutR() 
{
	// TODO: Add your control notification handler code here
	CAboutDlg dlg;
	dlg.DoModal();
}
