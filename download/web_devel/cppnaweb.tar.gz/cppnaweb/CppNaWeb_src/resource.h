//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CppNaWeb.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CPPNAWEB_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDB_WOQ                         129
#define IDC_KONVERT                     1000
#define IDC_FILE_IN                     1001
#define IDC_FILE_IN_BROWSE              1002
#define IDC_FILE_OUT                    1003
#define IDC_FILE_OUT_BROWSE             1004
#define IDC_ZOBRAZIT_VYSLEDEK           1007
#define IDC_NET_WOQ                     1008
#define IDC_INTRO                       1009
#define IDC_NET_NEHE                    1009
#define IDC_ABOUT_L                     1010
#define IDC_ABOUT_R                     1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
