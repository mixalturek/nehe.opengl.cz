/*
 * Timer
 * Create by Marek Ol��k - Eosie
 * pro http://nehe.opengl.cz/
 * 15.10.2003
 *
 */

#include <sdl.h>// Vlozi SDL
#include <sdl_opengl.h>// Vlozi za nas OpenGL

#pragma comment (lib, "opengl32.lib")
#pragma comment (lib, "glu32.lib")
#pragma comment (lib, "sdl.lib")
#pragma comment (lib, "sdlmain.lib")

// Interval timeru v ms, odpovida 50 FPS
#define TIMER_INTERVAL 20

// Promenne
float rotx, roty;// Rotace na osach x a y
unsigned int last_time = 0;// Cas minule aktualizace sceny


void OnTimer()// Aktualizace sceny
{
	rotx += 2.0f;// Zvysi uhly rotace
	roty += 2.0f;
}

bool DrawGLScene()// Vykreslovani
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	glTranslatef(0.0f, 0.0f, -4.0f);

	glRotatef(rotx, 1.0f, 0.0f, 0.0f);
	glRotatef(roty, 0.0f, 1.0f, 0.0f);

	glBegin(GL_QUADS);
		// Predni stena
		glColor3f(1.0f, 1.0f, 0.0f);
		glVertex3f(-0.5f, -0.5f,  0.5f);
		glVertex3f( 0.5f, -0.5f,  0.5f);
		glVertex3f( 0.5f,  0.5f,  0.5f);
		glVertex3f(-0.5f,  0.5f,  0.5f);

		// Zadni stena
		glColor3f(1.0f, 0.0f, 1.0f);
		glVertex3f(-0.5f, -0.5f, -0.5f);
		glVertex3f(-0.5f,  0.5f, -0.5f);
		glVertex3f( 0.5f,  0.5f, -0.5f);
		glVertex3f( 0.5f, -0.5f, -0.5f);

		// Horni stena
		glColor3f(0.0f, 0.0f, 1.0f);
		glVertex3f(-0.5f,  0.5f, -0.5f);
		glVertex3f(-0.5f,  0.5f,  0.5f);
		glVertex3f( 0.5f,  0.5f,  0.5f);
		glVertex3f( 0.5f,  0.5f, -0.5f);

		// Spodni stena
		glColor3f(0.0f, 1.0f, 1.0f);
		glVertex3f(-0.5f, -0.5f, -0.5f);
		glVertex3f( 0.5f, -0.5f, -0.5f);
		glVertex3f( 0.5f, -0.5f,  0.5f);
		glVertex3f(-0.5f, -0.5f,  0.5f);

		// Prava stena
		glColor3f(1.0f, 0.0f, 0.0f);
		glVertex3f( 0.5f, -0.5f, -0.5f);
		glVertex3f( 0.5f,  0.5f, -0.5f);
		glVertex3f( 0.5f,  0.5f,  0.5f);
		glVertex3f( 0.5f, -0.5f,  0.5f);

		// Leva stena
		glColor3f(0.0f, 1.0f, 0.0f);
		glVertex3f(-0.5f, -0.5f, -0.5f);
		glVertex3f(-0.5f, -0.5f,  0.5f);
		glVertex3f(-0.5f,  0.5f,  0.5f);
		glVertex3f(-0.5f,  0.5f, -0.5f);
	glEnd();

	unsigned int actual_time = SDL_GetTicks();// Grabovani casu (ve WinAPI GetTickCound())

	while (actual_time > last_time + TIMER_INTERVAL)// Aktualizovat, dokud scena neni v "soucasnem" case
	{
		OnTimer();// Aktualizace sceny
		last_time += TIMER_INTERVAL;// Pricteni 20 ms

		if(SDL_GetTicks() > actual_time + 1000)// Trva cely cyklus dele nez 1 sekundu?
		{
			fprintf(stderr, "Prekreslovaci cyklus trva prilis dlouho! Slaby pocitac!\n");
			fprintf(stderr, "Program ukoncen...");

			return false;// Konec funkce a programu
		}
	}
	
	return true;
}


/* A nakonec bezna inicializace SDL. */


int main(int argc, char *argv[])// Proste main()
{
	bool quit = false;// Flag ukonceni programu
	SDL_Event event;// Udalost

	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0)// Inicializace SDL
	{
		SDL_Quit();
		return 0;
	}

	if (!SDL_SetVideoMode(640, 480, 16, SDL_OPENGL))// Spusteni OpenGL a zmena rozliseni
	{
		SDL_Quit();
		return 0;
	}

	SDL_WM_SetCaption("Timer Example by Eosie", NULL);// Titulek okna

	// Inicializace OpenGL
	glViewport(0, 0, 640, 480);// Resetuje aktualni nastaveni
	glMatrixMode(GL_PROJECTION);// Zvoli projekcni matici
	glLoadIdentity();// Reset matice
	gluPerspective(45.0f, 640.f/480.0f, 1.0f, 100.0f);// Vypocet perspektivy
	glMatrixMode(GL_MODELVIEW);// Zvoli matici Modelview
	glLoadIdentity();// Reset matice

	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);// Cerne pozadi
	glClearDepth(1.0);// Mazani hloubky
	glDepthFunc(GL_LESS);// Nastaveni hloubky
	glEnable(GL_DEPTH_TEST);// Povoleni testu hloubky
	glShadeModel(GL_SMOOTH);// Jemne stinovani
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);// Perspektivni korekce

	while (!quit)// Hlavni smycka programu
	{
		while (SDL_PollEvent(&event))// Hlidani udalosti
		{
			switch (event.type)// Vetvi podle dosle zpravy
			{
			case SDL_QUIT:// Konec
				quit = true;
				break;
        
			case SDL_KEYDOWN:// Klavesa
				if (event.key.keysym.sym == SDLK_ESCAPE)// ESC
				{
					quit = true;
				}

				break;
			}
		}

		if (!DrawGLScene())// Vykresleni sceny
		{
			quit = true;// Konec programu
		}

		SDL_GL_SwapBuffers();// Prohozeni bufferu
		glFlush();
	}

	SDL_Quit();// Ukonceni SDL
	return 0;// Konec programu
}