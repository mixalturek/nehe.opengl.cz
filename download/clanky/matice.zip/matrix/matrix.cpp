/*     Tento k�d ukazuje jak v OpenGL pou��t matice
       k ur�en� sou�adnic bodu v protsoru snad n�komu 
       pom��e, jinak je samoz�ejm� ���en pod GPL
                            P�emysl Jaro� 2003 
       
       Uprost�ed obrazovky vykreslujeme rotuj�c� kostku
       vpravo naho�e vypisuji pozice jej�ch tr� vrchl� 
       v prostoru. 

       P�edem chci upozornit �e k�d nen� dokonal�
       asi nejv�t�� trhlynou je �e nen� obecn� 
       v p��pad� �e budete cht�t ve sv� aplikaci 
       pou��t matice budete si napsat sv�j k�d 
       scela od za��tku*/


/* Nejd�� vlo��me klasick� hlavi�ky pro Opengl
   SDL a n�kter� dal��*/
#include <stdio.h>
#include<sdl_opengl.h>//vkl�d� za n�s OpenGL
#include "SDL.h" // Hlavi�kov� soubor pro SDL
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <SDL_image.h>// Abychom mohli pou��vat funkci IMG_Load() na�te texturu textu
#include <math.h>

/*Definujeme n�jak� prom�n� nejdule�it�j�� je pole m*/
GLdouble m[16];// Pam� pro modelview matici 

/*tyto prom�n� nejsou d�le�it� k t�matu*/ 
GLuint base;// Ukazatel na prvn� z display list� pro font
GLuint loop;// Pomocn� pro cykly

float xrot, yrot, zrot;//informace o �hlu oto�en�
GLuint gl_texture;// Ukl�d� texturu

float x,y,z;/* pomocn� prom�n� p�i v�po�tech vrchl� ukl�daj� se 
              pouze do�asn� hodnoty*/ 

/* Zde m�me nejdule�it�j�� funkci programu p�eb�r� t�i argumenty co� 
   jsou hodnoty jednoho bodu jeho� pozici chceme ur�it k tomu vyu�ijeme
   matici kterou m�me ulo�enou v poli m, v�sledek ukl�d� do pomocn�ch 
   prom�n�ch*/
void Matrix(float vx,float vy,float vz)
{
  x =(float)( vx * m[0] + vy * m[4] + vz * m[8] +m[12]);

  y =(float)( vx * m[1] + vy * m[5] + vz * m[9] +m[13]);

  z =(float)( vx * m[2] + vy * m[6] + vz * m[10] +m[14]);
}

/* Funkce k vytvo�en� font� p�evzata z NeHe tutori�lu 17*/
GLvoid BuildFont(GLvoid)// Vytvo�en� display list� fontu
{
   float cx;// Koordin�ty x
   float cy;// Koordin�ty y

   base=glGenLists(256);// 256 display list�
   glBindTexture(GL_TEXTURE_2D, gl_texture);// V�b�r textury
   for (loop=0; loop<256; loop++)// Vytv��� 256 display list�
   {
      cx=float(loop%16)/16.0f;// X pozice aktu�ln�ho znaku
      cy=float(loop/16)/16.0f;// Y pozice aktu�ln�ho znaku

      glNewList(base+loop,GL_COMPILE);// Vytvo�en� display listu
      glBegin(GL_QUADS);// Pro ka�d� znak jeden obd�ln�k
      glTexCoord2f(cx,1-cy-0.0625f); glVertex2i(0,0);// Lev� doln�
      glTexCoord2f(cx+0.0625f,1-cy-0.0625f); glVertex2i(16,0);// Prav� doln�
      glTexCoord2f(cx+0.0625f,1-cy); glVertex2i(16,16);// Prav� horn�
      glTexCoord2f(cx,1-cy); glVertex2i(0,16);// Lev� horn�
      glEnd();// Konec znaku

      glTranslated(10,0,0);// P�esun na pravou stranu znaku
      glEndList();// Konec kreslen� display listu
      }// Cyklus pokra�uje dokud se nevytvo�� v�ech 256 znak�
}

/*Funkce slo��c� k nat�en� textury fontu p�evzata z turi�lu 
  o SDL_image od Bernyho*/
SDL_Surface* LoadBitmap(const char *filename)// Funkce pro na�teni bitmapy
{
   Uint8 *rowhi, *rowlo;// Ukazatele na prohazov�ni ��dk�
   Uint8 *tmpbuf, tmpch;// Do�asn� pam�
   int i, j;// ��d�c� prom�nn� pro cykly

   SDL_Surface *image;// Na��tan� obr�zek

   image = IMG_Load(filename);// Na�ten� dat obr�zku

   if (image == NULL)// O�et�en� chyby p�i na��t�n�
   {
      fprintf(stderr, "Nepodarilo se nacist %s: %s\n", filename, SDL_GetError());
      return(NULL);
   }

   tmpbuf = (Uint8 *)malloc(image->pitch);// Alokace pam�ti

   if (tmpbuf == NULL)// O�et�en� chyby
   {
      fprintf(stderr, "Nedostatek pameti\n");
      return NULL;
   }

   // Nastaven� prvn�ho a posledn�ho ��dku
   rowhi = (Uint8 *)image->pixels;
   rowlo = rowhi + (image->h * image->pitch) - image->pitch;

   for (i = 0; i < image->h/2; i++)
   {
     // P�evr�cen� BGR na RGB
     if (image->format->Bshift == 0)
     {
        for (j = 0; j < image->w; j++)
        {
           tmpch = rowhi[j*3];
           rowhi[j*3] = rowhi[j*3+2];
           rowhi[j*3+2] = tmpch;
           tmpch = rowlo[j*3];
           rowlo[j*3] = rowlo[j*3+2];
           rowlo[j*3+2] = tmpch;
        }
     }

     // Prohozen� ��dk�
     memcpy(tmpbuf, rowhi, image->pitch);
     memcpy(rowhi, rowlo, image->pitch);
     memcpy(rowlo, tmpbuf, image->pitch);

     // Posun ukazatel� na ��dky
     rowhi += image->pitch;
     rowlo -= image->pitch;
  }

  free(tmpbuf);// �klid
  return image;// Vr�t� na�ten� obr�zek
}

/*Funkce vytvo��c� font op�t p�evzata z �l�nku od Bernyho*/
GLuint CreateTexture(const char *file, int min_filter, int mag_filter, bool mipmaps)// Vytvo�� texturu
{
   SDL_Surface *surface;// Obr�zek
   
   surface = LoadBitmap(file);// Na�ten� obr�zku

   if (surface == NULL)// O�et�en� chyby
       return 0;

   GLuint texture;// OpenGL textura
   glGenTextures(1, &texture);// Generov�n� jedn� textury
   glBindTexture(GL_TEXTURE_2D, texture);// Nastaven� textury
   // Nastaven� po�adovan�ch filtr�
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, mag_filter);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, min_filter);
   if (mipmaps)// Mipmapovan� textura
   {
      gluBuild2DMipmaps(GL_TEXTURE_2D, 3, surface->w, surface->h, GL_RGB, GL_UNSIGNED_BYTE, surface->pixels);
   }
   else// Oby�ejn� textura
   {
      glTexImage2D(GL_TEXTURE_2D, 0, 3, surface->w, surface->h, 0, GL_RGB, GL_UNSIGNED_BYTE, surface->pixels);
   }

   SDL_FreeSurface(surface);// Smaz�n� SDL_Surface
   surface = NULL;// Nastaven� ukazatele na NULL
   return texture;// Vr�t� texturu
}


/*Zde inicializujeme OpenGL*/
void InitGL(int Width, int Height) // Tuto funkci vol�me hned po vytvo�en� okna pro inicializace OpenGL
{
  glViewport(0, 0, Width, Height);//nastaven� wieportu 
  glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // �ern� pozad�
  glClearDepth(1.0); // Povol�me maz�n� pozad�
  glDepthFunc(GL_LESS); // Vybereme typ Depth Testu
  glEnable(GL_DEPTH_TEST); // Povol�me Depth Test
  glShadeModel(GL_SMOOTH); // Povol�me Smooth Color Shading
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity(); // Resetujeme projek�n� matici
  gluPerspective(45.0f,(GLfloat)Width/(GLfloat)Height,0.1f,100.0f); // Vypo��t�me pom�r okna
  glMatrixMode(GL_MODELVIEW);
  xrot = yrot = zrot = 0.0; //inicializujeme pomocn� prom�n� ale je to pom�rn� zbite�n� 
  glDisable(GL_TEXTURE_2D);// Povolen� mapov�n� textur
  if ((gl_texture = CreateTexture("data/Font.jpg", GL_LINEAR, GL_LINEAR, false)) == 0)//na�teme font
  {
     fprintf(stderr, "Nepodarilo se vytvorit texturu\n");
     exit(1);
  }
  BuildFont();// Vytvo�� font
  glBlendFunc(GL_SRC_ALPHA,GL_ONE);// Vybere typ blendingu
}

/*Funkce slou��c� k v�pisu textu op�t p�evzato z NeHe tut.17*/
GLvoid glPrint(GLint x, GLint y, int set, const char *fmt, ...)// V�pis text�
{
   char text[256];// Bude ukl�dat v�sledn� �et�zec
   va_list ap;// Ukazatel do argument� funkce

   if (fmt == NULL)// Nebyl p�ed�n �et�zec
      return;// Konec

   va_start(ap, fmt);// Rozd�l� �et�zec pro prom�nn�
   vsprintf(text, fmt, ap);// Konvertuje symboly na ��sla
   va_end(ap);// V�sledek je ulo�en v text
 
   if (set>1)// Byla p�ed�na �patn� znakov� sada?
   {
      set=1;// Pokud ano, zvol� se kurz�va
   }
   
    glDisable(GL_DEPTH_TEST);// Vypne hloubkov� testov�n�
    glMatrixMode(GL_PROJECTION);// Vybere projek�n� matici
    glPushMatrix();// Ulo�� projek�n� matici
    glLoadIdentity();// Reset matice
    glOrtho(0,640,0,480,-1,1);// Nastaven� kolm� projekce
    glMatrixMode(GL_MODELVIEW);// V�b�r matice
    glPushMatrix();// Ulo�en� matice
    glLoadIdentity();// Reset matice
    glEnable(GL_BLEND);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, gl_texture);// V�b�r textury
   glTranslated(x,y,0);// P�esun na po�adovanou pozici
   glListBase(base-32+(128*set));// Zvol� znakovou sadu
 
   glCallLists(strlen(text),GL_UNSIGNED_BYTE, text);// V�pis textu na monitor
    
    glDisable(GL_BLEND);
   glMatrixMode(GL_PROJECTION);// V�b�r projek�n� matice
   glPopMatrix();// Obnoven� ulo�en� projek�n� matice
   glMatrixMode(GL_MODELVIEW);// V�b�r matice modelview
   glPopMatrix();// Obnoven� ulo�en� modelview matice
   glEnable(GL_DEPTH_TEST);// Zapne hloubkov� testov�n�
   glDisable(GL_TEXTURE_2D);
}

//Funkce slou�� k vykreslen� na obrazovku
void DrawGLScene() // Hlavn� vykreslovac� funkce
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Vymaz�n� obrazovkov�ho a hloubkov�ho bufferu
  glLoadIdentity(); // Reset matice pohledu
  glTranslatef(0.0f,0.0f,-7.0f); // Posun o 1.5 doleva a o 6 do hloubky
  glRotatef(xrot,1.0,0.0,0.0);//rotace v X vektoru
  glRotatef(yrot,0.0,1.0,0.0);//rotace v Y vektoru
  glRotatef(zrot,0.0,0.0,1.0);//rotace v Z vektoru 
  //Vykresl�me krychly 
  glBegin(GL_QUADS);// Za��tek kreslen� krychle
  glColor3f(0.0f,1.0f,0.0f);// zelen�
  glVertex3f( 1.0f, 1.0f,-1.0f);// Prav� horn� bod (horn� st�na)
  glColor3f(1.0f,0.0f,0.0f);// �erven�
  glVertex3f(-1.0f, 1.0f,-1.0f);// Lev� horn� bod (horn� st�na)
  glColor3f(1.0f,1.0f,0.0f);// �lut�
  glVertex3f(-1.0f, 1.0f, 1.0f);// Lev� doln� bod (horn� st�na)
  glColor3f(1.0f,0.0f,0.0f);// �erven�
  glVertex3f( 1.0f, 1.0f, 1.0f);// Prav� doln� bod (horn� st�na)
 
  glColor3f(0.0f,1.0f,0.0f);// zelen�
  glVertex3f( 1.0f,-1.0f, 1.0f);// Prav� horn� bod (spodn� st�na)
  glColor3f(0.0f,0.0f,1.0f);// Modr�
  glVertex3f(-1.0f,-1.0f, 1.0f);// Lev� horn� (spodn� st�na)
  glColor3f(0.0f,0.0f,1.0f);// Modr�
  glVertex3f(-1.0f,-1.0f,-1.0f);// Lev� doln� (spodn� st�na)
  glColor3f(1.0f,1.0f,0.0f);// �lut�
  glVertex3f( 1.0f,-1.0f,-1.0f);// Prav� doln� (spodn� st�na)
  
  glColor3f(1.0f,0.0f,0.0f);// �erven�
  glVertex3f( 1.0f, 1.0f, 1.0f);// Prav� horn� (�eln� st�na)
  glColor3f(1.0f,1.0f,0.0f);// �lut�
  glVertex3f(-1.0f, 1.0f, 1.0f);// Lev� horn� (�eln� st�na)
  glColor3f(0.0f,0.0f,1.0f);// Modr�
  glVertex3f(-1.0f,-1.0f, 1.0f);// Lev� doln� (�eln� st�na)
  glColor3f(0.0f,1.0f,0.0f);// zelen�
  glVertex3f( 1.0f,-1.0f, 1.0f);// Prav� doln� (�eln� st�na)
  
  glColor3f(1.0f,1.0f,0.0f);// �lut�
  glVertex3f( 1.0f,-1.0f,-1.0f);// Prav� horn� (zadn� st�na)
  glColor3f(0.0f,0.0f,1.0f);// Modr�
  glVertex3f(-1.0f,-1.0f,-1.0f);// Lev� horn� (zadn� st�na)
  glColor3f(1.0f,0.0f,0.0f);// �erven�
  glVertex3f(-1.0f, 1.0f,-1.0f);// Lev� doln� (zadn� st�na)
  glColor3f(0.0f,1.0f,0.0f);// zelen�
  glVertex3f( 1.0f, 1.0f,-1.0f);// Prav� doln� (zadn� st�na)
  
  glColor3f(1.0f,1.0f,0.0f);// �lut�
  glVertex3f(-1.0f, 1.0f, 1.0f);// Prav� horn� (lev� st�na)
  glColor3f(1.0f,0.0f,0.0f);// �erven�
  glVertex3f(-1.0f, 1.0f,-1.0f);// Lev� horn� (lev� st�na)
  glColor3f(0.0f,0.0f,1.0f);// Modr�
  glVertex3f(-1.0f,-1.0f,-1.0f);// Lev� doln� (lev� st�na)
  glColor3f(0.0f,0.0f,1.0f);// Modr�
  glVertex3f(-1.0f,-1.0f, 1.0f);// Prav� doln� (lev� st�na)
  
  glColor3f(0.0f,1.0f,0.0f);// zelen�
  glVertex3f( 1.0f, 1.0f,-1.0f);// Prav� horn� (prav� st�na)
  glColor3f(1.0f,0.0f,0.0f);// �erven�
  glVertex3f( 1.0f, 1.0f, 1.0f);// Lev� horn� (prav� st�na)
  glColor3f(0.0f,1.0f,0.0f);// zelen�
  glVertex3f( 1.0f,-1.0f, 1.0f);// Lev� doln� (prav� st�na)
  glColor3f(1.0f,1.0f,0.0f);// �lut�
  glVertex3f( 1.0f,-1.0f,-1.0f);// Prav� doln� (prav� st�na)
  glEnd();// Konec kreslen� krychle

  glGetDoublev(GL_MODELVIEW_MATRIX, m);// Z�sk�n� modelview matice kterou ulo��me 
                                       // v poli m 

  glPrint(5,460,0,"Matrix");//vyp�e t�ma demonsrtace
  
  /*Zde postupn� vypo�teme a zobraz�me sou�adnice v�ech bod� 
    v�imn�te si �e fci. Matrix kter� v�e zpo��t� p�d�v�m pevn� hodnoty
    to by v opravdov� aplikaci ne�lo ale zde m�me jen 8 vrchol�
    hodnoty vrchol� zn�m zb�v� pouze ur�it pozici po pou�it� fc�.
    glTranslate a glRotate k �emu� n�m pom��e matic a fce. Matrix*/
  Matrix(-1.0,1.0,1.0);
  glPrint(400,460,0,"v1 %.2f %.2f %.2f",x,y,z);
  Matrix(-1.0,-1.0,1.0);
  glPrint(400,440,0,"v2 %.2f %.2f %.2f",x,y,z);
  Matrix(-1.0,1.0,-1.0);
  glPrint(400,420,0,"v3 %.2f %.2f %.2f",x,y,z);
  Matrix(-1.0,-1.0,-1.0);
  glPrint(400,400,0,"v4 %.2f %.2f %.2f",x,y,z);
  Matrix(1.0,1.0,1.0);
  glPrint(400,380,0,"v5 %.2f %.2f %.2f",x,y,z);
  Matrix(1.0,-1.0,1.0);
  glPrint(400,360,0,"v6 %.2f %.2f %.2f",x,y,z);
  Matrix(1.0,1.0,-1.0);
  glPrint(400,340,0,"v7 %.2f %.2f %.2f",x,y,z);
  Matrix(1.0,-1.0,-1.0);
  glPrint(400,320,0,"v8 %.2f %.2f %.2f",x,y,z);

  /*Zb�v� pouze upravit hodnoty t�chto prom�nn�ch pro oto�en�*/
  xrot += 0.15;
  yrot -= 0.15;
  zrot += 0.15; 

  SDL_GL_SwapBuffers(); // Prohozeni bufferu, aby se zobrazilo, co jsme nakreslili
}

/*Funkce main tak� p�evzat� od Bernyho*/
int main(int argc, char **argv) // funkce main
{
  int done; // Ukon�ovac� prom�nn�
  if ( SDL_Init(SDL_INIT_VIDEO) < 0 ) // Inicializace SDL s grafick�m v�stupem
  {
    fprintf(stderr, "Selhala inicializace SDL: %s\n", SDL_GetError());
    exit(1);
  }
  if (SDL_SetVideoMode(640, 480, 0, SDL_OPENGL) == NULL) // Vytvo�en� OpenGL okna 640x480
  {
    fprintf(stderr, "Neni mozne vytvorit OpenGL okno: %s\n", SDL_GetError());
    SDL_Quit(); // Ukon�en� SDL
    exit(2);
  }
 
  SDL_WM_SetCaption("Matrix tutorial", NULL); // Titulek okna
  InitGL(640, 480); // Inicializace OpenGL
  done = 0; // Je�t� nekon�it
  while (!done) // Hlavn� cyklus programu
  {
    DrawGLScene(); // Vykreslen� sc�ny
    SDL_Event event; // Prom�nn� zpr�vy
    while (SDL_PollEvent(&event)) // Zpracov�vat zpr�vy
    {
      if (event.type == SDL_QUIT) // Zpr�va o ukon�en�
      {
         done = 1; // Ukon�it hlavn� cyklus
      }
      if (event.type == SDL_KEYDOWN) // Zpr�va o stisku kl�vesy
      {
         if (event.key.keysym.sym == SDLK_ESCAPE) // Kl�vesa ESC
         {
            done = 1; // Ukon�it hlavn� cyklus
         }
      }
   }
 }
SDL_Quit(); // Ukon�en� SDL
return 1;
}


