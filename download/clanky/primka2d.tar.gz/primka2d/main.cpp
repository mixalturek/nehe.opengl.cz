#include <stdio.h>
#include "primka2d.h"

int main(int argc, char** argv)
{
	WPrimka2D primka1(3.0, -1.0, 1.0);
	WPrimka2D primka2(1.0, 3.0, -14.0);

	double prusecik_x, prusecik_y;

	if(primka1.Prusecik(primka2, prusecik_x, prusecik_y))
	{
		printf("Pr�se��k [%f; %f]\n", prusecik_x, prusecik_y);
	}

	return 0;
}
