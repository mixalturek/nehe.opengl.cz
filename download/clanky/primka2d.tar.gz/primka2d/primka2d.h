/*
 *	primka2d.h - Hlavi�kov� soubor p��mky WPrimka2D
 *
 *	Michal Turek - Woq, 30.1.2004
 *
 *	woq@email.cz
 *	http://woq.nipax.cz/
 *	http://nehe.opengl.cz/
 *
 *	K�d je voln� �i�iteln� podle licence GNU GPL (http://www.gnu.cz/), pou�it� absolutn� bez z�ruky.
 *
 */

 
#ifndef __PRIMKA2D_H__
#define __PRIMKA2D_H__

#include <math.h>

class WPrimka2D// T��da 2D p��mky
{
private:
	double a, b, c;// Obecn� rovnice p��mky a*x + b*y + c = 0

public:
	WPrimka2D();
	~WPrimka2D();
	WPrimka2D(const WPrimka2D& primka);
	WPrimka2D(double a, double b, double c);// P��m� zad�n�
	WPrimka2D(double x1, double y1, double x2, double y2);// P��mka ze dvou bod�

	void Create(double a, double b, double c);
	void Create(double x1, double y1, double x2, double y2);

	inline double GetA() { return a; }
	inline double GetB() { return b; }
	inline double GetC() { return b; }

	bool operator==(WPrimka2D& primka);// Jsou p��mky spl�vaj�c�? V �vahu se berou i k-n�sobky.
	bool operator!=(WPrimka2D& primka);// Negace...

	bool JeNaPrimce(double x, double y);// Le�� bod na p��mce?
	bool JsouRovnobezne(WPrimka2D& primka);// Jsou p��mky rovnob�n�?
	bool JsouKolme(WPrimka2D& primka);// Jsou p��mky kolm�?

	bool Prusecik(WPrimka2D& primka, double& retx, double& rety);// Pr�se��k dvou p��mek, false pokud neexistuje (rovnob�n�)
	double Uhel(WPrimka2D& primka);// �hel dvou p��mek (v radi�nech)
	double VzdalenostBodu(double x, double y);// Vzd�lenost bodu od p��mky
};

#endif
